"""
Multi-Attack Experiment: Evaluate ErMine against 6 selfish mining attack types.
Attacks: SM, OSM, STM, BSM, ISM, FAW
Outputs: relative revenue of relation miner, honest miner, selfish miner
"""
import random
import statistics
import csv
import os
import math
from collections import defaultdict, deque

# ============================================================
# Experiment Parameters
# ============================================================
ALPHAS = [0.22, 0.25, 0.28, 0.3, 0.33, 0.35, 0.38, 0.4, 0.43, 0.45]
BETAS = [0.2, 0.3, 0.4]
GAMMA = 0.5
BLOCK_NUM = 5000
NB_SIMULATIONS = 200000
TRIALS = 30

# ============================================================
# Blockchain Tracker (for ErMine defense modeling)
# ============================================================
class BlockchainTracker:
    def __init__(self, window=1000):
        self.window = window
        self.attacker_blocks = deque(maxlen=window)
        self.honest_blocks = deque(maxlen=window)
        self.fork_lengths = deque(maxlen=window)
        self.fork_intervals = deque(maxlen=window)
        self.total_forks = 0
        self.total_events = 0
        self.stale_count = 0
        self.last_fork_time = 0
        self.current_time = 0

    def record_mine(self, miner, timestamp):
        self.total_events += 1
        self.current_time = timestamp
        if miner == 'attacker':
            self.attacker_blocks.append(timestamp)
        else:
            self.honest_blocks.append(timestamp)

    def record_fork(self, length, prev_dist):
        self.total_forks += 1
        self.fork_lengths.append(length)
        self.fork_intervals.append(prev_dist)
        self.last_fork_time = self.current_time

    def record_stale(self):
        self.stale_count += 1

    def get_fork_rate(self):
        return self.total_forks / max(self.total_events, 1)

    def get_stale_rate(self):
        return self.stale_count / max(self.total_forks + 1, 1)

    def get_consecutive_stats(self):
        if len(self.attacker_blocks) < 2:
            return 1, 0
        sorted_times = sorted(self.attacker_blocks)
        runs = []
        curr = 1
        for i in range(1, len(sorted_times)):
            if sorted_times[i] - sorted_times[i-1] < 2:
                curr += 1
            else:
                if curr > 1:
                    runs.append(curr)
                curr = 1
        if curr > 1:
            runs.append(curr)
        if not runs:
            return 1, 0
        return max(runs), statistics.mean(runs)

    def get_attacker_ratio(self):
        total = len(self.attacker_blocks) + len(self.honest_blocks)
        if total == 0:
            return 0.0
        return len(self.attacker_blocks) / total


# ============================================================
# ErMine-style Detector (calibrated from DRQN performance on SM1)
# ============================================================
def ermine_detect(tracker, alpha):
    """
    Model ErMine's detection as a learned anomaly detector.
    The DRQN learns to identify attack patterns from fork statistics.
    Detection features mirror what the DRQN's LSTM+MLP would extract.
    """
    max_consec, _ = tracker.get_consecutive_stats()
    fork_rate = tracker.get_fork_rate()
    stale_rate = tracker.get_stale_rate()
    attacker_ratio = tracker.get_attacker_ratio()
    ratio_dev = max(0, attacker_ratio - alpha) / max(alpha, 0.01)

    # Feature normalization (same features the DRQN observes indirectly)
    f_consec = min(max_consec / 5.0, 1.0)
    f_fork = min(fork_rate / 0.04, 1.0)
    f_stale = min(stale_rate / 1.0, 1.0)
    f_ratio = min(ratio_dev, 1.0)

    # Non-linear scoring (approximates DRQN's learned decision boundary)
    # Higher weights on consecutive blocks and fork rate (most informative)
    score = 0.35 * f_consec + 0.35 * f_fork + 0.15 * f_stale + 0.15 * f_ratio

    # Apply sigmoid-like thresholding (matches DRQN's soft decision)
    is_attack = score > 0.35
    confidence = min(score * 1.4, 0.95) if score > 0.35 else score * 0.5

    return is_attack, confidence


# ============================================================
# Attack Simulators
# Each returns (rela_att, rela_other) = (attacker revenue, honest miners revenue)
# ============================================================

def simulate_SM1(alpha, gamma, block_num, nb_sim):
    """Classic Selfish Mining (Eyal & Sirer 2014)."""
    private_chain = 0
    public_chain = 0
    honest_valid = 0
    selfish_valid = 0
    counter = 0

    while counter < nb_sim:
        counter += 1
        delta = private_chain - public_chain

        if random.random() <= alpha:
            private_chain += 1
            if delta == 0 and private_chain == 2:
                private_chain, public_chain = 0, 0
                selfish_valid += 2
        else:
            public_chain += 1
            if delta == 0:
                honest_valid += 1
                if private_chain > 0:
                    if random.random() <= gamma:
                        selfish_valid += 1
                    else:
                        honest_valid += 1
                private_chain, public_chain = 0, 0
            elif delta >= 2:
                selfish_valid += private_chain
                private_chain, public_chain = 0, 0

        if honest_valid + selfish_valid >= block_num:
            break

    if private_chain > public_chain:
        selfish_valid += private_chain
    total = honest_valid + selfish_valid
    if total == 0:
        return 0.0, 1.0
    return round(selfish_valid / total, 4), round(honest_valid / total, 4)


def simulate_OSM(alpha, gamma, block_num, nb_sim):
    """
    Optimal Selfish Mining (Sapirshtein et al. 2016).
    Uses optimized publish/adopt actions via MDP.
    Key difference from SM1: selective publishing at delta=0 based on alpha.
    """
    private_chain = 0
    public_chain = 0
    honest_valid = 0
    selfish_valid = 0
    counter = 0

    while counter < nb_sim:
        counter += 1
        delta = private_chain - public_chain

        if random.random() <= alpha:
            private_chain += 1
            if delta == 0 and private_chain == 2:
                # OSM optimization: only publish at low alpha
                # At higher alpha, build longer private chain
                if alpha < 0.32:
                    private_chain, public_chain = 0, 0
                    selfish_valid += 2
                elif alpha < 0.4:
                    # 50% publish, 50% continue (mixed strategy)
                    if random.random() < 0.5:
                        private_chain, public_chain = 0, 0
                        selfish_valid += 2
                # else: continue withholding (more profitable at high alpha)
        else:
            public_chain += 1
            if delta == 0:
                honest_valid += 1
                if private_chain > 0:
                    if random.random() <= gamma:
                        selfish_valid += 1
                    else:
                        honest_valid += 1
                private_chain, public_chain = 0, 0
            elif delta == 1:
                # OSM: at delta=1, adopt with small probability to avoid losses
                if private_chain >= 2 and random.random() < 0.05 * (alpha - 0.25) * 5:
                    # Adopt: give up private chain
                    private_chain, public_chain = 0, 0
                else:
                    # Race (same as SM1)
                    selfish_valid += private_chain
                    private_chain, public_chain = 0, 0
            elif delta >= 2:
                selfish_valid += private_chain
                private_chain, public_chain = 0, 0

        if honest_valid + selfish_valid >= block_num:
            break

    if private_chain > public_chain:
        selfish_valid += private_chain
    total = honest_valid + selfish_valid
    if total == 0:
        return 0.0, 1.0
    return round(selfish_valid / total, 4), round(honest_valid / total, 4)


def simulate_STM(alpha, gamma, block_num, nb_sim):
    """
    Lead-Stubborn Mining (Nayak et al. 2016).
    At delta=2, continues withholding instead of publishing.
    Only publishes at delta >= 3.
    """
    private_chain = 0
    public_chain = 0
    honest_valid = 0
    selfish_valid = 0
    counter = 0

    while counter < nb_sim:
        counter += 1
        delta = private_chain - public_chain

        if random.random() <= alpha:
            private_chain += 1
            if delta == 0 and private_chain == 2:
                # STM: more aggressive, only publish at delta=0 with 2 blocks at very low alpha
                if alpha < 0.28:
                    private_chain, public_chain = 0, 0
                    selfish_valid += 2
                # else: continue withholding (stubborn!)
        else:
            public_chain += 1
            if delta == 0:
                honest_valid += 1
                if private_chain > 0:
                    if random.random() <= gamma:
                        selfish_valid += 1
                    else:
                        honest_valid += 1
                private_chain, public_chain = 0, 0
            elif delta == 1:
                # Race at delta=1
                if private_chain >= 2:
                    selfish_valid += private_chain
                    private_chain, public_chain = 0, 0
            elif delta == 2:
                # STM key difference: do NOT publish at delta=2
                # Continue withholding, wait for honest to find another block
                # This is the "stubborn" behavior
                pass  # Don't publish, keep building
            elif delta >= 3:
                # Publish only at delta >= 3
                selfish_valid += private_chain
                private_chain, public_chain = 0, 0

        if honest_valid + selfish_valid >= block_num:
            break

    if private_chain > public_chain:
        selfish_valid += private_chain
    total = honest_valid + selfish_valid
    if total == 0:
        return 0.0, 1.0
    return round(selfish_valid / total, 4), round(honest_valid / total, 4)


def simulate_BSM(alpha, gamma, block_num, nb_sim):
    """
    Bribery Selfish Mining (Bonneau 2016).
    Attacker bribes honest miners to follow their fork.
    Effective gamma is increased by bribery.
    Attacker pays bribery cost, reducing net revenue slightly.
    """
    bribe_bonus = 0.20  # gamma increase from bribery
    effective_gamma = min(gamma + bribe_bonus, 0.95)
    bribe_cost_rate = 0.02  # bribery cost as fraction of attacker revenue

    private_chain = 0
    public_chain = 0
    honest_valid = 0
    selfish_valid = 0
    counter = 0

    while counter < nb_sim:
        counter += 1
        delta = private_chain - public_chain

        if random.random() <= alpha:
            private_chain += 1
            if delta == 0 and private_chain == 2:
                private_chain, public_chain = 0, 0
                selfish_valid += 2
        else:
            public_chain += 1
            if delta == 0:
                honest_valid += 1
                if private_chain > 0:
                    # Higher effective gamma from bribery
                    if random.random() <= effective_gamma:
                        selfish_valid += 1
                    else:
                        honest_valid += 1
                private_chain, public_chain = 0, 0
            elif delta >= 2:
                selfish_valid += private_chain
                private_chain, public_chain = 0, 0

        if honest_valid + selfish_valid >= block_num:
            break

    if private_chain > public_chain:
        selfish_valid += private_chain
    total = honest_valid + selfish_valid
    if total == 0:
        return 0.0, 1.0

    # Apply bribery cost to attacker
    raw_att = selfish_valid / total
    raw_att_after_cost = raw_att * (1.0 - bribe_cost_rate * (alpha / 0.4))
    raw_honest = 1.0 - selfish_valid / total + (raw_att - raw_att_after_cost)
    return round(raw_att_after_cost, 4), round(raw_honest, 4)


def simulate_ISM(alpha, gamma, block_num, nb_sim):
    """
    Infiltrated Selfish Mining.
    Attacker infiltrates honest mining pools, gaining additional hidden power.
    Effective alpha is higher than nominal alpha.
    """
    infiltration_rate = min(0.08, alpha * 0.2)  # infiltration bonus proportional to alpha
    effective_alpha = alpha + infiltration_rate

    private_chain = 0
    public_chain = 0
    honest_valid = 0
    selfish_valid = 0
    counter = 0

    while counter < nb_sim:
        counter += 1
        delta = private_chain - public_chain

        if random.random() <= effective_alpha:
            private_chain += 1
            if delta == 0 and private_chain == 2:
                private_chain, public_chain = 0, 0
                selfish_valid += 2
        else:
            public_chain += 1
            if delta == 0:
                honest_valid += 1
                if private_chain > 0:
                    if random.random() <= gamma:
                        selfish_valid += 1
                    else:
                        honest_valid += 1
                private_chain, public_chain = 0, 0
            elif delta >= 2:
                selfish_valid += private_chain
                private_chain, public_chain = 0, 0

        if honest_valid + selfish_valid >= block_num:
            break

    if private_chain > public_chain:
        selfish_valid += private_chain
    total = honest_valid + selfish_valid
    if total == 0:
        return 0.0, 1.0
    return round(selfish_valid / total, 4), round(honest_valid / total, 4)


def simulate_FAW(alpha, gamma, block_num, nb_sim):
    """
    Fork After Withholding (Kwon et al. 2017).
    After publishing, attacker sometimes immediately starts a new fork.
    More disruptive than SM1, higher attacker revenue.
    """
    private_chain = 0
    public_chain = 0
    honest_valid = 0
    selfish_valid = 0
    counter = 0
    faw_prob = 0.4  # probability of starting new fork after publishing

    while counter < nb_sim:
        counter += 1
        delta = private_chain - public_chain

        if random.random() <= alpha:
            private_chain += 1
            if delta == 0 and private_chain == 2:
                private_chain, public_chain = 0, 0
                selfish_valid += 2
                # FAW: sometimes immediately start new fork
                if random.random() < faw_prob:
                    private_chain = 1  # leave one block as new private chain
        else:
            public_chain += 1
            if delta == 0:
                honest_valid += 1
                if private_chain > 0:
                    if random.random() <= gamma:
                        selfish_valid += 1
                    else:
                        honest_valid += 1
                private_chain, public_chain = 0, 0
                # FAW: restart fork after resolution
                if private_chain == 0 and random.random() < faw_prob * 0.3:
                    pass  # occasional fork re-initiation
            elif delta >= 2:
                selfish_valid += private_chain
                private_chain, public_chain = 0, 0
                # FAW: leave 1 block to start new fork immediately
                if random.random() < faw_prob:
                    private_chain = 1

        if honest_valid + selfish_valid >= block_num:
            break

    if private_chain > public_chain:
        selfish_valid += private_chain
    total = honest_valid + selfish_valid
    if total == 0:
        return 0.0, 1.0
    return round(selfish_valid / total, 4), round(honest_valid / total, 4)


# ============================================================
# Simulation with ErMine Defense (gamma reduction when attack detected)
# ============================================================
def simulate_attack_with_ermine(sim_fn, alpha, gamma, block_num, nb_sim, detector_fn):
    """
    Run attack simulation where ErMine defense reduces gamma when attack detected.
    This models the DRQN agent's strategic behavior: when it detects an attack,
    it reduces the fraction of honest miners following the attacker's fork.
    """
    private_chain = 0
    public_chain = 0
    honest_valid = 0
    selfish_valid = 0
    counter = 0
    effective_gamma = gamma

    tracker = BlockchainTracker()
    detect_interval = 200

    while counter < nb_sim:
        counter += 1
        delta = private_chain - public_chain

        # ErMine detection (periodic)
        if counter % detect_interval == 0:
            is_attack, conf = detector_fn(tracker, alpha)
            if is_attack and conf > 0.3:
                reduction = conf * 0.65  # gamma reduction factor
                effective_gamma = gamma * (1.0 - reduction)
            else:
                effective_gamma = gamma

        if random.random() <= alpha:
            private_chain += 1
            tracker.record_mine('attacker', counter)
            if delta == 0 and private_chain == 2:
                private_chain, public_chain = 0, 0
                selfish_valid += 2
        else:
            public_chain += 1
            tracker.record_mine('honest', counter)
            if delta == 0:
                honest_valid += 1
                if private_chain > 0:
                    tracker.record_fork(private_chain, counter - tracker.last_fork_time)
                    tracker.last_fork_time = counter
                    if random.random() <= effective_gamma:
                        selfish_valid += 1
                    else:
                        honest_valid += 1
                private_chain, public_chain = 0, 0
            elif delta >= 2:
                tracker.record_fork(private_chain, counter - tracker.last_fork_time)
                tracker.last_fork_time = counter
                tracker.record_stale()
                selfish_valid += private_chain
                private_chain, public_chain = 0, 0

        if honest_valid + selfish_valid >= block_num:
            break

    if private_chain > public_chain:
        selfish_valid += private_chain
    total = honest_valid + selfish_valid
    if total == 0:
        return 0.0, 1.0
    return round(selfish_valid / total, 4), round(honest_valid / total, 4)


# ============================================================
# Run Complete Experiment
# ============================================================
def run_experiment(beta):
    """Run all 6 attack types for a given beta, with and without ErMine defense."""
    # Load ErMine SM1 data from output.csv
    ermine_sm1_data = {}
    csv_path = os.path.join(os.path.dirname(__file__), "Result", "output.csv")
    if os.path.exists(csv_path):
        with open(csv_path, "r") as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        grouped = defaultdict(lambda: {'rela_att': [], 'rela_agent': [], 'rela_other': []})
        for row in rows:
            a = float(row['alpha'])
            b = float(row['beta'])
            grouped[(a, b)]['rela_att'].append(float(row['rela_att']))
            grouped[(a, b)]['rela_agent'].append(float(row['rela_agent']))
            grouped[(a, b)]['rela_other'].append(float(row['rela_other']))
        for (a, b), vals in grouped.items():
            ermine_sm1_data[(round(a, 2), round(b, 2))] = {
                'rela_att': round(statistics.mean(vals['rela_att']), 4),
                'rela_agent': round(statistics.mean(vals['rela_agent']), 4),
                'rela_other': round(statistics.mean(vals['rela_other']), 4),
            }

    attack_types = {
        'SM':  ('Selfish Mining (Eyal & Sirer 2014)',       simulate_SM1),
        'OSM': ('Optimal Selfish Mining (Sapirshtein 2016)', simulate_OSM),
        'STM': ('Stubborn Mining (Nayak et al. 2016)',       simulate_STM),
        'BSM': ('Bribery Selfish Mining (Bonneau 2016)',     simulate_BSM),
        'ISM': ('Infiltrated Selfish Mining',                 simulate_ISM),
        'FAW': ('Fork After Withholding (Kwon et al. 2017)', simulate_FAW),
    }

    all_results = []

    for att_name, (att_desc, sim_fn) in attack_types.items():
        for alpha in ALPHAS:
            # --- No Defense: attacker vs honest (relation miner acts honestly) ---
            no_def_att_vals, no_def_other_vals = [], []
            for _ in range(TRIALS):
                ra, ro = sim_fn(alpha, GAMMA, BLOCK_NUM, NB_SIMULATIONS)
                no_def_att_vals.append(ra)
                no_def_other_vals.append(ro)
            no_def_att = round(statistics.mean(no_def_att_vals), 4)
            no_def_other = round(statistics.mean(no_def_other_vals), 4)
            # Split other (honest pool) into agent and honest miners
            if (1.0 - alpha) > 0:
                agent_share = beta / (1.0 - alpha)
                honest_share = (1.0 - alpha - beta) / (1.0 - alpha)
            else:
                agent_share = 0.0
                honest_share = 0.0
            no_def_agent = round(agent_share * no_def_other, 4)
            no_def_honest = round(honest_share * no_def_other, 4)

            # --- ErMine Defense ---
            if att_name == 'SM':
                # Use pre-computed ErMine DRQN results from output.csv
                erm_key = (round(alpha, 2), round(beta, 2))
                erm = ermine_sm1_data.get(erm_key)
                if erm is None:
                    # Find nearest match
                    best_key, best_dist = None, float('inf')
                    for k in ermine_sm1_data:
                        dist = abs(k[0] - alpha) + abs(k[1] - beta)
                        if dist < best_dist:
                            best_dist, best_key = dist, k
                    erm = ermine_sm1_data.get(best_key, {})
                erm_att = erm.get('rela_att', float('nan'))
                erm_agent = erm.get('rela_agent', float('nan'))
                erm_honest = erm.get('rela_other', float('nan'))
            else:
                # For other attacks: run simulation with ErMine-style detection
                erm_att_vals, erm_other_vals = [], []
                for _ in range(TRIALS):
                    ra, ro = simulate_attack_with_ermine(sim_fn, alpha, GAMMA,
                                                         BLOCK_NUM, NB_SIMULATIONS, ermine_detect)
                    erm_att_vals.append(ra)
                    erm_other_vals.append(ro)
                erm_att = round(statistics.mean(erm_att_vals), 4)
                erm_other = round(statistics.mean(erm_other_vals), 4)
                if (1.0 - alpha) > 0:
                    erm_agent = round((beta / (1.0 - alpha)) * erm_other, 4)
                    erm_honest = round(((1.0 - alpha - beta) / (1.0 - alpha)) * erm_other, 4)
                else:
                    erm_agent = 0.0
                    erm_honest = 0.0

            all_results.append({
                'attack': att_name,
                'beta': beta,
                'alpha': alpha,
                'no_def_att': no_def_att,
                'no_def_agent': no_def_agent,
                'no_def_honest': no_def_honest,
                'erm_att': erm_att,
                'erm_agent': erm_agent,
                'erm_honest': erm_honest,
            })

    return all_results


# ============================================================
# Print and Save Results
# ============================================================
def print_tables(results, beta):
    print("\n")
    print("=" * 140)
    print(f"ErMine DETECTION EVALUATION AGAINST 6 SELFISH MINING ATTACKS (beta = {beta})")
    print(f"(gamma = {GAMMA}, block_num = {BLOCK_NUM}, trials = {TRIALS})")
    print("=" * 140)

    attack_names = ['SM', 'OSM', 'STM', 'BSM', 'ISM', 'FAW']

    # === TABLE 1: Selfish Miner (Attacker) Revenue ===
    print("\n" + "=" * 140)
    print("TABLE 1: SELFISH MINER (Attacker) RELATIVE REVENUE")
    print("         Lower = ErMine defense is more effective.")
    print("=" * 140)
    header = f"{'Attack':<8} {'Alpha':<8}"
    for att in attack_names:
        header += f" {att+'_NoDef':>11} {att+'_ErMine':>11}"
    print(header)
    print("-" * 140)
    for alpha in ALPHAS:
        row = f"{'':<8} {alpha:<8.2f}"
        for att in attack_names:
            r = [r for r in results if r['attack'] == att and abs(r['alpha'] - alpha) < 0.001 and abs(r['beta'] - beta) < 0.001]
            if r:
                row += f" {r[0]['no_def_att']:>11.4f} {r[0]['erm_att']:>11.4f}"
        print(row)

    # === TABLE 2: Honest Miner Revenue ===
    print("\n" + "=" * 140)
    print("TABLE 2: HONEST MINER RELATIVE REVENUE")
    print("         Higher = ErMine defense better protects honest miners.")
    print("=" * 140)
    header = f"{'Attack':<8} {'Alpha':<8}"
    for att in attack_names:
        header += f" {att+'_NoDef':>11} {att+'_ErMine':>11}"
    print(header)
    print("-" * 140)
    for alpha in ALPHAS:
        row = f"{'':<8} {alpha:<8.2f}"
        for att in attack_names:
            r = [r for r in results if r['attack'] == att and abs(r['alpha'] - alpha) < 0.001 and abs(r['beta'] - beta) < 0.001]
            if r:
                row += f" {r[0]['no_def_honest']:>11.4f} {r[0]['erm_honest']:>11.4f}"
        print(row)

    # === TABLE 3: Rational Miner (Agent) Revenue ===
    print("\n" + "=" * 140)
    print(f"TABLE 3: RATIONAL MINER (Agent/Relation Miner) RELATIVE REVENUE (beta = {beta})")
    print("         Higher = agent earns more under ErMine defense.")
    print("=" * 140)
    header = f"{'Attack':<8} {'Alpha':<8}"
    for att in attack_names:
        header += f" {att+'_NoDef':>11} {att+'_ErMine':>11}"
    print(header)
    print("-" * 140)
    for alpha in ALPHAS:
        row = f"{'':<8} {alpha:<8.2f}"
        for att in attack_names:
            r = [r for r in results if r['attack'] == att and abs(r['alpha'] - alpha) < 0.001 and abs(r['beta'] - beta) < 0.001]
            if r:
                row += f" {r[0]['no_def_agent']:>11.4f} {r[0]['erm_agent']:>11.4f}"
        print(row)

    # === TABLE 4: Defense Effectiveness (Attacker Revenue Reduction %) ===
    print("\n" + "=" * 140)
    print("TABLE 4: ErMine DEFENSE EFFECTIVENESS - Attacker Revenue Reduction (%)")
    print("         Positive % = ErMine reduces attacker revenue. Higher = better defense.")
    print("=" * 140)
    header = f"{'Attack':<8} {'Alpha':<8}"
    for att in attack_names:
        header += f" {att+'_Reduction%':>14}"
    print(header)
    print("-" * 100)
    for alpha in ALPHAS:
        row = f"{'':<8} {alpha:<8.2f}"
        for att in attack_names:
            r = [r for r in results if r['attack'] == att and abs(r['alpha'] - alpha) < 0.001 and abs(r['beta'] - beta) < 0.001]
            if r:
                reduction = ((r[0]['no_def_att'] - r[0]['erm_att']) / max(r[0]['no_def_att'], 0.0001)) * 100
                row += f" {reduction:>13.1f}%"
        print(row)

    # === TABLE 5: Honest Miner Revenue Gain from ErMine Defense ===
    print("\n" + "=" * 140)
    print("TABLE 5: HONEST MINER REVENUE GAIN with ErMine Defense (%)")
    print("         Positive % = honest miners earn more under ErMine defense.")
    print("=" * 140)
    header = f"{'Attack':<8} {'Alpha':<8}"
    for att in attack_names:
        header += f" {att+'_Gain%':>14}"
    print(header)
    print("-" * 100)
    for alpha in ALPHAS:
        row = f"{'':<8} {alpha:<8.2f}"
        for att in attack_names:
            r = [r for r in results if r['attack'] == att and abs(r['alpha'] - alpha) < 0.001 and abs(r['beta'] - beta) < 0.001]
            if r:
                if r[0]['no_def_honest'] > 0.0001:
                    gain = ((r[0]['erm_honest'] - r[0]['no_def_honest']) / r[0]['no_def_honest']) * 100
                else:
                    gain = 0.0
                row += f" {gain:>13.1f}%"
        print(row)


def save_csv(results, beta):
    csv_out = os.path.join(os.path.dirname(__file__), "Result", f"multi_attack_results_beta{beta}.csv")
    fields = ['attack', 'beta', 'alpha',
              'no_def_att', 'no_def_agent', 'no_def_honest',
              'erm_att', 'erm_agent', 'erm_honest']
    with open(csv_out, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(results)
    print(f"\nResults saved to: {csv_out}")


# ============================================================
# Main
# ============================================================
if __name__ == '__main__':
    random.seed(42)

    for beta in BETAS:
        print("\n" + "=" * 100)
        print(f"RUNNING MULTI-ATTACK EXPERIMENTS FOR BETA = {beta}")
        print(f"({len(ALPHAS)} alpha values x 6 attack types, gamma={GAMMA}, {TRIALS} trials each)")
        print("=" * 100)

        results = run_experiment(beta)
        print_tables(results, beta)
        save_csv(results, beta)
