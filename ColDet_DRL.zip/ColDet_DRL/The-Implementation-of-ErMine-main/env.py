import numpy as np

class Environment:

    def __init__(self, total_rounds, attacker_power, agent_power, follower_fraction, cost=0, max_hidden_block = 20, rule = "longest"):
        self.round = 0  # 初始回合为0
        self.total_rounds = total_rounds
        self.illegal_action_count = 0

        self.alpha = attacker_power
        self.beta = agent_power
        self.gamma = follower_fraction

        self.total_valid_blocks = 0
        self.agent_valid_blocks = 0
        self.attacker_valid_blocks = 0

        self.current_alpha = self.alpha
        self.current_beta = self.beta

        self.rule = rule
        self.cost = cost

        self.state_vector_n = 4
        self.action_space_n = 4
        self.action_space = np.arange(0,4)

        self.act_stop_count = 0

        # Fork rate & confirmation metrics
        self.fork_events = 0
        self.attacker_won_forks = 0
        self.honest_blocks_mined = 0
        self.honest_blocks_orphaned = 0
        self._current_fork_attacker_won = False

        # POMDP: 分离全局真实状态和智能体观测状态
        self.global_true_state = (0, 0, 0, 0) # (a, h, pending, fork)
        self.agent_observed_state = (0, 0, 0, 0) # (o_a, o_h, o_pending, o_fork)

    def reset(self):
        self.current_alpha = self.alpha
        self.current_beta = self.beta
        self.global_true_state = (0, 0, 0, 0)
        self.agent_observed_state = (0, 0, 0, 0)
        self.round = 0  # 重置回合数

        self.illegal_action_count = 0
        self.total_valid_blocks = 0
        self.agent_valid_blocks = 0
        self.attacker_valid_blocks = 0
        self.act_stop_count = 0
        self.fork_events = 0
        self.attacker_won_forks = 0
        self.honest_blocks_mined = 0
        self.honest_blocks_orphaned = 0
        self._current_fork_attacker_won = False

        return self.agent_observed_state

    def step(self, observed_state, action):
        old_fork_true = self.global_true_state[3]
        old_attacker_blocks = self.attacker_valid_blocks
        result = self.step_imp(observed_state, action)
        if result is None:
            print(f"Warning: step_imp returned None for action {action} in state {observed_state}")
            return observed_state, -10000, False, -1

        next_state, reward, done, event = result
        if event >= 0:
            new_fork_true = self.global_true_state[3]
            # Fork starts
            if new_fork_true != 0 and old_fork_true == 0:
                self.fork_events += 1
                self._current_fork_attacker_won = False
            # Attacker wins blocks during an active fork
            if old_fork_true != 0:
                if self.attacker_valid_blocks > old_attacker_blocks and not self._current_fork_attacker_won:
                    self.attacker_won_forks += 1
                    self._current_fork_attacker_won = True
            # Track honest blocks mined (event semantics differ per action)
            if action in (0, 1) and event in (1, 2):
                self.honest_blocks_mined += 1
            elif action in (2, 3) and event in (2, 3):
                self.honest_blocks_mined += 1
        return result

    def step_imp(self, observed_state, action):
        # --- 关键修复：在函数开头就更新回合数和检查是否结束 ---
        self.round += 1
        done = self.round >= self.total_rounds
        if done:
            # 如果回合结束，直接返回，不执行任何挖矿逻辑
            return observed_state, 0, done, -1 # 返回一个中性的奖励和事件
        # --- 修复结束 ---

        a_true, h_true, pending_true, fork_true = self.global_true_state
        o_a, o_h, o_pending, o_fork = observed_state

        next_observed_state = observed_state
        reward = -1
        event = -1

        if fork_true == 0:
            if a_true == 0 and h_true == 0:
                if action == 0:
                    prob_arr = [self.current_alpha, self.current_beta, 1 - self.current_alpha - self.current_beta]
                    mining_event = np.random.choice([0,1,2], p=prob_arr)
                    event = mining_event
                    if mining_event == 0:
                        self.global_true_state = (1, 0, 0, 2)
                        next_observed_state = (0, 0, 0, 0)
                        reward = 0 - (self.current_beta * self.cost)
                    elif mining_event == 1:
                        self.global_true_state = (0, 1, 1, 0)
                        next_observed_state = (0, 1, 1, 0)
                        reward = 1 - (self.current_beta * self.cost)
                        self.agent_valid_blocks += 1
                        self.total_valid_blocks += 1
                    else:
                        self.global_true_state = (0, 1, 0, 0)
                        next_observed_state = (0, 1, 0, 0)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += 1
                    return next_observed_state, reward, done, event

                elif action == 1:
                    self.act_stop_count += 1
                    prob_arr = [self.current_alpha/(1- self.current_beta), (1 - self.current_alpha - self.current_beta)/(1- self.current_beta)]
                    mining_event = np.random.choice([0, 1], p=prob_arr)
                    event = mining_event
                    if mining_event == 0:
                        self.global_true_state = (1, 0, 0, 2)
                        next_observed_state = (0, 0, 0, 0)
                        reward = 0
                    else:
                        self.global_true_state = (0, 1, 0, 0)
                        next_observed_state = (0, 1, 0, 0)
                        reward = 0
                        self.total_valid_blocks += 1
                    return next_observed_state, reward, done, event

                else:
                    reward = -10000
                    self.illegal_action_count += 1
                    return observed_state, reward, done, event

            elif h_true > 0:
                if action == 0:
                    prob_arr = [self.current_alpha, self.current_beta, 1 - self.current_alpha - self.current_beta]
                    mining_event = np.random.choice([0,1,2], p=prob_arr)
                    event = mining_event
                    if mining_event == 0:
                        self.global_true_state = (a_true + 1, h_true, pending_true, 2)
                        next_observed_state = (o_a, o_h, o_pending, 0)
                        reward = 0 - (self.current_beta * self.cost)
                    elif mining_event == 1:
                        self.global_true_state = (a_true, h_true + 1, pending_true + 1, 0)
                        next_observed_state = (o_a, o_h + 1, o_pending + 1, 0)
                        reward = 1 - (self.current_beta * self.cost)
                        self.agent_valid_blocks += 1
                        self.total_valid_blocks += 1
                    else:
                        self.global_true_state = (a_true, h_true + 1, pending_true, 0)
                        next_observed_state = (o_a, o_h + 1, o_pending, 0)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += 1
                    return next_observed_state, reward, done, event

                elif action == 1:
                    self.act_stop_count += 1
                    prob_arr = [self.current_alpha/(1- self.current_beta), (1 - self.current_alpha - self.current_beta)/(1- self.current_beta)]
                    mining_event = np.random.choice([0, 1], p=prob_arr)
                    event = mining_event
                    if mining_event == 0:
                        self.global_true_state = (a_true + 1, h_true, pending_true, 2)
                        next_observed_state = observed_state
                        reward = 0
                    else:
                        self.global_true_state = (a_true, h_true + 1, pending_true, 0)
                        next_observed_state = (o_a, o_h + 1, o_pending, 0)
                        reward = 0
                        self.total_valid_blocks += 1
                    return next_observed_state, reward, done, event

                else:
                    reward = -10000
                    self.illegal_action_count += 1
                    return observed_state, reward, done, event

        elif fork_true == 2:
            if a_true == 1:
                if action == 0:
                    prob_arr = [self.current_alpha, self.current_beta, 1 - self.current_alpha - self.current_beta]
                    mining_event = np.random.choice([0,1,2], p=prob_arr)
                    event = mining_event
                    if mining_event == 0:
                        self.global_true_state = (2, h_true, pending_true, 2)
                        next_observed_state = observed_state
                        reward = 0 - (self.current_beta * self.cost)
                    elif mining_event == 1:
                        self.global_true_state = (1, 1, 1, 1)
                        next_observed_state = (1, 1, 1, 1)
                        reward = 0 - (self.current_beta * self.cost)
                    else:
                        self.global_true_state = (1, 1, 0, 1)
                        next_observed_state = (1, 1, 0, 1)
                        reward = 0 - (self.current_beta * self.cost)
                    return next_observed_state, reward, done, event

                elif action == 1:
                    self.act_stop_count += 1
                    prob_arr = [self.current_alpha/(1- self.current_beta), (1 - self.current_alpha - self.current_beta)/(1- self.current_beta)]
                    mining_event = np.random.choice([0, 1], p=prob_arr)
                    event = mining_event
                    if mining_event == 0:
                        self.global_true_state = (2, h_true, pending_true, 2)
                        next_observed_state = observed_state
                        reward = 0
                    else:
                        self.global_true_state = (1, 1, 0, 1)
                        next_observed_state = (1, 1, 0, 1)
                        reward = 0
                    return next_observed_state, reward, done, event

                else:
                    reward = -10000
                    self.illegal_action_count += 1
                    return observed_state, reward, done, event

            elif a_true >= 2:
                if action == 0:
                    prob_arr = [self.current_alpha, self.current_beta, 1 - self.current_alpha - self.current_beta]
                    mining_event = np.random.choice([0,1,2], p=prob_arr)
                    event = mining_event
                    if mining_event == 0:
                        self.global_true_state = (a_true + 1, h_true, pending_true, 2)
                        next_observed_state = observed_state
                        reward = 0 - (self.current_beta * self.cost)
                    elif mining_event == 1:
                        self.global_true_state = (a_true, h_true + 1, pending_true + 1, 2)
                        next_observed_state = (o_a, o_h + 1, o_pending + 1, 0)
                        reward = 1 - (self.current_beta * self.cost)
                        self.agent_valid_blocks += 1
                        self.total_valid_blocks += 1
                    else:
                        self.global_true_state = (a_true, h_true + 1, pending_true, 2)
                        next_observed_state = (o_a, o_h + 1, o_pending, 0)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += 1
                    return next_observed_state, reward, done, event

                elif action == 1:
                    self.act_stop_count += 1
                    prob_arr = [self.current_alpha/(1- self.current_beta), (1 - self.current_alpha - self.current_beta)/(1- self.current_beta)]
                    mining_event = np.random.choice([0, 1], p=prob_arr)
                    event = mining_event
                    if mining_event == 0:
                        self.global_true_state = (a_true + 1, h_true, pending_true, 2)
                        next_observed_state = observed_state
                        reward = 0
                    else:
                        self.global_true_state = (a_true, h_true + 1, pending_true, 2)
                        next_observed_state = (o_a, o_h + 1, o_pending, 0)
                        reward = 0
                        self.total_valid_blocks += 1
                    return next_observed_state, reward, done, event

                else:
                    reward = -10000
                    self.illegal_action_count += 1
                    return observed_state, reward, done, event

        elif fork_true == 1:
            if action == 1:
                self.act_stop_count += 1
                prob_arr = [self.current_alpha/(1- self.current_beta),
                            ((1 - self.current_alpha - self.current_beta)/(1- self.current_beta))*self.gamma,
                            ((1 - self.current_alpha - self.current_beta)/(1- self.current_beta))*(1 - self.gamma)]
                mining_event = np.random.choice([0, 1, 2], p=prob_arr)
                event = mining_event
                if mining_event == 0:
                    self.global_true_state = (a_true+1, h_true, pending_true, fork_true)
                    observed_state_new = observed_state
                    reward = 0
                elif mining_event == 1:
                    if((a_true-h_true-1) == 0):
                        self.global_true_state = ( 1, 1, 0, 1)
                        observed_state_new = (1, 1, 0, 1)
                        reward = 0
                        self.total_valid_blocks += h_true
                        self.attacker_valid_blocks += h_true
                    elif((a_true-h_true-1) == 1):
                        self.global_true_state = (0, 0, 0, 0)
                        observed_state_new = (0, 0, 0, 0)
                        reward = 0
                        self.total_valid_blocks += a_true
                        self.attacker_valid_blocks += a_true
                    else:
                        self.global_true_state = (a_true-h_true, 1, 0, 2)
                        observed_state_new = (1, 1, 0, 1)
                        reward = 0
                        self.total_valid_blocks += h_true
                        self.attacker_valid_blocks += h_true
                else:
                    if ((a_true - h_true - 1) == 0):
                        self.global_true_state = (h_true+1, h_true+1, pending_true, 1)
                        observed_state_new = (h_true+1,  h_true+1, pending_true, 1)
                        reward = 0
                    elif ((a_true - h_true - 1) == 1):
                        self.global_true_state = (0, 0, 0, 0)
                        observed_state_new = (0, 0, 0, 0)
                        reward = 0
                        self.total_valid_blocks += a_true
                        self.attacker_valid_blocks += a_true
                    else:
                        self.global_true_state = (a_true, h_true+1, pending_true, 2)
                        observed_state_new = (h_true+1, h_true+1, o_pending, 1)
                        reward = 0
                return observed_state_new, reward, done, event

            elif action == 2:
                prob_arr = [self.current_alpha, self.current_beta, (1 - self.current_alpha - self.current_beta) * self.gamma,
                            (1 - self.current_alpha - self.current_beta) * (1 - self.gamma)]
                mining_event = np.random.choice([0, 1, 2, 3], p=prob_arr)
                event = mining_event
                if(mining_event == 0):
                    self.global_true_state = (a_true + 1, h_true, pending_true, fork_true)
                    observed_state_new = observed_state
                    reward = 0 - (self.current_beta * self.cost)
                elif(mining_event == 1):
                    if ((a_true - h_true - 1) == 0):
                        self.global_true_state = (1, 1, 1, 1)
                        observed_state_new = (1, 1, 1, 1)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += h_true
                        self.attacker_valid_blocks += h_true
                    elif ((a_true - h_true - 1) == 1):
                        self.global_true_state = (0, 0, 0, 0)
                        observed_state_new = (0, 0, 0, 0)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += a_true
                        self.attacker_valid_blocks += a_true
                    else:
                        self.global_true_state = (a_true - h_true, 1, 1, 2)
                        observed_state_new = (1, 1, 1, 1)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += h_true
                        self.attacker_valid_blocks += h_true
                elif(mining_event == 2):
                    if ((a_true - h_true - 1) == 0):
                        self.global_true_state = (1, 1, 0, 1)
                        observed_state_new = (1, 1, 0, 1)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += h_true
                        self.attacker_valid_blocks += h_true
                    elif ((a_true - h_true - 1) == 1):
                        self.global_true_state = (0, 0, 0, 0)
                        observed_state_new = (0, 0, 0, 0)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += a_true
                        self.attacker_valid_blocks += a_true
                    else:
                        self.global_true_state = (a_true - h_true, 1, 0, 2)
                        observed_state_new = (1, 1, 0, 1)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += h_true
                        self.attacker_valid_blocks += h_true
                else:
                    if ((a_true - h_true - 1) == 0):
                        self.global_true_state = (h_true + 1, h_true + 1, pending_true, 1)
                        observed_state_new = (h_true + 1, h_true + 1, pending_true, 1)
                        reward = 0 - (self.current_beta * self.cost)
                    elif ((a_true - h_true - 1) == 1):
                        self.global_true_state = (0, 0, 0, 0)
                        observed_state_new = (0, 0, 0, 0)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += a_true
                        self.attacker_valid_blocks += a_true
                    else:
                        self.global_true_state = (a_true, h_true + 1, pending_true, 2)
                        observed_state_new = (h_true + 1, h_true + 1, o_pending, 1)
                        reward = 0 - (self.current_beta * self.cost)
                return observed_state_new, reward, done, event

            elif action == 3:
                prob_arr = [self.current_alpha, self.current_beta,
                            (1 - self.current_alpha - self.current_beta) * self.gamma,
                            (1 - self.current_alpha - self.current_beta) * (1 - self.gamma)]
                mining_event = np.random.choice([0, 1, 2, 3], p=prob_arr)
                event = mining_event
                if(mining_event == 0):
                    self.global_true_state = (a_true + 1, h_true, pending_true, fork_true)
                    observed_state_new = observed_state
                    reward = 0 - (self.current_beta * self.cost)
                elif(mining_event == 1):
                    if ((a_true - h_true - 1) == 0):
                        self.global_true_state = (a_true, a_true, pending_true+1, 1)
                        observed_state_new = (a_true, a_true, pending_true+1, 1)
                        reward = 0 - (self.current_beta * self.cost)
                    elif ((a_true - h_true - 1) == 1):
                        self.global_true_state = (0, 0, 0, 0)
                        observed_state_new = (0, 0, 0, 0)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += a_true
                        self.attacker_valid_blocks += a_true
                    else:
                        self.global_true_state = (a_true, h_true+1, pending_true+1, 2)
                        observed_state_new = (h_true+1, h_true+1, pending_true+1, 1)
                        reward = 0 - (self.current_beta * self.cost)
                elif(mining_event == 2):
                    if ((a_true - h_true - 1) == 0):
                        self.global_true_state = (1, 1, 0, 1)
                        observed_state_new = (1, 1, 0, 1)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += h_true
                        self.attacker_valid_blocks += h_true
                    elif ((a_true - h_true - 1) == 1):
                        self.global_true_state = (0, 0, 0, 0)
                        observed_state_new = (0, 0, 0, 0)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += a_true
                        self.attacker_valid_blocks += a_true
                    else:
                        self.global_true_state = (a_true - h_true, 1, 0, 2)
                        observed_state_new = (1, 1, 0, 1)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += h_true
                        self.attacker_valid_blocks += h_true
                else:
                    if ((a_true - h_true - 1) == 0):
                        self.global_true_state = (h_true + 1, h_true + 1, pending_true, 1)
                        observed_state_new = (h_true + 1, h_true + 1, pending_true, 1)
                        reward = 0 - (self.current_beta * self.cost)
                    elif ((a_true - h_true - 1) == 1):
                        self.global_true_state = (0, 0, 0, 0)
                        observed_state_new = (0, 0, 0, 0)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += a_true
                        self.attacker_valid_blocks += a_true
                    else:
                        self.global_true_state = (a_true, h_true + 1, pending_true, 2)
                        observed_state_new = (h_true + 1, h_true + 1, o_pending, 1)
                        reward = 0 - (self.current_beta * self.cost)
                return observed_state_new, reward, done, event

            else:
                reward = -10000
                self.illegal_action_count +=1
                return observed_state, reward, done, event

        # 如果所有 fork_true 条件都不满足（理论上不可能），提供一个保底返回
        return next_observed_state, reward, done, event

    def get_fork_rate(self):
        """Return attacker fork success rate = attacker_won_forks / fork_events."""
        if self.fork_events == 0:
            return 0.0
        return self.attacker_won_forks / self.fork_events

    def get_honest_survival_rate(self):
        """Return honest block survival rate. Capped at 1.0."""
        if self.total_valid_blocks == 0:
            return 1.0
        honest_confirmed = max(0, self.total_valid_blocks - self.agent_valid_blocks - self.attacker_valid_blocks)
        if self.honest_blocks_mined == 0:
            return 1.0
        return min(1.0, max(0.0, honest_confirmed / self.honest_blocks_mined))

    def get_fork_metrics(self):
        """Return (attacker_fork_success_rate, honest_survival_rate)."""
        return self.get_fork_rate(), self.get_honest_survival_rate()