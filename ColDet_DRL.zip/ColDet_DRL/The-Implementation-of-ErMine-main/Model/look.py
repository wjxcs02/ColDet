import numpy as np


class Environment:
    def __init__(self, total_rounds, attacker_power, agent_power, follower_fraction, cost=0, max_hidden_block=20, rule="longest"):
        self.round = 0  # 当前轮次
        self.total_rounds = total_rounds  # 单episode总轮次
        self.illegal_action_count = 0

        self.alpha = attacker_power  # 攻击者算力（α）
        self.beta = agent_power  # 智能体算力（β）
        self.gamma = follower_fraction  # 诚实节点追随者比例（γ）

        self.total_valid_blocks = 0  # 总有效区块数
        self.agent_valid_blocks = 0  # 智能体挖出的有效区块数
        self.attacker_valid_blocks = 0  # 攻击者挖出的有效区块数

        self.current_alpha = self.alpha  # 攻击者当前算力
        self.current_beta = self.beta  # 智能体当前算力

        self.rule = rule  # 共识规则（默认最长链）
        self.cost = cost  # 挖矿成本因子（λ）

        self.state_vector_n = 4  # 智能体观测状态维度（部分可观测）
        self.action_space_n = 4  # 动作空间维度：0=挖矿，1=停止，2=跟随攻击者链，3=跟随诚实链
        self.action_space = np.arange(0, 4)

        self.act_stop_count = 0  # 停止动作执行次数

        # -------------------------- POMDP核心改造：分离全局状态与观测状态 --------------------------
        # 1. 全局真实状态（智能体不可直接观测，包含隐藏信息）
        # 结构：(攻击者私有链长度a, 公开诚实链长度h, 智能体待确认区块数pending, 网络状态fork)
        # fork含义：0=无分叉，1=公开分叉，2=攻击者私有分叉（智能体未知）
        self.global_true_state = (0, 0, 0, 0)

        # 2. 智能体观测状态（部分可观测，不含隐藏信息）
        # 结构：(观测到的分叉链长度o_a, 观测到的主链长度o_h, 待确认区块数o_pending, 观测到的分叉状态o_fork)
        # o_fork含义：0=无分叉，1=公开分叉（仅能观测到公开分叉，无法观测攻击者私有分叉）
        self.agent_observed_state = (0, 0, 0, 0)

    def reset(self):
        '''重置环境，恢复全局真实状态和智能体观测状态'''
        self.current_alpha = self.alpha
        self.current_beta = self.beta
        self.global_true_state = (0, 0, 0, 0)  # 全局状态重置
        self.agent_observed_state = (0, 0, 0, 0)  # 观测状态重置
        self.round = 0

        self.illegal_action_count = 0
        self.total_valid_blocks = 0
        self.agent_valid_blocks = 0
        self.attacker_valid_blocks = 0
        self.act_stop_count = 0

        return self.agent_observed_state  # 仅返回观测状态，不暴露全局真实状态

    def step(self, observed_state, action):
        '''
        执行动作并转移状态（POMDP核心逻辑）
        :param observed_state: 智能体的观测状态（而非全局真实状态）
        :param action: 智能体选择的动作
        :return: next_observed_state（下一个观测状态）, reward（即时奖励）, done（结束标志）, event（事件信息）
        '''
        next_observed_state, reward, done, event = self.step_imp(observed_state, action)
        return next_observed_state, reward, done, event

    def step_imp(self, observed_state, action):
        # 解包全局真实状态（智能体不可见）
        a_true, h_true, pending_true, fork_true = self.global_true_state
        # 解包智能体观测状态（智能体可见）
        o_a, o_h, o_pending, o_fork = observed_state

        # 初始化返回值
        next_observed_state = observed_state  # 默认观测状态不变
        reward = -1
        done = False
        event = -1

        # -------------------------- 场景1：全局真实状态无分叉（fork_true=0） --------------------------
        if fork_true == 0:
            # 子场景1.1：攻击者私有链和公开链长度均为0（初始状态）
            if a_true == 0 and h_true == 0:
                # 合法动作：0=挖矿，1=停止（其他动作非法）
                if action == 0:  # 智能体选择挖矿
                    # 算力分配：攻击者α，智能体β，其他诚实节点1-α-β
                    prob_arr = [self.current_alpha, self.current_beta, 1 - self.current_alpha - self.current_beta]
                    mining_event = np.random.choice([0, 1, 2], p=prob_arr)
                    event = mining_event

                    if mining_event == 0:  # 攻击者挖矿成功（隐藏私有链）
                        self.global_true_state = (1, 0, 0, 2)  # fork_true=2（私有分叉，智能体不可见）
                        next_observed_state = (0, 0, 0, 0)  # 观测状态无变化（未察觉私有分叉）
                        reward = 0 - (self.current_beta * self.cost)  # 挖矿成本

                    elif mining_event == 1:  # 智能体挖矿成功（公开链）
                        self.global_true_state = (0, 1, 1, 0)  # 公开链长度+1，待确认区块+1
                        next_observed_state = (0, 1, 1, 0)  # 观测状态同步更新
                        reward = 1 - (self.current_beta * self.cost)  # 区块奖励-成本
                        self.agent_valid_blocks += 1
                        self.total_valid_blocks += 1

                    else:  # 其他诚实节点挖矿成功（公开链）
                        self.global_true_state = (0, 1, 0, 0)  # 公开链长度+1
                        next_observed_state = (0, 1, 0, 0)  # 观测状态同步更新
                        reward = 0 - (self.current_beta * self.cost)  # 仅成本无奖励
                        self.total_valid_blocks += 1

                elif action == 1:  # 智能体选择停止挖矿
                    self.act_stop_count += 1
                    # 算力重新分配（排除智能体β）
                    prob_arr = [self.current_alpha/(1 - self.current_beta),
                                (1 - self.current_alpha - self.current_beta)/(1 - self.current_beta)]
                    mining_event = np.random.choice([0, 1], p=prob_arr)
                    event = mining_event

                    if mining_event == 0:  # 攻击者挖矿成功（私有链）
                        self.global_true_state = (1, 0, 0, 2)
                        next_observed_state = (0, 0, 0, 0)  # 观测不到私有分叉
                        reward = 0  # 无成本无奖励

                    else:  # 其他诚实节点挖矿成功（公开链）
                        self.global_true_state = (0, 1, 0, 0)
                        next_observed_state = (0, 1, 0, 0)
                        reward = 0
                        self.total_valid_blocks += 1

                else:  # 非法动作（跟随动作在无分叉时无效）
                    reward = -10000
                    self.illegal_action_count += 1
                    return observed_state, reward, done, event

            # 子场景1.2：公开链已存在（h_true > 0，无分叉）
            elif h_true > 0:
                if action == 0:  # 智能体挖矿
                    prob_arr = [self.current_alpha, self.current_beta, 1 - self.current_alpha - self.current_beta]
                    mining_event = np.random.choice([0, 1, 2], p=prob_arr)
                    event = mining_event

                    if mining_event == 0:  # 攻击者挖矿成功（延长私有链）
                        self.global_true_state = (a_true + 1, h_true, pending_true, 2)
                        next_observed_state = (o_a, o_h, o_pending, 0)  # 观测无变化
                        reward = 0 - (self.current_beta * self.cost)

                    elif mining_event == 1:  # 智能体挖矿成功（延长公开链）
                        self.global_true_state = (a_true, h_true + 1, pending_true + 1, 0)
                        next_observed_state = (o_a, o_h + 1, o_pending + 1, 0)  # 观测同步更新
                        reward = 1 - (self.current_beta * self.cost)
                        self.agent_valid_blocks += 1
                        self.total_valid_blocks += 1

                    else:  # 其他诚实节点挖矿成功（延长公开链）
                        self.global_true_state = (a_true, h_true + 1, pending_true, 0)
                        next_observed_state = (o_a, o_h + 1, o_pending, 0)  # 观测同步更新
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += 1

                elif action == 1:  # 智能体停止挖矿
                    self.act_stop_count += 1
                    prob_arr = [self.current_alpha/(1 - self.current_beta),
                                (1 - self.current_alpha - self.current_beta)/(1 - self.current_beta)]
                    mining_event = np.random.choice([0, 1], p=prob_arr)
                    event = mining_event

                    if mining_event == 0:  # 攻击者挖矿成功（私有链）
                        self.global_true_state = (a_true + 1, h_true, pending_true, 2)
                        next_observed_state = observed_state
                        reward = 0

                    else:  # 其他诚实节点挖矿成功（公开链）
                        self.global_true_state = (a_true, h_true + 1, pending_true, 0)
                        next_observed_state = (o_a, o_h + 1, o_pending, 0)
                        reward = 0
                        self.total_valid_blocks += 1

                else:  # 非法动作（无分叉时无法跟随）
                    reward = -10000
                    self.illegal_action_count += 1
                    return observed_state, reward, done, event

        # -------------------------- 场景2：攻击者私有分叉（fork_true=2，智能体不可观测） --------------------------
        elif fork_true == 2:
            # 子场景2.1：攻击者私有链长度=1（a_true=1）
            if a_true == 1:
                if action == 0:  # 智能体挖矿
                    prob_arr = [self.current_alpha, self.current_beta, 1 - self.current_alpha - self.current_beta]
                    mining_event = np.random.choice([0, 1, 2], p=prob_arr)
                    event = mining_event

                    if mining_event == 0:  # 攻击者挖矿成功（私有链长度=2）
                        self.global_true_state = (2, h_true, pending_true, 2)
                        next_observed_state = observed_state  # 观测无变化
                        reward = 0 - (self.current_beta * self.cost)

                    elif mining_event == 1:  # 智能体挖矿成功（公开链长度=1，触发公开分叉）
                        self.global_true_state = (1, 1, 1, 1)  # fork_true=1（公开分叉，智能体可观测）
                        next_observed_state = (1, 1, 1, 1)  # 观测状态更新为公开分叉
                        reward = 0 - (self.current_beta * self.cost)

                    else:  # 其他诚实节点挖矿成功（公开链长度=1，触发公开分叉）
                        self.global_true_state = (1, 1, 0, 1)
                        next_observed_state = (1, 1, 0, 1)
                        reward = 0 - (self.current_beta * self.cost)

                elif action == 1:  # 智能体停止挖矿
                    self.act_stop_count += 1
                    prob_arr = [self.current_alpha/(1 - self.current_beta),
                                (1 - self.current_alpha - self.current_beta)/(1 - self.current_beta)]
                    mining_event = np.random.choice([0, 1], p=prob_arr)
                    event = mining_event

                    if mining_event == 0:  # 攻击者挖矿成功（私有链长度=2）
                        self.global_true_state = (2, h_true, pending_true, 2)
                        next_observed_state = observed_state
                        reward = 0

                    else:  # 其他诚实节点挖矿成功（公开链长度=1，公开分叉）
                        self.global_true_state = (1, 1, 0, 1)
                        next_observed_state = (1, 1, 0, 1)
                        reward = 0

                else:  # 非法动作（未观测到分叉，无法跟随）
                    reward = -10000
                    self.illegal_action_count += 1
                    return observed_state, reward, done, event

            # 子场景2.2：攻击者私有链长度≥2（a_true≥2）
            elif a_true >= 2:
                if action == 0:  # 智能体挖矿
                    prob_arr = [self.current_alpha, self.current_beta, 1 - self.current_alpha - self.current_beta]
                    mining_event = np.random.choice([0, 1, 2], p=prob_arr)
                    event = mining_event

                    if mining_event == 0:  # 攻击者挖矿成功（延长私有链）
                        self.global_true_state = (a_true + 1, h_true, pending_true, 2)
                        next_observed_state = observed_state
                        reward = 0 - (self.current_beta * self.cost)

                    elif mining_event == 1:  # 智能体挖矿成功（公开链长度+1）
                        self.global_true_state = (a_true, h_true + 1, pending_true + 1, 2)
                        next_observed_state = (o_a, o_h + 1, o_pending + 1, 0)
                        reward = 1 - (self.current_beta * self.cost)
                        self.agent_valid_blocks += 1
                        self.total_valid_blocks += 1

                    else:  # 其他诚实节点挖矿成功（公开链长度+1）
                        self.global_true_state = (a_true, h_true + 1, pending_true, 2)
                        next_observed_state = (o_a, o_h + 1, o_pending, 0)
                        reward = 0 - (self.current_beta * self.cost)
                        self.total_valid_blocks += 1

                elif action == 1:  # 智能体停止挖矿
                    self.act_stop_count += 1
                    prob_arr = [self.current_alpha/(1 - self.current_beta),
                                (1 - self.current_alpha - self.current_beta)/(1 - self.current_beta)]
                    mining_event = np.random.choice([0, 1], p=prob_arr)
                    event = mining_event

                    if mining_event == 0:  # 攻击者挖矿成功（延长私有链）
                        self.global_true_state = (a_true + 1, h_true, pending_true, 2)
                        next_observed_state = observed_state
                        reward = 0

                    else:  # 其他诚实节点挖矿成功（公开链长度+1）
                        self.global_true_state = (a_true, h_true + 1, pending_true, 2)
                        next_observed_state = (o_a, o_h + 1, o_pending, 0)
                        reward = 0
                        self.total_valid_blocks += 1

                else:  # 非法动作
                    reward = -10000
                    self.illegal_action_count += 1
                    return observed_state, reward, done, event

        # -------------------------- 场景3：公开分叉（fork_true=1，智能体可观测） --------------------------
        elif fork_true == 1:
            # 仅合法动作：1=停止，2=跟随攻击者链，3=跟随诚实链（挖矿动作非法）
            if action == 1:  # 智能体停止挖矿
                self.act_stop_count += 1
                # 算力分配：攻击者α/(1-β)，诚实节点跟随攻击者γ，诚实节点跟随诚实链(1-γ)
                prob_arr = [self.current_alpha/(1 - self.current_beta),
                            ((1 - self.current_alpha - self.current_beta)/(1 - self.current_beta))*self.gamma,
                            ((1 - self.current_alpha - self.current_beta)/(1 - self.current_beta))*(1 - self.gamma)]
                mining_event = np.random.choice([0, 1, 2], p=prob_arr)
                event = mining_event
