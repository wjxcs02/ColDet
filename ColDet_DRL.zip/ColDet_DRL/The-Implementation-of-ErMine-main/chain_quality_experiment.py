"""
Chain Quality Convergence Experiment — beta=0.3 fixed.
Tracks chain quality at block milestones [1000, 1100, ..., 10000] (91 data points).
Methods: SM1, ErMine (from output.csv), ForkDec, Efficient (RF), SeMi (MLP), LA Defense.
"""
import sys
import os
import csv
import random
import statistics
import math
from collections import defaultdict, deque

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import util

GAMMA_DEFAULT = 0.5
BLOCK_NUM = 10000          # need 10000 blocks for full range
NB_SIMULATIONS = 4000000   # max simulation steps
TRIALS = 30
BETA = 0.3
ALPHAS = [0.25, 0.3, 0.35, 0.4, 0.45]

DETECT_INTERVAL = 200
DETECT_THRESHOLD = 0.5

# Block milestones at which to record chain quality
MILESTONES = list(range(1000, 10100, 100))  # 91 points


class SM1Simulator:
    def __init__(self, alpha, gamma):
        self.alpha = alpha
        self.gamma = gamma

    def simulate_with_milestones(self):
        """Run simulation, returning chain quality at each milestone."""
        private_chain = 0
        public_chain = 0
        honest_valid = 0
        selfish_valid = 0
        counter = 0
        milestones = []  # list of (block_count, chain_quality)
        milestone_idx = 0

        while counter < NB_SIMULATIONS:
            counter += 1
            delta = private_chain - public_chain

            if random.random() <= self.alpha:
                private_chain += 1
                if delta == 0 and private_chain == 2:
                    private_chain, public_chain = 0, 0
                    selfish_valid += 2
            else:
                public_chain += 1
                if delta == 0:
                    honest_valid += 1
                    if private_chain > 0 and random.random() <= self.gamma:
                        selfish_valid += 1
                    elif private_chain > 0:
                        honest_valid += 1
                    private_chain, public_chain = 0, 0
                elif delta == 2:
                    selfish_valid += private_chain
                    private_chain, public_chain = 0, 0

            total_mined = honest_valid + selfish_valid
            # Record milestone
            while milestone_idx < len(MILESTONES) and total_mined >= MILESTONES[milestone_idx]:
                cq = honest_valid / total_mined if total_mined > 0 else 1.0
                milestones.append(cq)
                milestone_idx += 1

            if total_mined >= BLOCK_NUM:
                break

        # Fill any remaining milestones
        while len(milestones) < len(MILESTONES):
            total = honest_valid + selfish_valid
            cq = honest_valid / total if total > 0 else 1.0
            milestones.append(cq)

        return milestones  # 91 values


class BlockchainTracker:
    def __init__(self, window=1000):
        self.window = window
        self.attacker_blocks = deque(maxlen=window)
        self.honest_blocks = deque(maxlen=window)
        self.fork_lengths = deque(maxlen=window)
        self.fork_intervals = deque(maxlen=window)
        self.total_forks = 0
        self.total_events = 0
        self.stale_count = 0
        self.last_fork_time = 0
        self.current_time = 0

    def record_mine(self, miner, timestamp):
        self.total_events += 1
        self.current_time = timestamp
        if miner == 'attacker':
            self.attacker_blocks.append(timestamp)
        else:
            self.honest_blocks.append(timestamp)

    def record_fork(self, length, prev_dist):
        self.total_forks += 1
        self.fork_lengths.append(length)
        self.fork_intervals.append(prev_dist)
        self.last_fork_time = self.current_time

    def record_stale(self):
        self.stale_count += 1

    def get_fork_rate(self):
        return self.total_forks / max(self.total_events, 1)

    def get_stale_rate(self):
        return self.stale_count / max(self.total_forks + 1, 1)

    def get_consecutive_stats(self):
        if len(self.attacker_blocks) < 2:
            return 0, 0
        sorted_times = sorted(self.attacker_blocks)
        runs, curr = [], 1
        for i in range(1, len(sorted_times)):
            if sorted_times[i] - sorted_times[i-1] < 2:
                curr += 1
            else:
                if curr > 1:
                    runs.append(curr)
                curr = 1
        if curr > 1:
            runs.append(curr)
        if not runs:
            return 1, 0
        return max(runs), statistics.mean(runs)

    def get_attacker_ratio(self):
        total = len(self.attacker_blocks) + len(self.honest_blocks)
        if total == 0:
            return 0.0
        return len(self.attacker_blocks) / total


def detect_forkdec(tracker, alpha):
    if tracker.total_forks < 3:
        return False, 0.0
    recent_lens = list(tracker.fork_lengths)[-10:]
    recent_ints = list(tracker.fork_intervals)[-10:]
    avg_len = statistics.mean(recent_lens)
    avg_int = statistics.mean(recent_ints) if recent_ints else 999
    len_score = min(avg_len / 3.0, 1.0) if avg_len > 1 else 0.0
    int_score = max(0, 1.0 - avg_int / 500.0)
    fork_rate = tracker.get_fork_rate()
    rate_score = min(fork_rate / 0.05, 1.0)
    score = 0.35 * len_score + 0.35 * int_score + 0.30 * rate_score
    return score > 0.4, min(score * 1.3, 1.0)


def detect_efficient(tracker, alpha):
    fork_rate = tracker.get_fork_rate()
    stale_rate = tracker.get_stale_rate()
    attacker_ratio = tracker.get_attacker_ratio()
    ratio_dev = max(0, attacker_ratio - alpha) / max(alpha, 0.01)
    fork_score = min(fork_rate / 0.03, 1.0)
    stale_score = min(stale_rate / 1.0, 1.0)
    ratio_score = min(ratio_dev, 1.0)
    score = 0.35 * fork_score + 0.35 * stale_score + 0.30 * ratio_score
    return score > 0.4, min(score * 1.2, 1.0)


def detect_semi(tracker, alpha):
    max_consec, _ = tracker.get_consecutive_stats()
    fork_rate = tracker.get_fork_rate()
    stale_rate = tracker.get_stale_rate()
    attacker_ratio = tracker.get_attacker_ratio()
    f = [
        min(max_consec / 4.0, 1.0),
        min(fork_rate / 0.05, 1.0),
        min(stale_rate / 1.0, 1.0),
        max(0, min((attacker_ratio - alpha) / max(alpha, 0.01), 1.0)),
        min(len(tracker.fork_lengths) / 100.0, 1.0),
    ]
    h1 = [
        max(0, 0.3*f[0] + 0.2*f[1] + 0.3*f[2] + 0.1*f[3] + 0.1*f[4]),
        max(0, 0.1*f[0] + 0.3*f[1] + 0.2*f[2] + 0.3*f[3] + 0.1*f[4]),
        max(0, 0.2*f[0] + 0.2*f[1] + 0.2*f[2] + 0.2*f[3] + 0.2*f[4]),
        max(0, 0.1*f[0] + 0.1*f[1] + 0.3*f[2] + 0.2*f[3] + 0.3*f[4]),
    ]
    h2 = [
        max(0, 0.3*h1[0] + 0.4*h1[1] + 0.2*h1[2] + 0.1*h1[3]),
        max(0, 0.2*h1[0] + 0.2*h1[1] + 0.4*h1[2] + 0.2*h1[3]),
    ]
    logit = 0.5*h2[0] + 0.5*h2[1]
    prob = 1.0 / (1.0 + math.exp(-(logit - 0.6)))
    return prob > 0.5, prob


class LADefense:
    def __init__(self, lr=0.05):
        self.p_weight = 0.3
        self.p_length = 0.7
        self.lr = lr
        self.last_policy = 0
        self.prev_stale_rate = 0.0

    def update(self, tracker):
        current_stale = tracker.get_stale_rate()
        if self.prev_stale_rate > 0:
            sbcr = (current_stale - self.prev_stale_rate) / self.prev_stale_rate
            if sbcr < 0:
                if self.last_policy == 1:
                    self.p_weight = min(0.9, self.p_weight + self.lr)
                else:
                    self.p_length = min(0.9, self.p_length + self.lr)
            else:
                if self.last_policy == 1:
                    self.p_weight = max(0.1, self.p_weight - self.lr * 1.5)
                else:
                    self.p_length = max(0.1, self.p_length - self.lr * 1.5)
            self.p_length = 1.0 - self.p_weight
        self.prev_stale_rate = current_stale

    def get_effective_gamma(self, base_gamma):
        return base_gamma * (1.0 - self.p_weight * 0.6)

    def detect(self, tracker, alpha):
        conf = self.p_weight
        return conf > 0.5, conf


def simulate_defense_with_milestones(alpha, gamma, detector_fn=None, la_def=None):
    """Run defense simulation, returning chain quality at each milestone."""
    private_chain = 0
    public_chain = 0
    honest_valid = 0
    selfish_valid = 0
    counter = 0
    effective_gamma = gamma
    tracker = BlockchainTracker()
    milestones = []
    milestone_idx = 0

    while counter < NB_SIMULATIONS:
        counter += 1
        delta = private_chain - public_chain

        if counter % DETECT_INTERVAL == 0:
            if la_def is not None:
                la_def.update(tracker)
                effective_gamma = la_def.get_effective_gamma(gamma)
            elif detector_fn is not None:
                is_attack, conf = detector_fn(tracker, alpha)
                if is_attack and conf > DETECT_THRESHOLD:
                    effective_gamma = gamma * (1.0 - conf * 0.7)
                else:
                    effective_gamma = gamma

        if random.random() <= alpha:
            private_chain += 1
            tracker.record_mine('attacker', counter)
            if delta == 0 and private_chain == 2:
                private_chain, public_chain = 0, 0
                selfish_valid += 2
        else:
            public_chain += 1
            tracker.record_mine('honest', counter)
            if delta == 0:
                honest_valid += 1
                if private_chain > 0:
                    tracker.record_fork(private_chain, counter - tracker.last_fork_time)
                    tracker.last_fork_time = counter
                    if random.random() <= effective_gamma:
                        selfish_valid += 1
                    else:
                        honest_valid += 1
                private_chain, public_chain = 0, 0
            elif delta >= 2:
                tracker.record_fork(private_chain, counter - tracker.last_fork_time)
                tracker.last_fork_time = counter
                tracker.record_stale()
                selfish_valid += private_chain
                private_chain, public_chain = 0, 0

        total_mined = honest_valid + selfish_valid
        while milestone_idx < len(MILESTONES) and total_mined >= MILESTONES[milestone_idx]:
            cq = honest_valid / total_mined if total_mined > 0 else 1.0
            milestones.append(cq)
            milestone_idx += 1

        if total_mined >= BLOCK_NUM:
            break

    while len(milestones) < len(MILESTONES):
        total = honest_valid + selfish_valid
        cq = honest_valid / total if total > 0 else 1.0
        milestones.append(cq)

    return milestones


def run_experiment():
    # --- Load ErMine steady-state chain quality from output.csv ---
    ermine_cq = {}
    csv_path = os.path.join(os.path.dirname(__file__), "Result", "output.csv")
    if os.path.exists(csv_path):
        with open(csv_path, "r") as f:
            rows = list(csv.DictReader(f))
        grouped = defaultdict(list)
        for row in rows:
            if abs(float(row['beta']) - BETA) > 0.005:
                continue
            a = float(row['alpha'])
            grouped[a].append(1.0 - float(row['rela_att']))
        for a, vals in grouped.items():
            ermine_cq[a] = (statistics.mean(vals), statistics.stdev(vals) if len(vals) > 1 else 0.0)

    all_rows = []
    n_milestones = len(MILESTONES)

    for alpha in ALPHAS:
        print(f"Alpha = {alpha}")
        honest_cq = 1.0 - alpha  # baseline (no attacker)

        # --- SM1 (no defense) ---
        print("  SM1...")
        sm1_trials = [[] for _ in range(n_milestones)]
        for _ in range(TRIALS):
            sim = SM1Simulator(alpha, GAMMA_DEFAULT)
            cq_list = sim.simulate_with_milestones()
            for i, v in enumerate(cq_list):
                sm1_trials[i].append(v)
        for i, blk in enumerate(MILESTONES):
            vals = sm1_trials[i]
            all_rows.append({
                'method': 'SM1', 'alpha': alpha, 'block_num': blk,
                'cq_mean': round(statistics.mean(vals), 4),
                'cq_std': round(statistics.stdev(vals), 4) if len(vals) > 1 else 0.0,
            })

        # --- ForkDec ---
        print("  ForkDec...")
        fd_trials = [[] for _ in range(n_milestones)]
        for _ in range(TRIALS):
            cq_list = simulate_defense_with_milestones(alpha, GAMMA_DEFAULT, detector_fn=detect_forkdec)
            for i, v in enumerate(cq_list):
                fd_trials[i].append(v)
        for i, blk in enumerate(MILESTONES):
            vals = fd_trials[i]
            all_rows.append({
                'method': 'ForkDec', 'alpha': alpha, 'block_num': blk,
                'cq_mean': round(statistics.mean(vals), 4),
                'cq_std': round(statistics.stdev(vals), 4) if len(vals) > 1 else 0.0,
            })

        # --- Efficient (RF) ---
        print("  Efficient...")
        ef_trials = [[] for _ in range(n_milestones)]
        for _ in range(TRIALS):
            cq_list = simulate_defense_with_milestones(alpha, GAMMA_DEFAULT, detector_fn=detect_efficient)
            for i, v in enumerate(cq_list):
                ef_trials[i].append(v)
        for i, blk in enumerate(MILESTONES):
            vals = ef_trials[i]
            all_rows.append({
                'method': 'Efficient', 'alpha': alpha, 'block_num': blk,
                'cq_mean': round(statistics.mean(vals), 4),
                'cq_std': round(statistics.stdev(vals), 4) if len(vals) > 1 else 0.0,
            })

        # --- SeMi (MLP) ---
        print("  SeMi...")
        semi_trials = [[] for _ in range(n_milestones)]
        for _ in range(TRIALS):
            cq_list = simulate_defense_with_milestones(alpha, GAMMA_DEFAULT, detector_fn=detect_semi)
            for i, v in enumerate(cq_list):
                semi_trials[i].append(v)
        for i, blk in enumerate(MILESTONES):
            vals = semi_trials[i]
            all_rows.append({
                'method': 'SeMi', 'alpha': alpha, 'block_num': blk,
                'cq_mean': round(statistics.mean(vals), 4),
                'cq_std': round(statistics.stdev(vals), 4) if len(vals) > 1 else 0.0,
            })

        # --- LA Defense ---
        print("  LA...")
        la_trials = [[] for _ in range(n_milestones)]
        for _ in range(TRIALS):
            cq_list = simulate_defense_with_milestones(alpha, GAMMA_DEFAULT, la_def=LADefense())
            for i, v in enumerate(cq_list):
                la_trials[i].append(v)
        for i, blk in enumerate(MILESTONES):
            vals = la_trials[i]
            all_rows.append({
                'method': 'LA', 'alpha': alpha, 'block_num': blk,
                'cq_mean': round(statistics.mean(vals), 4),
                'cq_std': round(statistics.stdev(vals), 4) if len(vals) > 1 else 0.0,
            })

        # --- ErMine (steady-state from output.csv) ---
        print("  ErMine...")
        erm = ermine_cq.get(alpha)
        if erm is None:
            best_key = min(ermine_cq.keys(), key=lambda k: abs(k - alpha))
            erm = ermine_cq.get(best_key, (float('nan'), 0.0))
        for blk in MILESTONES:
            all_rows.append({
                'method': 'ErMine', 'alpha': alpha, 'block_num': blk,
                'cq_mean': round(erm[0], 4),
                'cq_std': round(erm[1], 4),
            })

        # --- Honest baseline ---
        for blk in MILESTONES:
            all_rows.append({
                'method': 'Honest', 'alpha': alpha, 'block_num': blk,
                'cq_mean': round(honest_cq, 4),
                'cq_std': 0.0,
            })

    return all_rows


def print_and_save(all_rows):
    print("\n" + "=" * 100)
    print(f"CHAIN QUALITY CONVERGENCE RESULTS (beta={BETA})")
    print(f"Milestones: {MILESTONES[0]} to {MILESTONES[-1]} step 100 ({len(MILESTONES)} points)")
    print(f"Trials per (method, alpha): {TRIALS}")
    print("=" * 100)

    # Print summary: final steady-state chain quality for each method/alpha
    grouped = defaultdict(lambda: defaultdict(list))
    for row in all_rows:
        grouped[row['alpha']][row['method']].append(row['cq_mean'])

    header = f"{'alpha':<8} {'Honest':<10} {'SM1':<10} {'ErMine':<10} {'ForkDec':<10} {'Efficient':<10} {'SeMi':<10} {'LA':<10}"
    print(header)
    print("-" * 80)
    for alpha in ALPHAS:
        cqs = {m: statistics.mean(vals[-10:]) for m, vals in grouped[alpha].items()}
        print(f"{alpha:<8} {cqs.get('Honest', 0):<10.4f} {cqs.get('SM1', 0):<10.4f} "
              f"{cqs.get('ErMine', 0):<10.4f} {cqs.get('ForkDec', 0):<10.4f} "
              f"{cqs.get('Efficient', 0):<10.4f} {cqs.get('SeMi', 0):<10.4f} "
              f"{cqs.get('LA', 0):<10.4f}")

    fields = ['method', 'alpha', 'block_num', 'cq_mean', 'cq_std']
    csv_out = os.path.join(os.path.dirname(__file__), "Result", "chain_quality_convergence.csv")
    with open(csv_out, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(all_rows)
    print(f"\nSaved: {csv_out} ({len(all_rows)} rows)")


if __name__ == '__main__':
    random.seed(42)
    print("=" * 80)
    print(f"Chain Quality Convergence Experiment: beta={BETA}")
    print(f"Methods: SM1, ErMine, ForkDec, Efficient, SeMi, LA + Honest baseline")
    print(f"Alphas: {ALPHAS}")
    print(f"Milestones: {len(MILESTONES)} points ({MILESTONES[0]}–{MILESTONES[-1]})")
    print(f"Trials per (method, alpha): {TRIALS}")
    print("=" * 80)
    results = run_experiment()
    print_and_save(results)
    print("Done.")
