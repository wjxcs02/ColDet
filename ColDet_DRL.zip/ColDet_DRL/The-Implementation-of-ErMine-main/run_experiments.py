"""
Comprehensive experiment script for ErMine project.
Compares revenue of rational miners, malicious miners, and honest miners
across different strategies: Honest Mining, SM1 (Selfish Mining), ErMine (DRQN), Theoretical.
"""
import sys
import os
import csv
import statistics
import numpy as np
from collections import defaultdict

# Add project path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from env import Environment
import util

# ============================================================
# Configuration
# ============================================================
GAMMA = 0.5          # follow fraction
TOTAL_ROUNDS = 10000
BLOCK_NUM = 5000
SM1_SIMULATIONS = 500000  # reduced for speed, increase for accuracy
SM1_TRIALS = 20     # reduced for speed

# Parameter grids
ALPHAS = [0.3, 0.35, 0.4]   # attacker (malicious miner) power
BETAS = [0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4]  # agent (rational miner) power

print("=" * 80)
print("ErMine Comprehensive Experiment")
print("Comparing: Honest Mining | SM1 (Selfish Mining) | ErMine-DRQN | Theoretical")
print("=" * 80)

# ============================================================
# 1. Theoretical Results (using util.py formulas)
# ============================================================
print("\n[1/4] Computing theoretical results...")
theoretical_results = {}

for alpha in ALPHAS:
    for beta in BETAS:
        if alpha + beta >= 1.0:
            continue
        sm1_gain = util.SM1_theoretical_gain(alpha, GAMMA)
        agent_gain = util.Agent_theoreticle_gain(alpha, beta, GAMMA)
        other_gain = util.Other_theoreticle_gain(alpha, beta, GAMMA)
        theoretical_results[(alpha, beta)] = {
            'rela_att': sm1_gain,
            'rela_agent': agent_gain,
            'rela_other': other_gain
        }

# ============================================================
# 2. Honest Mining (no attacker, just proportional to mining power)
# ============================================================
print("[2/4] Computing honest mining baseline...")
honest_results = {}

for alpha in ALPHAS:
    for beta in BETAS:
        if alpha + beta >= 1.0:
            continue
        # In honest mining with no attacker: attacker mines honestly too
        total_power = alpha + beta + (1 - alpha - beta)
        honest_results[(alpha, beta)] = {
            'rela_att': alpha,          # attacker mines proportionally
            'rela_agent': beta,          # agent mines proportionally
            'rela_other': 1 - alpha - beta  # others mine proportionally
        }

# ============================================================
# 3. SM1 Simulation (Selfish Mining Attack)
# ============================================================
print("[3/4] Running SM1 simulation...")

# Import Selfish_Mining from selfish_mining1.py
import importlib.util
spec = importlib.util.spec_from_file_location("sm1_module",
    os.path.join(os.path.dirname(__file__), "selfish_mining1.py"))
sm1_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sm1_module)
Selfish_Mining = sm1_module.Selfish_Mining

sm1_results = {}

for alpha in ALPHAS:
    for beta in BETAS:
        if alpha + beta >= 1.0:
            continue
        print(f"  SM1: alpha={alpha}, beta={beta}...")

        rela_att_list, rela_agent_list, rela_other_list = [], [], []

        for trial in range(SM1_TRIALS):
            sm = Selfish_Mining(**{
                'nb_simulations': SM1_SIMULATIONS,
                'alpha': alpha,
                'gamma': GAMMA,
                'block_num': BLOCK_NUM
            })
            rela_att, rela_agent, rela_other = sm.Simulate()
            rela_att_list.append(rela_att)
            rela_agent_list.append(rela_agent)
            rela_other_list.append(rela_other)

        sm1_results[(alpha, beta)] = {
            'rela_att': round(statistics.mean(rela_att_list), 4),
            'rela_agent': round(statistics.mean(rela_agent_list), 4),
            'rela_other': round(statistics.mean(rela_other_list), 4)
        }

# ============================================================
# 4. ErMine-DRQN Results (from existing output.csv)
# ============================================================
print("[4/4] Aggregating ErMine-DRQN results from output.csv...")

dqn_results = {}  # Note: output.csv is actually from DRQN training

# Read existing DRQN results
if os.path.exists("Result/output.csv"):
    with open("Result/output.csv", "r") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    # Group by (alpha, beta) and compute average over episodes
    grouped = defaultdict(lambda: {'rela_att': [], 'rela_agent': [], 'rela_other': []})
    for row in rows:
        alpha = float(row['alpha'])
        beta = float(row['beta'])
        grouped[(alpha, beta)]['rela_att'].append(float(row['rela_att']))
        grouped[(alpha, beta)]['rela_agent'].append(float(row['rela_agent']))
        grouped[(alpha, beta)]['rela_other'].append(float(row['rela_other']))

    for (alpha, beta), vals in grouped.items():
        if alpha in ALPHAS and beta in BETAS:
            dqn_results[(alpha, beta)] = {
                'rela_att': round(statistics.mean(vals['rela_att']), 4),
                'rela_agent': round(statistics.mean(vals['rela_agent']), 4),
                'rela_other': round(statistics.mean(vals['rela_other']), 4)
            }
    print(f"  Loaded {len(dqn_results)} (alpha, beta) combinations from output.csv")
else:
    print("  WARNING: output.csv not found, skipping DRQN results")

# ============================================================
# Generate Final Results Table
# ============================================================
print("\n" + "=" * 120)
print("FINAL RESULTS TABLE")
print("=" * 120)

# Table header
header = f"{'alpha':<7} {'beta':<7} | {'Honest Mining':<36} | {'SM1 (Selfish)':<36} | {'ErMine-DRQN':<36} | {'Theoretical(SM1)':<36}"
print(header)
print(f"{'':7} {'':7} | {'att':>8} {'agent':>8} {'other':>8} {'gain%':>8} | {'att':>8} {'agent':>8} {'other':>8} {'gain%':>8} | {'att':>8} {'agent':>8} {'other':>8} {'gain%':>8} | {'att':>8} {'agent':>8} {'other':>8} {'gain%':>8}")
print("-" * 120)

all_rows = []

for alpha in ALPHAS:
    for beta in BETAS:
        if alpha + beta >= 1.0:
            continue

        key = (alpha, beta)

        # Honest mining baseline
        h = honest_results.get(key, {})
        h_att = h.get('rela_att', 0)
        h_agent = h.get('rela_agent', 0)
        h_other = h.get('rela_other', 0)
        h_gain = round(h_agent - beta, 4)  # agent's extra gain over proportional

        # SM1 results
        s = sm1_results.get(key, {})
        s_att = s.get('rela_att', 0)
        s_agent = s.get('rela_agent', 0)  # In SM1, agent = attacker
        s_other = s.get('rela_other', 0)
        s_gain = round(s_att - alpha, 4)  # attacker's extra gain

        # ErMine-DRQN results
        d = dqn_results.get(key, {})
        d_att = d.get('rela_att', float('nan'))
        d_agent = d.get('rela_agent', float('nan'))
        d_other = d.get('rela_other', float('nan'))
        d_gain = round(d_agent - beta, 4) if not np.isnan(d_agent) else float('nan')

        # Theoretical SM1
        t = theoretical_results.get(key, {})
        t_att = t.get('rela_att', 0)
        t_agent = t.get('rela_agent', 0)
        t_other = t.get('rela_other', 0)
        t_gain = round(t_att - alpha, 4)

        row_str = f"{alpha:<7} {beta:<7} | {h_att:>8.4f} {h_agent:>8.4f} {h_other:>8.4f} {h_gain:>8.4f} | {s_att:>8.4f} {s_agent:>8.4f} {s_other:>8.4f} {s_gain:>8.4f} | {d_att:>8.4f} {d_agent:>8.4f} {d_other:>8.4f} {d_gain:>8.4f} | {t_att:>8.4f} {t_agent:>8.4f} {t_other:>8.4f} {t_gain:>8.4f}"
        print(row_str)

        all_rows.append({
            'alpha': alpha, 'beta': beta,
            'honest_att': h_att, 'honest_agent': h_agent, 'honest_other': h_other, 'honest_gain': h_gain,
            'sm1_att': s_att, 'sm1_agent': s_agent, 'sm1_other': s_other, 'sm1_gain': s_gain,
            'ermine_att': d_att, 'ermine_agent': d_agent, 'ermine_other': d_other, 'ermine_gain': d_gain,
            'theo_att': t_att, 'theo_agent': t_agent, 'theo_other': t_other, 'theo_gain': t_gain,
        })

# ============================================================
# Summary: Key findings
# ============================================================
print("\n" + "=" * 80)
print("KEY FINDINGS")
print("=" * 80)

print("""
Explanation of columns:
  - Honest Mining: All miners follow protocol (attacker mines honestly).
    Revenue proportional to mining power.
  - SM1 (Selfish Mining): Attacker uses selfish mining strategy.
    Agent is part of 'attacker' group, so rela_agent = rela_att.
  - ErMine-DRQN: Agent uses DRQN-based detection/defense (ErMine method).
    Agent can choose to mine, stop, follow attacker, or follow honest chain.
  - Theoretical(SM1): Theoretical expected revenue under SM1 strategy.
    Calculated from Eyal & Sirer formulas.

Revenue columns:
  - att: Malicious miner's relative revenue
  - agent: Rational miner's (our agent's) relative revenue
  - other: Honest miners' relative revenue
  - gain%: Extra revenue beyond proportional (positive = advantage)
""")

print(f"\nExperiment complete. {len(all_rows)} parameter combinations tested.")
print(f"Results saved to 'experiment_results.csv'")

# Save to CSV
csv_path = os.path.join(os.path.dirname(__file__), "Result", "experiment_results.csv")
with open(csv_path, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=[
        'alpha', 'beta',
        'honest_att', 'honest_agent', 'honest_other', 'honest_gain',
        'sm1_att', 'sm1_agent', 'sm1_other', 'sm1_gain',
        'ermine_att', 'ermine_agent', 'ermine_other', 'ermine_gain',
        'theo_att', 'theo_agent', 'theo_other', 'theo_gain'
    ])
    writer.writeheader()
    writer.writerows(all_rows)

print(f"Full CSV: {csv_path}")
