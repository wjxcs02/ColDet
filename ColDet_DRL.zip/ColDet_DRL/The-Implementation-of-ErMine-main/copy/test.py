import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams

# 设置新罗马字体
rcParams['font.family'] = 'serif'
rcParams['font.serif'] = ['Times New Roman', 'Times', 'DejaVu Serif']
rcParams['mathtext.fontset'] = 'stix'

# 生成数据
np.random.seed(42)
n_groups = 8  # 减少组数使图表更清晰

groups = [f'Test {i + 1}' for i in range(n_groups)]

# 生成数据
data = {
    'Red Dots': np.random.uniform(60, 90, n_groups),
    'Green Slashes': np.random.uniform(50, 85, n_groups),
    'Blue Pattern': np.random.uniform(70, 95, n_groups)
}

# 创建图形
fig, ax = plt.subplots(figsize=(12, 6))

# 柱状图参数
bar_width = 0.26
x = np.arange(n_groups)

# 自定义填充图案
fill_styles = [
    {'facecolor': 'white', 'edgecolor': 'red', 'hatch': '....', 'linewidth': 1.5},
    {'facecolor': 'white', 'edgecolor': 'green', 'hatch': '////', 'linewidth': 1.5},
    {'facecolor': 'white', 'edgecolor': 'blue', 'hatch': '\\\\\\', 'linewidth': 1.5},
]

# 绘制柱状图
for i, (label, values) in enumerate(data.items()):
    offset = (i - 1) * bar_width
    style = fill_styles[i]

    bars = ax.bar(x + offset, values, bar_width,
                  label=label,
                  color=style['facecolor'],  # 背景色
                  edgecolor=style['edgecolor'],  # 边框和填充颜色
                  linewidth=style['linewidth'],  # 边框粗细
                  alpha=0.9,
                  hatch=style['hatch'])  # 填充图案

# 设置图表
ax.set_xlabel('Dataset', fontsize=12, fontweight='bold')
ax.set_ylabel('Accuracy (%)', fontsize=12, fontweight='bold')
ax.set_title('Comparison with Red Dots and Green Slashes Fill Patterns',
             fontsize=14, fontweight='bold')
ax.set_xticks(x)
ax.set_xticklabels(groups, fontsize=11)
ax.set_ylim(0, 100)

# 添加图例
legend = ax.legend(loc='upper left', fontsize=11, frameon=True)
legend.get_frame().set_facecolor('white')
legend.get_frame().set_edgecolor('gray')

# 添加网格
ax.grid(True, axis='y', alpha=0.2, linestyle='--')
ax.set_axisbelow(True)

# 添加填充图案说明
pattern_info = "Fill Patterns:\n• Red Dots: .... (dot pattern)\n• Green Slashes: //// (diagonal lines)\n• Blue Pattern: \\\\\\ (reverse slashes)"
ax.text(0.02, 0.98, pattern_info,
        transform=ax.transAxes, fontsize=10, verticalalignment='top',
        bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.8))

plt.tight_layout()
#plt.savefig('red_dots_green_slashes.png', dpi=300, bbox_inches='tight')
plt.show()

print("红点绿斜线填充柱状图已生成")