import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from env_copy import Environment
import util
import csv

# 超参数
BATCH_SIZE = 32  # 网络训练的批大小
LEARNING_RATE = 0.001  # 学习率
EPSILON = 0.9  # 贪婪策略
GAMMA = 0.9  # 折扣因子
TARGET_REPLACE_ITER = 100  # 目标网络更新频率
MEMORY_CAPACITY = 2000  # 经验缓冲区大小
EPISODE_NUM = 6  # 训练 episodes 数量
SEQ_LEN = 10  # LSTM序列长度

# 挖矿参数
TOTAL_ROUNDS = 10000
ALPHA = 0.3
AGENT_POWER = 0.3
FOLLOW_FRACTION = 0.5
COST_FACTOR = 0.1

# 动作和状态空间维度
N_ACTIONS = 3
N_STATES = 4


class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.lstm = nn.LSTM(
            input_size=N_STATES,
            hidden_size=64,
            num_layers=1,
            batch_first=True
        )
        self.fc = nn.Linear(64, 32)
        self.fc.weight.data.normal_(0, 0.1)
        self.out = nn.Linear(32, N_ACTIONS)
        self.out.weight.data.normal_(0, 0.1)

    def forward(self, x, hidden=None):
        # x形状: (batch_size, seq_len, input_size)
        batch_size = x.size(0)

        # 如果没有提供隐藏状态，则初始化
        if hidden is None:
            h0 = torch.zeros(1, batch_size, 64).to(x.device)
            c0 = torch.zeros(1, batch_size, 64).to(x.device)
            hidden = (h0, c0)
        else:
            # 确保隐藏状态与输入在同一设备上
            h0, c0 = hidden
            hidden = (h0.to(x.device), c0.to(x.device))

        # LSTM前向传播
        lstm_out, hidden = self.lstm(x, hidden)

        # 取最后一个时间步的输出
        last_out = lstm_out[:, -1, :]

        # 全连接层处理
        x = F.relu(self.fc(last_out))
        actions_value = self.out(x)
        return actions_value, hidden  # 返回值和新的隐藏状态


class DRQN(object):
    def __init__(self):
        self.eval_net, self.target_net = Net(), Net()
        self.learn_step_counter = 0
        self.memory_counter = 0
        self.memory = np.zeros((MEMORY_CAPACITY, SEQ_LEN * N_STATES * 2 + 2))
        self.optimizer = torch.optim.Adam(self.eval_net.parameters(), lr=LEARNING_RATE)
        self.loss_func = nn.MSELoss()

        # 存储最近的状态用于构建序列
        self.recent_states = []
        # 单独存储推理时的隐藏状态（与训练分离）
        self.inference_hidden = None

    def choose_action(self, x, reset_hidden=False):
        # 维护状态序列
        self.recent_states.append(x)
        if len(self.recent_states) > SEQ_LEN:
            self.recent_states.pop(0)
        while len(self.recent_states) < SEQ_LEN:
            self.recent_states.insert(0, np.zeros_like(x))

        # 转换为序列张量 (1, SEQ_LEN, N_STATES)
        state_seq = np.array(self.recent_states).reshape(1, SEQ_LEN, N_STATES)
        x = torch.FloatTensor(state_seq)

        # 重置推理隐藏状态（如episode开始时）
        if reset_hidden:
            self.inference_hidden = None

        if np.random.uniform() < EPSILON:
            # 使用评估网络选择动作，传入推理专用隐藏状态
            actions_value, self.inference_hidden = self.eval_net(x, self.inference_hidden)
            action = torch.max(actions_value, 1)[1].data.numpy()[0]
        else:
            action = np.random.randint(0, N_ACTIONS)
        return action

    def choose_action_by_target_net(self, x, reset_hidden=False):
        self.recent_states.append(x)
        if len(self.recent_states) > SEQ_LEN:
            self.recent_states.pop(0)
        while len(self.recent_states) < SEQ_LEN:
            self.recent_states.insert(0, np.zeros_like(x))

        state_seq = np.array(self.recent_states).reshape(1, SEQ_LEN, N_STATES)
        x = torch.FloatTensor(state_seq)

        if reset_hidden:
            self.inference_hidden = None

        if np.random.uniform() < EPSILON:
            actions_value, self.inference_hidden = self.target_net(x, self.inference_hidden)
            action = torch.max(actions_value, 1)[1].data.numpy()[0]
        else:
            action = np.random.randint(0, N_ACTIONS)
        return action

    def store_transition(self, s_seq, a, r, s_seq_):
        s_seq_flat = s_seq.flatten()
        s_seq__flat = s_seq_.flatten()
        transition = np.hstack((s_seq_flat, [a, r], s_seq__flat))
        index = self.memory_counter % MEMORY_CAPACITY
        self.memory[index, :] = transition
        self.memory_counter += 1

    def learn(self):
        # 更新目标网络
        if self.learn_step_counter % TARGET_REPLACE_ITER == 0:
            self.target_net.load_state_dict(self.eval_net.state_dict())
        self.learn_step_counter += 1

        # 采样批次
        sample_index = np.random.choice(MEMORY_CAPACITY, BATCH_SIZE)
        b_memory = self.memory[sample_index, :]

        # 解析经验
        seq_state_size = SEQ_LEN * N_STATES
        b_s_seq = torch.FloatTensor(b_memory[:, :seq_state_size]).view(BATCH_SIZE, SEQ_LEN, N_STATES)
        b_a = torch.LongTensor(b_memory[:, seq_state_size:seq_state_size + 1].astype(int))
        b_r = torch.FloatTensor(b_memory[:, seq_state_size + 1:seq_state_size + 2])
        b_s_seq_ = torch.FloatTensor(b_memory[:, -seq_state_size:]).view(BATCH_SIZE, SEQ_LEN, N_STATES)

        # 训练时不使用推理的隐藏状态，而是让LSTM自动初始化
        q_eval, _ = self.eval_net(b_s_seq)  # 忽略训练时的隐藏状态
        q_eval = q_eval.gather(1, b_a)

        q_next, _ = self.target_net(b_s_seq_)  # 忽略目标网络的隐藏状态
        q_next = q_next.detach()
        q_target = b_r + GAMMA * q_next.max(1)[0].view(BATCH_SIZE, 1)

        # 计算损失并优化
        loss = self.loss_func(q_eval, q_target)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

    def flush_buffer(self):
        self.learn_step_counter = 0
        self.memory_counter = 0
        self.memory = np.zeros((MEMORY_CAPACITY, SEQ_LEN * N_STATES * 2 + 2))
        self.recent_states = []
        self.inference_hidden = None  # 重置推理隐藏状态


def training_op(env, model_path, alpha, beta):
    drqn = DRQN()

    for i in range(EPISODE_NUM):
        print('<<<<<<<<< Episode: %s' % i)
        s = env.reset()
        drqn.flush_buffer()  # 每个episode重置

        # 初始化状态序列
        state_sequence = [s for _ in range(SEQ_LEN)]

        while True:
            # 选择动作时传入reset_hidden（仅在episode开始时生效）
            a = drqn.choose_action(s, reset_hidden=(len(drqn.recent_states) == 0))

            # 执行动作
            s_, r, done, info = env.step(s, a)

            # 更新状态序列
            state_sequence.append(s_)
            state_sequence.pop(0)

            # 准备下一状态序列
            next_state_sequence = state_sequence.copy()
            next_state_sequence.append(s_)
            next_state_sequence.pop(0)

            # 存储经验
            drqn.store_transition(np.array(state_sequence), a, r, np.array(next_state_sequence))

            # 更新当前状态
            s = s_

            # 缓冲区满了就开始学习
            if drqn.memory_counter > MEMORY_CAPACITY:
                drqn.learn()

            if done:
                print('>>>>>>>>>>> Episode %s finish: \n' % i)
                rela_att, rela_agent, rela_other = util.rela_reward_calculate(
                    env.total_valid_blocks,
                    env.attacker_valid_blocks,
                    env.agent_valid_blocks
                )

                output_data = [alpha, beta, i, rela_att, rela_agent, rela_other]
                with open('../Result/output.csv', 'a', newline='') as file:
                    writer = csv.writer(file)
                    # 首次写入时添加表头（可选，避免重复表头）
                    if file.tell() == 0:
                        writer.writerow(['alpha', 'beta', 'episode', 'rela_att', 'rela_agent', 'rela_other'])
                    writer.writerow(output_data)
                break

    # 确保保存目录存在
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    torch.save(drqn, model_path)


def drqn_training():
    alphas = [0.5]
    betas = [0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45,0.5,0.55,0.6]

    for alpha in alphas:
        for beta in betas:
            env = Environment(
                total_rounds=TOTAL_ROUNDS,
                attacker_power=alpha,
                agent_power=beta,
                follower_fraction=FOLLOW_FRACTION,
                cost=0
            )
            print(alpha,beta)
            model_path = f'C:/Users/23945/Desktop/DRQN/drqn_{EPISODE_NUM}episodes_alpha{alpha}_beta{beta}_.pt'
            training_op(env, model_path,alpha,beta)


if __name__ == '__main__':
    drqn_training()