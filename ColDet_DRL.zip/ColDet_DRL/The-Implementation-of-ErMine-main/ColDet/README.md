# ColDet-DRL: MNIST federated-learning dynamic-backdoor prototype

## What is implemented
- Actual local client training on MNIST with a small CNN.
- Server-side FedAvg aggregation each communication round.
- Dirichlet non-IID client data partitioning.
- Dynamic trigger placement and target-label poisoning by malicious clients.
- Four labels: Normal, Dormant, Attack, Collaborative Attack.
- Server-visible update features, peer update cosine similarity, Gaussian observation likelihood and transition-prior belief filter.
- LSTM state classifier evaluated on later rounds (chronological split).
- Optional REINFORCE policy-gradient *classification baseline* via `--policy-gradient`.
- Per-round clean accuracy and backdoor success rate, plus detector accuracy, macro-F1, confusion matrix, class precision/recall/F1 saved to JSON.

## Important limitations
This is an executable research prototype, not a validated reproduction of the final ColDet-DRL paper method. The transition matrix is fixed; the emission model is a diagonal Gaussian; the optional REINFORCE module treats state classification as an action and is not yet a justified adaptive defense policy. The coordinated group is defined by known simulated client IDs, and state labels come from the simulator. Run multiple seeds, larger/full datasets, baselines and ablations before drawing scientific conclusions. Do not present one run as definitive paper evidence.

## Environment
The script is CPU-compatible. Your reported environment is PyTorch 1.13.0+cu116 and Python 3.9. Install a compatible torchvision build if not already installed; PyTorch 1.13.0 generally pairs with torchvision 0.14.0. First check `import torchvision` before changing packages. Also install:

```powershell
& "D:\Compiler\Pycharm\venv\pytorch\python.exe" -m pip install numpy==1.26.4 scikit-learn
```

If torchvision is missing and compatible wheels are available in your package source:

```powershell
& "D:\Compiler\Pycharm\venv\pytorch\python.exe" -m pip install torchvision==0.14.0
```

Do not upgrade PyTorch blindly. If torchvision import gives an error, send the complete error first.

## Run in PyCharm Terminal
Initial MNIST download requires internet access:

```powershell
& "D:\Compiler\Pycharm\venv\pytorch\python.exe" coldet_mnist_experiment.py --rounds 8 --clients 10 --local-epochs 1 --limit-train 12000 --limit-test 2000
```

For a more informative detector test, use at least 20 rounds after confirming the short run works:

```powershell
& "D:\Compiler\Pycharm\venv\pytorch\python.exe" coldet_mnist_experiment.py --rounds 20 --clients 10 --local-epochs 1 --limit-train 20000 --limit-test 3000
```

Optional REINFORCE baseline:

```powershell
& "D:\Compiler\Pycharm\venv\pytorch\python.exe" coldet_mnist_experiment.py --rounds 8 --clients 10 --policy-gradient
```

## Output
`results/coldet_mnist_results.json` includes configuration, per-round clean accuracy and backdoor success rate, held-out detector metrics, class-wise report and confusion matrix.
