"""ColDet-DRL runnable FL dynamic-backdoor prototype on MNIST.
Research prototype, not a reproduction of a published benchmark.
Run: python coldet_mnist_experiment.py --rounds 8 --clients 10
"""
import argparse, copy, json, os, random
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Subset, TensorDataset
from torchvision import datasets, transforms

STATE_NAMES = ["Normal", "Dormant", "Attack", "Collaborative Attack"]
K = 4
DEVICE = torch.device("cpu")
TRANSITION = np.array([[.94,.04,.015,.005],[.30,.52,.13,.05],[.12,.15,.63,.10],[.08,.10,.12,.70]], dtype=np.float64)
EMISSION_MEAN = None
EMISSION_VAR = None

def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.set_num_threads(2)

class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Conv2d(1,16,3,padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(16,32,3,padding=1), nn.ReLU(), nn.MaxPool2d(2), nn.Flatten(),
            nn.Linear(32*7*7,64), nn.ReLU(), nn.Linear(64,10))
    def forward(self,x): return self.net(x)

def add_trigger(x, pattern=0):
    x=x.clone()
    if pattern % 2 == 0: x[...,24:27,24:27]=1.0
    else: x[...,24:27,21:24]=1.0
    return x

def make_client_indices(labels, n_clients, alpha, seed):
    rng=np.random.default_rng(seed); labels=np.asarray(labels); buckets=[[] for _ in range(n_clients)]
    for c in range(10):
        idx=np.where(labels==c)[0]; rng.shuffle(idx)
        cuts=(np.cumsum(rng.dirichlet(np.full(n_clients,alpha))*len(idx))).astype(int)[:-1]
        for k,p in enumerate(np.split(idx,cuts)): buckets[k].extend(p.tolist())
    return [np.asarray(sorted(b),dtype=np.int64) for b in buckets]

def state_and_attack(cid, r, malicious_ids, collab_ids):
    if cid not in malicious_ids: return 0,False
    active=(r%2==0) or (r%2==1 and cid in collab_ids)
    if not active: return 1,False
    return (3,True) if cid in collab_ids else (2,True)

def local_train(global_model,dataset,indices,r,malicious,collab,epochs,batch_size,lr,target=0):
    model=copy.deepcopy(global_model).to(DEVICE); model.train()
    loader=DataLoader(Subset(dataset,indices.tolist()),batch_size=batch_size,shuffle=True)
    opt=torch.optim.SGD(model.parameters(),lr=lr); loss_fn=nn.CrossEntropyLoss()
    for _ in range(epochs):
        for xb,yb in loader:
            if malicious:
                mask=torch.rand(len(xb)) < (0.30 if collab else 0.20)
                if mask.any():
                    xb=xb.clone(); xb[mask]=add_trigger(xb[mask],r%2)
                    yb=yb.clone(); yb[mask]=target
            opt.zero_grad(); loss=loss_fn(model(xb),yb); loss.backward(); opt.step()
    return model.state_dict()

def flatten_delta(local, global_state):
    return torch.cat([(local[k]-global_state[k]).detach().cpu().reshape(-1) for k in global_state if torch.is_floating_point(global_state[k])]).numpy().astype(np.float32)

def fedavg(global_state, states, weights):
    total=float(sum(weights)); out={}
    for k,v in global_state.items():
        if torch.is_floating_point(v):
            acc=torch.zeros_like(v)
            for s,w in zip(states,weights): acc += s[k]*(w/total)
            out[k]=acc
        else: out[k]=v.clone()
    return out

def update_features(delta, previous, peer_sims):
    norm=float(np.linalg.norm(delta)); q=np.quantile(np.abs(delta),[.25,.5,.75,.95])
    prev=previous[-1] if previous else np.zeros_like(delta)
    temporal=float(np.dot(delta,prev)/(np.linalg.norm(delta)*np.linalg.norm(prev)+1e-8))
    return np.asarray([np.log1p(norm),float(delta.mean()),float(delta.std()),*q,
        float(np.mean(peer_sims)) if peer_sims else 0.,temporal],dtype=np.float32)

def belief_filter(seq):
    b=np.array([.80,.10,.07,.03],dtype=np.float64); out=[]
    for f in seq:
        prior=b@TRANSITION
        logp=-.5*np.sum(np.log(2*np.pi*EMISSION_VAR)+(f-EMISSION_MEAN)**2/EMISSION_VAR,axis=1)
        logp-=np.max(logp); likelihood=np.exp(np.clip(logp,-60,0))+1e-12
        b=prior*likelihood; b=b/b.sum(); out.append(b.astype(np.float32))
    return np.asarray(out,dtype=np.float32)

class BeliefLSTM(nn.Module):
    def __init__(self,in_dim):
        super().__init__(); self.lstm=nn.LSTM(in_dim,32,batch_first=True)
        self.head=nn.Sequential(nn.Linear(32,24),nn.ReLU(),nn.Linear(24,K))
    def forward(self,x):
        y,_=self.lstm(x); return self.head(y[:,-1])

class REINFORCEPolicy(nn.Module):
    """Optional REINFORCE policy-gradient classification baseline (not a defense policy)."""
    def __init__(self,in_dim):
        super().__init__(); self.net=nn.Sequential(nn.Linear(in_dim,32),nn.Tanh(),nn.Linear(32,K))
    def forward(self,x): return torch.softmax(self.net(x),dim=-1)

def train_policy_gradient(model,x,y,epochs=20):
    opt=torch.optim.Adam(model.parameters(),lr=1e-3)
    for _ in range(epochs):
        dist=torch.distributions.Categorical(model(x)); actions=dist.sample()
        rewards=torch.where(actions==y,1.,-1.); adv=rewards-rewards.mean()
        loss=-(dist.log_prob(actions)*adv.detach()).mean()
        opt.zero_grad(); loss.backward(); opt.step()
    return model

def test_backdoor(model,testset,n=500,target=0,pattern=0):
    loader=DataLoader(Subset(testset,list(range(min(n,len(testset))))),batch_size=128)
    total=success=clean=seen=0; model.eval()
    with torch.no_grad():
        for xb,yb in loader:
            pred=model(xb).argmax(1); clean+=int((pred==yb).sum()); seen+=len(yb)
            mask=yb.ne(target)
            if mask.any():
                p=model(add_trigger(xb[mask],pattern)).argmax(1)
                success+=int((p==target).sum()); total+=int(mask.sum())
    return {"clean_accuracy":clean/max(seen,1),"backdoor_success_rate":success/max(total,1)}

def main():
    global EMISSION_MEAN, EMISSION_VAR
    ap=argparse.ArgumentParser()
    ap.add_argument('--rounds',type=int,default=8); ap.add_argument('--clients',type=int,default=10)
    ap.add_argument('--malicious-ratio',type=float,default=.3); ap.add_argument('--collab-ratio',type=float,default=.5)
    ap.add_argument('--local-epochs',type=int,default=1); ap.add_argument('--batch-size',type=int,default=64)
    ap.add_argument('--lr',type=float,default=.01); ap.add_argument('--alpha',type=float,default=.5)
    ap.add_argument('--limit-train',type=int,default=12000); ap.add_argument('--limit-test',type=int,default=2000)
    ap.add_argument('--seed',type=int,default=42); ap.add_argument('--policy-gradient',action='store_true')
    args=ap.parse_args()
    if args.rounds<3: raise ValueError('Use at least 3 rounds for a chronological train/test split.')
    seed_all(args.seed); tf=transforms.Compose([transforms.ToTensor()])
    train_full=datasets.MNIST('./data',train=True,download=True,transform=tf)
    test_full=datasets.MNIST('./data',train=False,download=True,transform=tf)
    rng=np.random.default_rng(args.seed)
    trainset=Subset(train_full,rng.permutation(len(train_full))[:min(args.limit_train,len(train_full))].tolist())
    testset=Subset(test_full,rng.permutation(len(test_full))[:min(args.limit_test,len(test_full))].tolist())
    labels=np.asarray([trainset[i][1] for i in range(len(trainset))])
    client_idxs=make_client_indices(labels,args.clients,args.alpha,args.seed)
    n_mal=max(1,int(args.clients*args.malicious_ratio)); malicious_ids=set(range(args.clients-n_mal,args.clients))
    n_coll=max(1,int(n_mal*args.collab_ratio)); collab_ids=set(sorted(malicious_ids)[-n_coll:])
    print('Malicious IDs:',sorted(malicious_ids),'Collaborative IDs:',sorted(collab_ids))
    model=SmallCNN(); global_state=copy.deepcopy(model.state_dict())
    feature_history=[[] for _ in range(args.clients)]; delta_history=[[] for _ in range(args.clients)]
    all_features=[]; all_labels=[]; round_metrics=[]
    for r in range(args.rounds):
        print(f'\n=== FL round {r+1}/{args.rounds} ==='); states=[]; weights=[]; deltas=[]; round_states=[]
        for cid in range(args.clients):
            state,active=state_and_attack(cid,r,malicious_ids,collab_ids)
            local=local_train(model,trainset,client_idxs[cid],r,active,cid in collab_ids,args.local_epochs,args.batch_size,args.lr)
            delta=flatten_delta(local,global_state); deltas.append(delta); states.append(local)
            weights.append(max(1,len(client_idxs[cid]))); round_states.append(state)
        normed=[d/(np.linalg.norm(d)+1e-8) for d in deltas]
        for cid,delta in enumerate(deltas):
            sims=[float(np.dot(normed[cid],normed[j])) for j in range(args.clients) if j!=cid]
            f=update_features(delta,delta_history[cid],sims)
            feature_history[cid].append(f); delta_history[cid].append(delta)
            all_features.append(f); all_labels.append(round_states[cid])
        global_state=fedavg(global_state,states,weights); model.load_state_dict(global_state)
        m=test_backdoor(model,testset,n=min(500,len(testset)),pattern=r%2); round_metrics.append(m)
        print(f"CleanAcc={m['clean_accuracy']:.4f} | BackdoorSuccess={m['backdoor_success_rate']:.4f}")
    X=np.asarray(all_features,dtype=np.float32); y=np.asarray(all_labels,dtype=np.int64)
    X3=X.reshape(args.rounds,args.clients,-1); y2=y.reshape(args.rounds,args.clients)
    split=max(2,int(args.rounds*.7)); split=min(split,args.rounds-1)
    Xtrain=X3[:split].reshape(-1,X.shape[-1]); ytrain=y2[:split].reshape(-1)
    EMISSION_MEAN=np.zeros((K,X.shape[-1]),dtype=np.float64); EMISSION_VAR=np.ones_like(EMISSION_MEAN)*1e-3
    for s in range(K):
        subset=Xtrain[ytrain==s]
        if len(subset): EMISSION_MEAN[s]=subset.mean(0); EMISSION_VAR[s]=np.maximum(subset.var(0),1e-3)
    win=min(4,split); tr_x=[]; tr_y=[]; te_x=[]; te_y=[]
    for cid in range(args.clients):
        seq=feature_history[cid]
        for end in range(win-1,split):
            fs=np.asarray(seq[end-win+1:end+1]); bs=belief_filter(fs); tr_x.append(np.concatenate([fs,bs],axis=1)); tr_y.append(y2[end,cid])
        for end in range(split,args.rounds):
            start=max(0,end-win+1); fs=np.asarray(seq[start:end+1]); bs=belief_filter(fs)
            if len(fs)<win:
                pad=win-len(fs); fs=np.concatenate([np.repeat(fs[:1],pad,axis=0),fs]); bs=np.concatenate([np.repeat(bs[:1],pad,axis=0),bs])
            te_x.append(np.concatenate([fs,bs],axis=1)); te_y.append(y2[end,cid])
    xtr=torch.tensor(np.asarray(tr_x),dtype=torch.float32); ytr=torch.tensor(tr_y,dtype=torch.long)
    xte=torch.tensor(np.asarray(te_x),dtype=torch.float32); yte=torch.tensor(te_y,dtype=torch.long)
    counts=torch.bincount(ytr,minlength=K).float(); class_weights=counts.sum()/(K*counts.clamp_min(1))
    detector=BeliefLSTM(xtr.shape[-1]); opt=torch.optim.Adam(detector.parameters(),lr=1e-3)
    loss_fn=nn.CrossEntropyLoss(weight=class_weights); loader=DataLoader(TensorDataset(xtr,ytr),batch_size=32,shuffle=True)
    for ep in range(8):
        detector.train(); total=0
        for xb,yb in loader:
            opt.zero_grad(); loss=loss_fn(detector(xb),yb); loss.backward(); opt.step(); total+=loss.item()*len(yb)
        print(f'Detector epoch {ep+1}/8 | loss={total/len(xtr):.4f}')
    from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report
    detector.eval()
    with torch.no_grad(): pred=detector(xte).argmax(1).numpy()
    truth=yte.numpy(); cm=confusion_matrix(truth,pred,labels=list(range(K)))
    report=classification_report(truth,pred,labels=list(range(K)),target_names=STATE_NAMES,output_dict=True,zero_division=0)
    detector_result={"accuracy":float(accuracy_score(truth,pred)),"macro_f1":float(f1_score(truth,pred,average='macro',zero_division=0)),"confusion_matrix":cm.tolist(),"classification_report":report}
    print('\nHeld-out chronological detector evaluation; rows=true, columns=pred:')
    print('Accuracy:',round(detector_result['accuracy'],4),'Macro-F1:',round(detector_result['macro_f1'],4)); print(cm)
    results={"warning":"Prototype research results only; do not report as conclusive paper results.","config":vars(args),"state_names":STATE_NAMES,"detector":detector_result,"per_round_fl_metrics":round_metrics,"training_class_counts":counts.tolist()}
    if args.policy_gradient:
        pg=train_policy_gradient(REINFORCEPolicy(xtr.shape[-1]),xtr,ytr)
        with torch.no_grad(): pg_pred=pg(xte).argmax(-1).numpy()
        results['reinforce_classification_baseline']={"accuracy":float(accuracy_score(truth,pg_pred)),"macro_f1":float(f1_score(truth,pg_pred,average='macro',zero_division=0)),"confusion_matrix":confusion_matrix(truth,pg_pred,labels=list(range(K))).tolist()}
    os.makedirs('results',exist_ok=True)
    with open('results/coldet_mnist_results.json','w',encoding='utf-8') as f: json.dump(results,f,indent=2,ensure_ascii=False)
    print('\nSaved results/coldet_mnist_results.json')

if __name__=='__main__': main()
