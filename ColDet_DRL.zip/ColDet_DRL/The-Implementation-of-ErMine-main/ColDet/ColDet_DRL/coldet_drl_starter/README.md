# ColDet-DRL starter: Stage 1

This project is a synthetic pipeline sanity check only. It is NOT a real FL experiment and its metrics must NOT be reported as paper results.

## Install
```bash
python -m pip install torch numpy
```
If PyTorch is already installed, do not reinstall it unless imports fail.

## Run
```bash
python coldet_pipeline_demo.py
```

The script creates synthetic observation sequences, applies a Bayesian belief filter, trains a small LSTM on CPU, prints accuracy/Macro-F1 and writes `demo_metrics.json`.

The transition and observation models are illustrative assumptions, not learned from real attack data. This first stage checks code flow only. The next stage is a real CPU-friendly MNIST + FedAvg + BadNets baseline, followed by dynamic attacks and client-level detection.
