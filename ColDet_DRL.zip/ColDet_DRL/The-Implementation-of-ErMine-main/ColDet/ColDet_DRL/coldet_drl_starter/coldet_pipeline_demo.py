"""
ColDet-DRL Stage 1 synthetic sanity check.
WARNING: this is not a real federated-learning experiment and its metrics are not paper results.
Requires: python -m pip install torch numpy
Run: python coldet_pipeline_demo.py
"""
import json, random
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

SEED = 42
STATES = ["Normal", "Dormant", "Attack", "Collaborative Attack"]
K, D, L = 4, 8, 8
T = np.array([[.91,.06,.02,.01],[.20,.55,.20,.05],[.12,.12,.66,.10],[.08,.07,.15,.70]], dtype=float)
MEANS = np.array([
    [.15,.15,.20,.20,.20,.15,.15,.10],
    [.18,.16,.18,.18,.22,.18,.17,.12],
    [.65,.72,.62,.68,.25,.30,.25,.20],
    [.62,.65,.58,.62,.78,.82,.75,.70]], dtype=np.float32)

def seed_all():
    random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
    torch.set_num_threads(2)

def generate(n):
    xs, ys = [], []
    for _ in range(n):
        s = int(np.random.choice(K, p=[.78,.10,.08,.04]))
        sx, sy = [], []
        for _ in range(L):
            sx.append(np.clip(np.random.normal(MEANS[s], .10), 0, 1).astype(np.float32))
            sy.append(s)
            s = int(np.random.choice(K, p=T[s]))
        xs.append(sx); ys.append(sy)
    return np.asarray(xs, np.float32), np.asarray(ys, np.int64)

def likelihood(o, sigma=.14):
    d = o[None,:] - MEANS
    lp = -.5 * np.sum((d/sigma)**2, axis=1)
    lp -= lp.max()
    return np.exp(lp) + 1e-12

def filter_beliefs(seq):
    b = np.array([.90,.06,.03,.01], dtype=float)
    out = []
    for o in seq:
        prior = b @ T
        q = prior * likelihood(o)
        b = q / q.sum()
        out.append(b.astype(np.float32))
    return np.asarray(out)

class BeliefLSTM(nn.Module):
    def __init__(self):
        super().__init__()
        self.lstm = nn.LSTM(K, 24, batch_first=True)
        self.head = nn.Sequential(nn.Linear(24,16), nn.ReLU(), nn.Linear(16,K))
    def forward(self, x):
        y, _ = self.lstm(x)
        return self.head(y[:,-1,:])

def macro_f1(y, p):
    scores = []
    for c in range(K):
        tp = np.sum((y==c)&(p==c)); fp = np.sum((y!=c)&(p==c)); fn = np.sum((y==c)&(p!=c))
        pr = tp/(tp+fp) if tp+fp else 0
        re = tp/(tp+fn) if tp+fn else 0
        scores.append(2*pr*re/(pr+re) if pr+re else 0)
    return float(np.mean(scores))

def main():
    seed_all()
    xtr, ytr = generate(1800); xte, yte = generate(500)
    xtr = torch.tensor(np.stack([filter_beliefs(s) for s in xtr]))
    ytr = torch.tensor(ytr[:,-1])
    xte = torch.tensor(np.stack([filter_beliefs(s) for s in xte]))
    yte = torch.tensor(yte[:,-1])
    loader = DataLoader(TensorDataset(xtr,ytr), batch_size=64, shuffle=True)
    model = BeliefLSTM()
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    loss_fn = nn.CrossEntropyLoss()
    for ep in range(1,9):
        model.train(); total=0; count=0
        for xb,yb in loader:
            opt.zero_grad(); loss=loss_fn(model(xb),yb); loss.backward(); opt.step()
            total += loss.item()*len(yb); count += len(yb)
        print(f"Epoch {ep}/8 | loss={total/count:.4f}")
    model.eval()
    with torch.no_grad(): pred = model(xte).argmax(1).numpy()
    truth = yte.numpy()
    result = {"warning":"SYNTHETIC SANITY CHECK ONLY; NOT PAPER RESULTS",
              "seed":SEED,"train_sequences":1800,"test_sequences":500,
              "sequence_length":L,"accuracy":float(np.mean(pred==truth)),
              "macro_f1":macro_f1(truth,pred),"states":STATES,
              "per_class":{}}
    for i,name in enumerate(STATES):
        mask = truth==i
        result["per_class"][name] = {"support":int(mask.sum()),
          "recall":float(np.mean(pred[mask]==i)) if mask.any() else None}
    Path("demo_metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print("\nSynthetic sanity check only — NOT paper results")
    print(f"Accuracy={result['accuracy']:.4f} | Macro-F1={result['macro_f1']:.4f}")
    for name, val in result["per_class"].items():
        print(name, val)
    print("Saved demo_metrics.json")

if __name__ == "__main__":
    main()
