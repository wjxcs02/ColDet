
import sys

print("Python路径：", sys.executable)

try:
    import numpy as np
    print("NumPy版本：", np.__version__)
    print("NumPy路径：", np.__file__)
    print("NumPy测试：", np.array([1, 2, 3]))
except Exception as e:
    print("NumPy导入失败：", repr(e))

try:
    import torch
    print("PyTorch版本：", torch.__version__)
    print("PyTorch路径：", torch.__file__)
except Exception as e:
    print("PyTorch导入失败：", repr(e))
