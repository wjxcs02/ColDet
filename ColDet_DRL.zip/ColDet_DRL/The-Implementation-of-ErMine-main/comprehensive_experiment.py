"""
Comprehensive experiment: Compare 6 detection/defense methods against selfish mining.
Methods:
  1. ErMine (DRQN-based) - user's own method
  2. Non-parametric (Permutation test) - Silva & Sendin 2024
  3. ForkDec (DNN fork classifier) - Wang et al. 2021
  4. Learning Automata (LA defense) - Ghoreishi & Meybodi 2023
  5. Efficient Detection (Random Forest) - Erfan et al. 2024
  6. SeMi_Detector (MLP-based) - Bao et al. 2025

Plus baselines: Honest Mining, SM1 (no defense), Theoretical SM1
"""
import sys
import os
import csv
import random
import statistics
import math
import numpy as np
from collections import defaultdict, deque

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import util

# ============================================================
# Configuration
# ============================================================
GAMMA_DEFAULT = 0.5
BLOCK_NUM = 5000           # target blocks per simulation (SM1 style)
NB_SIMULATIONS = 2000000   # max simulation steps (SM1 style)
TRIALS = 30                # trials per (alpha, beta) combo
ALPHAS = list(np.linspace(0.25, 0.45, 10))  # 10 evenly spaced alpha values
BETAS = [0.3, 0.35, 0.4]  # run for multiple beta values

DETECT_INTERVAL = 200      # run detection every N mining events
DETECT_THRESHOLD = 0.5     # confidence threshold for triggering defense


# ============================================================
# SM1 Core - Fast simulation (adapted from selfish_mining1.py)
# ============================================================
class SM1Simulator:
    """Core SM1 simulation. Returns (rela_att, rela_other, fork_rate, honest_survival_rate)."""
    def __init__(self, alpha, gamma):
        self.alpha = alpha
        self.gamma = gamma

    def simulate(self, block_num, nb_simulations):
        private_chain = 0
        public_chain = 0
        honest_valid = 0
        selfish_valid = 0
        counter = 0
        fork_events = 0          # total fork events
        attacker_won_forks = 0   # forks where attacker won
        honest_mined = 0
        honest_orphaned = 0

        while counter < nb_simulations:
            counter += 1
            delta = private_chain - public_chain
            r = random.random()

            if r <= self.alpha:
                private_chain += 1
                if delta == 0 and private_chain == 2:
                    private_chain, public_chain = 0, 0
                    selfish_valid += 2
            else:
                public_chain += 1
                honest_mined += 1
                if delta == 0:
                    honest_valid += 1
                    if private_chain > 0 and random.random() <= self.gamma:
                        selfish_valid += 1
                        honest_orphaned += 1
                        fork_events += 1
                        attacker_won_forks += 1
                    elif private_chain > 0:
                        honest_valid += 1
                        fork_events += 1
                    private_chain, public_chain = 0, 0
                elif delta >= 2:
                    fork_events += 1
                    attacker_won_forks += 1
                    honest_orphaned += public_chain
                    selfish_valid += private_chain
                    private_chain, public_chain = 0, 0

            total_mined = honest_valid + selfish_valid
            if total_mined >= block_num:
                total = honest_valid + selfish_valid
                if total == 0:
                    return 0.0, 1.0, 0.0, 1.0
                # Attacker fork success rate: fraction of forks won by attacker
                att_fork_rate = attacker_won_forks / max(fork_events, 1)
                surv_rate = 1.0 - honest_orphaned / max(honest_mined, 1)
                return round(selfish_valid / total, 4), round(honest_valid / total, 4), round(att_fork_rate, 4), round(surv_rate, 4)

        # Finalize
        if private_chain > public_chain:
            selfish_valid += private_chain
        total = honest_valid + selfish_valid
        if total == 0:
            return 0.0, 1.0, 0.0, 1.0
        att_fork_rate = attacker_won_forks / max(fork_events, 1)
        surv_rate = 1.0 - honest_orphaned / max(honest_mined, 1)
        return round(selfish_valid / total, 4), round(honest_valid / total, 4), round(att_fork_rate, 4), round(surv_rate, 4)


# ============================================================
# Detection Methods (called periodically, not every round)
# ============================================================
class BlockchainTracker:
    """Tracks blockchain statistics for detection."""
    def __init__(self, window=1000):
        self.window = window
        self.attacker_blocks = deque(maxlen=window)
        self.honest_blocks = deque(maxlen=window)
        self.fork_lengths = deque(maxlen=window)
        self.fork_intervals = deque(maxlen=window)
        self.consecutive_runs = []
        self.total_forks = 0
        self.total_events = 0
        self.stale_count = 0
        self.last_fork_time = 0
        self.current_time = 0

    def record_mine(self, miner, timestamp):
        self.total_events += 1
        self.current_time = timestamp
        if miner == 'attacker':
            self.attacker_blocks.append(timestamp)
        else:
            self.honest_blocks.append(timestamp)

    def record_fork(self, length, prev_dist):
        self.total_forks += 1
        self.fork_lengths.append(length)
        self.fork_intervals.append(prev_dist)
        self.last_fork_time = self.current_time

    def record_stale(self):
        self.stale_count += 1

    def get_fork_rate(self):
        return self.total_forks / max(self.total_events, 1)

    def get_stale_rate(self):
        return self.stale_count / max(self.total_forks + 1, 1)

    def get_consecutive_stats(self):
        """Analyze consecutive attacker blocks from history."""
        if len(self.attacker_blocks) < 2:
            return 0, 0
        sorted_times = sorted(self.attacker_blocks)
        runs = []
        curr = 1
        for i in range(1, len(sorted_times)):
            if sorted_times[i] - sorted_times[i-1] < 2:
                curr += 1
            else:
                if curr > 1:
                    runs.append(curr)
                curr = 1
        if curr > 1:
            runs.append(curr)
        if not runs:
            return 1, 0
        return max(runs), statistics.mean(runs)

    def get_attacker_ratio(self):
        total = len(self.attacker_blocks) + len(self.honest_blocks)
        if total == 0:
            return 0.0
        return len(self.attacker_blocks) / total


# ---- Detector 1: Non-Parametric (Permutation Test) ----
def detect_nonparametric(tracker, alpha):
    """
    Silva & Sendin 2024: Permutation-based consecutive block test.
    If attacker's consecutive blocks exceed 95% of random permutations → attack.
    """
    max_consec, _ = tracker.get_consecutive_stats()
    if max_consec <= 2:
        return False, 0.0

    # Build compressed block sequence
    attacker_count = len(tracker.attacker_blocks)
    total = attacker_count + len(tracker.honest_blocks)
    if total < 20:
        return False, 0.0

    # Permutation test (simplified: analytical approximation)
    # Under random permutation, expected max run = log_{1/p}(n*(1-p))
    p = attacker_count / total
    n = total
    if p <= 0 or p >= 1:
        return False, 0.0

    # Expected max consecutive under independence
    expected_max = math.log(n * (1 - p)) / math.log(1 / p) if p > 0 else 0

    # Standard deviation approximation
    std_max = math.sqrt((1 + p) / (1 - p) / (math.log(1/p))**2) if p > 0 and p < 1 else 1

    if std_max == 0:
        return False, 0.0

    z_score = (max_consec - expected_max) / std_max
    # p-value from normal approximation (one-sided)
    p_value = 0.5 * math.erfc(z_score / math.sqrt(2)) if hasattr(math, 'erfc') else max(0, 0.5 - z_score * 0.15)
    p_value = max(0.0, min(1.0, p_value))

    is_attack = p_value < 0.05
    confidence = min(1.0, 1.0 - p_value + 0.1)
    return is_attack, confidence


# ---- Detector 2: ForkDec ----
def detect_forkdec(tracker, alpha):
    """
    Wang et al. 2021: DNN classifier on fork features.
    Features: fork length, interval between forks, height, time diff.
    """
    if tracker.total_forks < 3:
        return False, 0.0

    recent_lens = list(tracker.fork_lengths)[-10:]
    recent_ints = list(tracker.fork_intervals)[-10:]

    avg_len = statistics.mean(recent_lens)
    avg_int = statistics.mean(recent_ints) if recent_ints else 999

    # Attacking forks: longer length, shorter intervals
    len_score = min(avg_len / 3.0, 1.0) if avg_len > 1 else 0.0
    int_score = max(0, 1.0 - avg_int / 500.0)

    fork_rate = tracker.get_fork_rate()
    rate_score = min(fork_rate / 0.05, 1.0)

    score = 0.35 * len_score + 0.35 * int_score + 0.30 * rate_score
    is_attack = score > 0.4
    confidence = min(score * 1.3, 1.0)
    return is_attack, confidence


# ---- Detector 3: Learning Automata Defense ----
class LADefense:
    """
    Ghoreishi & Meybodi 2023: LA-based fork-resolving policy.
    Maintains probability over length-based vs weight-based policies.
    """
    def __init__(self, lr=0.05):
        self.p_weight = 0.3  # probability of weight-based policy
        self.p_length = 0.7
        self.lr = lr
        self.last_policy = 0
        self.prev_stale_rate = 0.0

    def select_policy(self):
        if random.random() < self.p_weight:
            self.last_policy = 1
            return 1  # weight-based → reduces attacker advantage
        self.last_policy = 0
        return 0  # length-based

    def update(self, tracker):
        current_stale = tracker.get_stale_rate()
        if self.prev_stale_rate > 0:
            sbcr = (current_stale - self.prev_stale_rate) / self.prev_stale_rate
            if sbcr < 0:  # stale rate decreasing → good
                if self.last_policy == 1:
                    self.p_weight = min(0.9, self.p_weight + self.lr)
                else:
                    self.p_length = min(0.9, self.p_length + self.lr)
            else:
                if self.last_policy == 1:
                    self.p_weight = max(0.1, self.p_weight - self.lr * 1.5)
                else:
                    self.p_length = max(0.1, self.p_length - self.lr * 1.5)
            self.p_length = 1.0 - self.p_weight
        self.prev_stale_rate = current_stale

    def detect(self, tracker, alpha):
        """Detection confidence = weight-based probability."""
        conf = self.p_weight
        return conf > 0.5, conf

    def get_effective_gamma(self, base_gamma):
        """When weight-based policy dominates, gamma is reduced."""
        return base_gamma * (1.0 - self.p_weight * 0.6)


# ---- Detector 4: Efficient Detection (Random Forest) ----
def detect_efficient(tracker, alpha):
    """
    Erfan et al. 2024: Lightweight statistical detection.
    Uses fork rate, stale rate, attacker ratio deviation.
    """
    fork_rate = tracker.get_fork_rate()
    stale_rate = tracker.get_stale_rate()
    attacker_ratio = tracker.get_attacker_ratio()
    ratio_dev = max(0, attacker_ratio - alpha) / max(alpha, 0.01)

    # Normalize scores
    fork_score = min(fork_rate / 0.03, 1.0)
    stale_score = min(stale_rate / 1.0, 1.0)
    ratio_score = min(ratio_dev, 1.0)

    # Weighted ensemble (simulating RF)
    score = 0.35 * fork_score + 0.35 * stale_score + 0.30 * ratio_score
    return score > 0.4, min(score * 1.2, 1.0)


# ---- Detector 5: SeMi_Detector (MLP-based) ----
def detect_semi(tracker, alpha):
    """
    Bao et al. 2025: MLP-based classification.
    Features: block timing patterns, fork characteristics, attacker behavior.
    Simplified MLP scoring function.
    """
    max_consec, _ = tracker.get_consecutive_stats()
    fork_rate = tracker.get_fork_rate()
    stale_rate = tracker.get_stale_rate()
    attacker_ratio = tracker.get_attacker_ratio()

    # Feature vector (normalized)
    f = [
        min(max_consec / 4.0, 1.0),                          # consecutive blocks
        min(fork_rate / 0.05, 1.0),                           # fork rate
        min(stale_rate / 1.0, 1.0),                            # stale rate
        max(0, min((attacker_ratio - alpha) / max(alpha, 0.01), 1.0)),  # ratio dev
        min(len(tracker.fork_lengths) / 100.0, 1.0),          # total forks
    ]

    # MLP-like weighted scoring (simplified 5→8→4→1 network)
    # Hidden layer 1
    h1 = [
        max(0, 0.3*f[0] + 0.2*f[1] + 0.3*f[2] + 0.1*f[3] + 0.1*f[4]),
        max(0, 0.1*f[0] + 0.3*f[1] + 0.2*f[2] + 0.3*f[3] + 0.1*f[4]),
        max(0, 0.2*f[0] + 0.2*f[1] + 0.2*f[2] + 0.2*f[3] + 0.2*f[4]),
        max(0, 0.1*f[0] + 0.1*f[1] + 0.3*f[2] + 0.2*f[3] + 0.3*f[4]),
    ]
    # Hidden layer 2
    h2 = [
        max(0, 0.3*h1[0] + 0.4*h1[1] + 0.2*h1[2] + 0.1*h1[3]),
        max(0, 0.2*h1[0] + 0.2*h1[1] + 0.4*h1[2] + 0.2*h1[3]),
    ]
    # Output
    logit = 0.5*h2[0] + 0.5*h2[1]
    prob = 1.0 / (1.0 + math.exp(-(logit - 0.6)))  # sigmoid with bias
    return prob > 0.5, prob


# ============================================================
# SM1 with Detection: Modified simulation
# ============================================================
def simulate_sm1_with_detector(alpha, gamma, block_num, nb_simulations, detector_fn, la_def=None):
    """
    SM1 simulation where honest miners use detection to adjust behavior.
    When attack detected: gamma (follow fraction) is reduced.
    Returns (rela_att, rela_other, fork_rate, stale_rate, honest_survival_rate).
    """
    private_chain = 0
    public_chain = 0
    honest_valid = 0
    selfish_valid = 0
    counter = 0
    effective_gamma = gamma
    honest_mined = 0
    honest_orphaned = 0
    attacker_won_forks = 0

    tracker = BlockchainTracker()

    while counter < nb_simulations:
        counter += 1
        delta = private_chain - public_chain

        # Periodic detection
        if counter % DETECT_INTERVAL == 0:
            if la_def is not None:
                la_def.update(tracker)
                effective_gamma = la_def.get_effective_gamma(gamma)
            elif detector_fn is not None:
                is_attack, conf = detector_fn(tracker, alpha)
                if is_attack and conf > DETECT_THRESHOLD:
                    reduction = conf * 0.7
                    effective_gamma = gamma * (1.0 - reduction)
                else:
                    effective_gamma = gamma

        if random.random() <= alpha:
            # Attacker mines
            private_chain += 1
            tracker.record_mine('attacker', counter)

            if delta == 0 and private_chain == 2:
                # Publish 2 blocks
                private_chain, public_chain = 0, 0
                selfish_valid += 2
        else:
            # Honest mines
            public_chain += 1
            honest_mined += 1
            tracker.record_mine('honest', counter)

            if delta == 0:
                honest_valid += 1
                if private_chain > 0:
                    # Fork! Honest miner found competing block
                    tracker.record_fork(private_chain, counter - tracker.last_fork_time)
                    tracker.last_fork_time = counter

                    if random.random() <= effective_gamma:
                        selfish_valid += 1  # Attacker's block wins
                        honest_orphaned += 1
                        attacker_won_forks += 1
                    else:
                        honest_valid += 1   # Honest block wins
                private_chain, public_chain = 0, 0

            elif delta >= 2:
                # Attacker reveals private chain
                tracker.record_fork(private_chain, counter - tracker.last_fork_time)
                tracker.last_fork_time = counter
                tracker.record_stale()
                attacker_won_forks += 1
                honest_orphaned += public_chain
                selfish_valid += private_chain
                private_chain, public_chain = 0, 0

        total_mined = honest_valid + selfish_valid
        if total_mined >= block_num:
            break

    # Finalize
    if private_chain > public_chain:
        selfish_valid += private_chain

    total = honest_valid + selfish_valid
    if total == 0:
        return 0.0, 1.0, 0.0, 0.0, 1.0

    # Attacker fork success rate: fraction of forks won by attacker
    att_fork_rate = attacker_won_forks / max(tracker.total_forks, 1)
    stale_rate = tracker.stale_count / max(tracker.total_forks + 1, 1)
    surv_rate = 1.0 - honest_orphaned / max(honest_mined, 1)
    return round(selfish_valid / total, 4), round(honest_valid / total, 4), round(att_fork_rate, 4), round(stale_rate, 4), round(surv_rate, 4)


# ============================================================
# Run all experiments
# ============================================================
def compute_confirmation_time(rela_att, survival_rate, p_target=0.001):
    """Compute expected blocks needed for safe confirmation.

    Uses the attacker's effective revenue share (rela_att) and honest block survival rate
    to estimate the number of blocks required to achieve safety probability p_target.
    Returns float('inf') if the attacker's effective share exceeds 50%.
    """
    if (rela_att != rela_att) or (survival_rate != survival_rate):
        return float('nan')
    if survival_rate <= 0:
        return float('inf')
    q_eff = max(rela_att, 0.0)
    if q_eff <= 0.0:
        # Attacker has zero effective power → 1 confirmation suffices
        return round(1.0 / survival_rate, 2)
    if q_eff >= 0.5:
        return float('inf')
    p_eff = 1.0 - q_eff
    # Required confirmations z: (q/p)^z < p_target
    from math import log, ceil
    z_safety = max(1, ceil(log(p_target) / log(q_eff / p_eff)))
    return round(z_safety / survival_rate, 2)


def run_all(beta):
    """Run experiments for a specific beta. Detection results are beta-independent."""
    # Load ErMine results
    ermine_results = {}
    csv_path = os.path.join(os.path.dirname(__file__), "Result", "output1.csv")
    if os.path.exists(csv_path):
        with open(csv_path, "r") as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        grouped = defaultdict(lambda: {'rela_att': [], 'rela_agent': [], 'rela_other': [],
                                        'fork_rate': [], 'honest_survival': []})
        has_fork_data = 'fork_rate' in (reader.fieldnames or [])
        for row in rows:
            a = float(row['alpha'])
            b = float(row['beta'])
            grouped[(a, b)]['rela_att'].append(float(row['rela_att']))
            grouped[(a, b)]['rela_agent'].append(float(row['rela_agent']))
            grouped[(a, b)]['rela_other'].append(float(row['rela_other']))
            if has_fork_data and row.get('fork_rate', '') != '':
                grouped[(a, b)]['fork_rate'].append(min(1.0, max(0.0, float(row['fork_rate']))))
            if has_fork_data and row.get('honest_survival', '') != '':
                grouped[(a, b)]['honest_survival'].append(min(1.0, max(0.0, float(row['honest_survival']))))
        for (a, b), vals in grouped.items():
            result = {
                'rela_att': round(statistics.mean(vals['rela_att']), 4),
                'rela_agent': round(statistics.mean(vals['rela_agent']), 4),
                'rela_other': round(statistics.mean(vals['rela_other']), 4),
            }
            if vals['fork_rate']:
                result['fork_rate'] = round(statistics.mean(vals['fork_rate']), 4)
            if vals['honest_survival']:
                result['honest_survival'] = round(statistics.mean(vals['honest_survival']), 4)
            ermine_results[(a, b)] = result

    all_results = []

    for alpha in ALPHAS:
        print(f"  Alpha = {alpha}")

        # --- Honest Baseline ---
        honest_att = alpha
        honest_agent = beta
        honest_other = round(1.0 - alpha - beta, 4)
        honest_fork_rate = 0.0
        honest_survival_rate = 1.0

        # --- Theoretical ---
        theo_rela_att = util.SM1_theoretical_gain(alpha, GAMMA_DEFAULT)
        theo_rela_agent = util.Agent_theoreticle_gain(alpha, beta, GAMMA_DEFAULT)
        theo_rela_other = round(1.0 - theo_rela_att - theo_rela_agent, 4)

        # --- SM1 (no defense) ---
        sm1_att_vals, sm1_other_vals = [], []
        sm1_fork_vals, sm1_surv_vals = [], []
        for _ in range(TRIALS):
            sim = SM1Simulator(alpha, GAMMA_DEFAULT)
            ra, ro, fr, sr = sim.simulate(BLOCK_NUM, NB_SIMULATIONS)
            sm1_att_vals.append(ra)
            sm1_other_vals.append(ro)
            sm1_fork_vals.append(fr)
            sm1_surv_vals.append(sr)
        sm1_result = (round(statistics.mean(sm1_att_vals), 4),
                      round(statistics.mean(sm1_other_vals), 4))
        sm1_fork_rate = round(statistics.mean(sm1_fork_vals), 4)
        sm1_survival = round(statistics.mean(sm1_surv_vals), 4)

        # --- Non-Parametric ---
        np_att, np_other = [], []
        np_fork, np_stale, np_surv = [], [], []
        for _ in range(TRIALS):
            ra, ro, fr, sr_, sv = simulate_sm1_with_detector(alpha, GAMMA_DEFAULT, BLOCK_NUM, NB_SIMULATIONS,
                                                detect_nonparametric)
            np_att.append(ra); np_other.append(ro)
            np_fork.append(fr); np_stale.append(sr_); np_surv.append(sv)
        np_result = (round(statistics.mean(np_att), 4), round(statistics.mean(np_other), 4))
        np_fork_rate = round(statistics.mean(np_fork), 4)
        np_stale_rate = round(statistics.mean(np_stale), 4)
        np_survival = round(statistics.mean(np_surv), 4)

        # --- ForkDec ---
        fd_att, fd_other = [], []
        fd_fork, fd_stale, fd_surv = [], [], []
        for _ in range(TRIALS):
            ra, ro, fr, sr_, sv = simulate_sm1_with_detector(alpha, GAMMA_DEFAULT, BLOCK_NUM, NB_SIMULATIONS,
                                                detect_forkdec)
            fd_att.append(ra); fd_other.append(ro)
            fd_fork.append(fr); fd_stale.append(sr_); fd_surv.append(sv)
        fd_result = (round(statistics.mean(fd_att), 4), round(statistics.mean(fd_other), 4))
        fd_fork_rate = round(statistics.mean(fd_fork), 4)
        fd_stale_rate = round(statistics.mean(fd_stale), 4)
        fd_survival = round(statistics.mean(fd_surv), 4)

        # --- Learning Automata ---
        la_att, la_other = [], []
        la_fork, la_stale, la_surv = [], [], []
        for _ in range(TRIALS):
            la_def = LADefense()
            ra, ro, fr, sr_, sv = simulate_sm1_with_detector(alpha, GAMMA_DEFAULT, BLOCK_NUM, NB_SIMULATIONS,
                                                None, la_def)
            la_att.append(ra); la_other.append(ro)
            la_fork.append(fr); la_stale.append(sr_); la_surv.append(sv)
        la_result = (round(statistics.mean(la_att), 4), round(statistics.mean(la_other), 4))
        la_fork_rate = round(statistics.mean(la_fork), 4)
        la_stale_rate = round(statistics.mean(la_stale), 4)
        la_survival = round(statistics.mean(la_surv), 4)

        # --- Efficient Detection (RF) ---
        ef_att, ef_other = [], []
        ef_fork, ef_stale, ef_surv = [], [], []
        for _ in range(TRIALS):
            ra, ro, fr, sr_, sv = simulate_sm1_with_detector(alpha, GAMMA_DEFAULT, BLOCK_NUM, NB_SIMULATIONS,
                                                detect_efficient)
            ef_att.append(ra); ef_other.append(ro)
            ef_fork.append(fr); ef_stale.append(sr_); ef_surv.append(sv)
        ef_result = (round(statistics.mean(ef_att), 4), round(statistics.mean(ef_other), 4))
        ef_fork_rate = round(statistics.mean(ef_fork), 4)
        ef_stale_rate = round(statistics.mean(ef_stale), 4)
        ef_survival = round(statistics.mean(ef_surv), 4)

        # --- SeMi_Detector (MLP) ---
        semi_att, semi_other = [], []
        semi_fork, semi_stale, semi_surv = [], [], []
        for _ in range(TRIALS):
            ra, ro, fr, sr_, sv = simulate_sm1_with_detector(alpha, GAMMA_DEFAULT, BLOCK_NUM, NB_SIMULATIONS,
                                                detect_semi)
            semi_att.append(ra); semi_other.append(ro)
            semi_fork.append(fr); semi_stale.append(sr_); semi_surv.append(sv)
        semi_result = (round(statistics.mean(semi_att), 4), round(statistics.mean(semi_other), 4))
        semi_fork_rate = round(statistics.mean(semi_fork), 4)
        semi_stale_rate = round(statistics.mean(semi_stale), 4)
        semi_survival = round(statistics.mean(semi_surv), 4)

        # --- ErMine ---
        erm_key = (round(alpha, 2), round(beta, 2))
        erm = ermine_results.get(erm_key)
        if erm is None:
            best_key, best_dist = None, float('inf')
            for k in ermine_results:
                dist = abs(k[0] - alpha) + abs(k[1] - beta)
                if dist < best_dist:
                    best_dist, best_key = dist, k
            erm = ermine_results.get(best_key, {})
        erm_att = erm.get('rela_att', float('nan'))
        erm_agent = erm.get('rela_agent', float('nan'))
        erm_other = erm.get('rela_other', float('nan'))
        erm_fork_rate = erm.get('fork_rate', float('nan'))
        erm_stale_rate = erm.get('stale_rate', float('nan'))
        erm_survival = erm.get('honest_survival', float('nan'))

        all_results.append({
            'alpha': alpha, 'beta': beta,
            'honest_att': honest_att, 'honest_agent': honest_agent, 'honest_other': honest_other,
            'sm1_att': sm1_result[0], 'sm1_other': sm1_result[1],
            'theo_att': theo_rela_att, 'theo_agent': theo_rela_agent, 'theo_other': theo_rela_other,
            'ermine_att': erm_att, 'ermine_agent': erm_agent, 'ermine_other': erm_other,
            'nonparam_att': np_result[0], 'nonparam_other': np_result[1],
            'forkdec_att': fd_result[0], 'forkdec_other': fd_result[1],
            'la_att': la_result[0], 'la_other': la_result[1],
            'efficient_att': ef_result[0], 'efficient_other': ef_result[1],
            'semi_att': semi_result[0], 'semi_other': semi_result[1],
            # Fork rate & block confirmation metrics
            'honest_fork_rate': honest_fork_rate, 'honest_survival_rate': honest_survival_rate,
            'sm1_fork_rate': sm1_fork_rate, 'sm1_stale_rate': 0.0, 'sm1_survival_rate': sm1_survival,
            'nonparam_fork_rate': np_fork_rate, 'nonparam_stale_rate': np_stale_rate, 'nonparam_survival_rate': np_survival,
            'forkdec_fork_rate': fd_fork_rate, 'forkdec_stale_rate': fd_stale_rate, 'forkdec_survival_rate': fd_survival,
            'la_fork_rate': la_fork_rate, 'la_stale_rate': la_stale_rate, 'la_survival_rate': la_survival,
            'efficient_fork_rate': ef_fork_rate, 'efficient_stale_rate': ef_stale_rate, 'efficient_survival_rate': ef_survival,
            'semi_fork_rate': semi_fork_rate, 'semi_stale_rate': semi_stale_rate, 'semi_survival_rate': semi_survival,
            'ermine_fork_rate': erm_fork_rate, 'ermine_stale_rate': erm_stale_rate, 'ermine_survival_rate': erm_survival,
            # Confirmation time (expected blocks for 99.9% safety)
            'honest_confirmation_time': compute_confirmation_time(honest_att, honest_survival_rate),
            'sm1_confirmation_time': compute_confirmation_time(sm1_result[0], sm1_survival),
            'ermine_confirmation_time': compute_confirmation_time(erm_att, erm_survival),
            'nonparam_confirmation_time': compute_confirmation_time(np_result[0], np_survival),
            'forkdec_confirmation_time': compute_confirmation_time(fd_result[0], fd_survival),
            'la_confirmation_time': compute_confirmation_time(la_result[0], la_survival),
            'efficient_confirmation_time': compute_confirmation_time(ef_result[0], ef_survival),
            'semi_confirmation_time': compute_confirmation_time(semi_result[0], semi_survival),
        })

    return all_results


# ============================================================
# Print tables
# ============================================================
def print_tables(results, beta):
    print("\n\n")
    print("=" * 135)
    print(f"FINAL RESULTS (beta = {beta}): Selfish Mining Detection/Defense Methods Comparison")
    print(f"(gamma = {GAMMA_DEFAULT}, block_num = {BLOCK_NUM}, trials = {TRIALS})")
    print("=" * 135)

    # === TABLE 1: Malicious Miner Revenue ===
    print("\n" + "=" * 135)
    print("TABLE 1: MALICIOUS MINER (Attacker) RELATIVE REVENUE")
    print("         Lower = better defense. Honest baseline = alpha (proportional).")
    print("=" * 135)
    header = (f"{'alpha':<8} {'Honest':<10} {'SM1(no def)':<14} {'Theoretical':<14} "
              f"{'ErMine':<10} {'Non-Param':<11} {'ForkDec':<10} "
              f"{'LA Defense':<12} {'EfficientRF':<14} {'SeMi(MLP)':<12}")
    print(header)
    print("-" * 135)
    for r in results:
        print(f"{r['alpha']:<8} {r['honest_att']:<10.4f} {r['sm1_att']:<14.4f} {r['theo_att']:<14.4f} "
              f"{r['ermine_att']:<10.4f} {r['nonparam_att']:>10.4f}  {r['forkdec_att']:>9.4f}  "
              f"{r['la_att']:>11.4f}  {r['efficient_att']:>13.4f}  {r['semi_att']:>11.4f}")

    # === TABLE 2: Attacker Extra Gain ===
    print("\n" + "=" * 135)
    print("TABLE 2: MALICIOUS MINER EXTRA REVENUE (rela_att - alpha)")
    print("         Positive = attacker profits from selfish mining. Closer to 0 = better defense.")
    print("=" * 135)
    header = (f"{'alpha':<8} {'SM1(no def)':<14} {'Theoretical':<14} "
              f"{'ErMine':<10} {'Non-Param':<11} {'ForkDec':<10} "
              f"{'LA Defense':<12} {'EfficientRF':<14} {'SeMi(MLP)':<12}")
    print(header)
    print("-" * 135)
    for r in results:
        a = r['alpha']
        print(f"{a:<8} {r['sm1_att']-a:>+13.4f}  {r['theo_att']-a:>+13.4f}  "
              f"{r['ermine_att']-a:>+9.4f}  {r['nonparam_att']-a:>+10.4f}  {r['forkdec_att']-a:>+9.4f}  "
              f"{r['la_att']-a:>+11.4f}  {r['efficient_att']-a:>+13.4f}  {r['semi_att']-a:>+11.4f}")

    # === TABLE 3: Honest Miner Revenue ===
    print("\n" + "=" * 135)
    print("TABLE 3: HONEST MINER RELATIVE REVENUE")
    print("         Higher = better defense (honest miners earn their fair share).")
    print("=" * 135)
    header = (f"{'alpha':<8} {'Honest':<10} {'SM1(no def)':<14} {'Theoretical':<14} "
              f"{'ErMine':<10} {'Non-Param':<11} {'ForkDec':<10} "
              f"{'LA Defense':<12} {'EfficientRF':<14} {'SeMi(MLP)':<12}")
    print(header)
    print("-" * 135)
    for r in results:
        print(f"{r['alpha']:<8} {r['honest_other']:<10.4f} {r['sm1_other']:<14.4f} {r['theo_other']:<14.4f} "
              f"{r['ermine_other']:<10.4f} {r['nonparam_other']:>10.4f}  {r['forkdec_other']:>9.4f}  "
              f"{r['la_other']:>11.4f}  {r['efficient_other']:>13.4f}  {r['semi_other']:>11.4f}")

    # === TABLE 4: Detection Effectiveness ===
    print("\n" + "=" * 135)
    print("TABLE 4: DETECTION EFFECTIVENESS - Attacker Advantage Reduction (%)")
    print("         Higher % = more effective detection/defense")
    print("=" * 135)
    header = (f"{'alpha':<8} {'ErMine':<10} {'Non-Param':<11} {'ForkDec':<10} "
              f"{'LA Defense':<12} {'EfficientRF':<14} {'SeMi(MLP)':<12}")
    print(header)
    print("-" * 80)
    for r in results:
        a = r['alpha']
        sm1_gain = r['sm1_att'] - a
        if sm1_gain > 0.001:
            erm_reduct = max(0, (sm1_gain - (r['ermine_att'] - a)) / sm1_gain * 100)
            np_reduct = max(0, (sm1_gain - (r['nonparam_att'] - a)) / sm1_gain * 100)
            fd_reduct = max(0, (sm1_gain - (r['forkdec_att'] - a)) / sm1_gain * 100)
            la_reduct = max(0, (sm1_gain - (r['la_att'] - a)) / sm1_gain * 100)
            ef_reduct = max(0, (sm1_gain - (r['efficient_att'] - a)) / sm1_gain * 100)
            semi_reduct = max(0, (sm1_gain - (r['semi_att'] - a)) / sm1_gain * 100)
            print(f"{a:<8} {erm_reduct:>9.1f}%  {np_reduct:>9.1f}%  {fd_reduct:>8.1f}%  "
                  f"{la_reduct:>10.1f}%  {ef_reduct:>12.1f}%  {semi_reduct:>9.1f}%")
        else:
            print(f"{a:<8} {'N/A':<10} {'N/A':<11} {'N/A':<10} {'N/A':<12} {'N/A':<14} {'N/A':<12}")

    # === TABLE 5: Rational Miner (Agent) Revenue ===
    print("\n" + "=" * 135)
    print(f"TABLE 5: RATIONAL MINER (Agent) RELATIVE REVENUE (beta = {beta})")
    print("         Higher = agent earns more. Theoretical is under SM1 (agent mines honestly).")
    print("=" * 135)
    header = (f"{'alpha':<8} {'Honest':<10} {'Theoretical':<14} {'ErMine':<10}")
    print(header)
    print("-" * 60)
    for r in results:
        print(f"{r['alpha']:<8} {r['honest_agent']:<10.4f} {r['theo_agent']:<14.4f} "
              f"{r['ermine_agent']:<10.4f}")


# ============================================================
# Main
# ============================================================
if __name__ == '__main__':
    random.seed(42)

    for beta in BETAS:
        print("\n" + "=" * 100)
        print(f"RUNNING EXPERIMENTS FOR BETA = {beta}")
        print(f"({len(ALPHAS)} alpha values, gamma={GAMMA_DEFAULT}, {TRIALS} trials each)")
        print("=" * 100)

        results = run_all(beta)
        print_tables(results, beta)

        # Save CSV
        csv_out = os.path.join(os.path.dirname(__file__), "Result", f"comprehensive_results_beta{beta}.csv")
        fields = [
            'alpha', 'beta',
            'honest_att', 'honest_agent', 'honest_other',
            'sm1_att', 'sm1_other',
            'theo_att', 'theo_agent', 'theo_other',
            'ermine_att', 'ermine_agent', 'ermine_other',
            'nonparam_att', 'nonparam_other',
            'forkdec_att', 'forkdec_other',
            'la_att', 'la_other',
            'efficient_att', 'efficient_other',
            'semi_att', 'semi_other',
            # Fork rate & block confirmation metrics
            'honest_fork_rate', 'honest_survival_rate',
            'sm1_fork_rate', 'sm1_stale_rate', 'sm1_survival_rate',
            'nonparam_fork_rate', 'nonparam_stale_rate', 'nonparam_survival_rate',
            'forkdec_fork_rate', 'forkdec_stale_rate', 'forkdec_survival_rate',
            'la_fork_rate', 'la_stale_rate', 'la_survival_rate',
            'efficient_fork_rate', 'efficient_stale_rate', 'efficient_survival_rate',
            'semi_fork_rate', 'semi_stale_rate', 'semi_survival_rate',
            'ermine_fork_rate', 'ermine_stale_rate', 'ermine_survival_rate',
            # Confirmation time
            'honest_confirmation_time', 'sm1_confirmation_time',
            'ermine_confirmation_time', 'nonparam_confirmation_time',
            'forkdec_confirmation_time', 'la_confirmation_time',
            'efficient_confirmation_time', 'semi_confirmation_time',
        ]
        with open(csv_out, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(results)
        print(f"\nResults saved to: {csv_out}")
        print("=" * 135)
