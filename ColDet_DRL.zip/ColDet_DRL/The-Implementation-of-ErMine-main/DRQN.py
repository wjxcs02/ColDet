import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import csv
from env import Environment  # 假设已改为隐马尔可夫环境
import util

# 超参数
BATCH_SIZE = 32  # 网络训练的批大小
LEARNING_RATE = 0.001  # 学习率
EPSILON = 0.9  # 贪婪策略
GAMMA = 0.9  # 折扣因子
TARGET_REPLACE_ITER = 100  # 目标网络更新频率
MEMORY_CAPACITY = 2000  # 经验缓冲区大小
EPISODE_NUM = 5  # 训练 episodes 数量
SEQ_LEN = 10  # LSTM序列长度（用于记忆历史观测）

# 挖矿参数
TOTAL_ROUNDS = 10000
ALPHA = 0.3
AGENT_POWER = 0.3
FOLLOW_FRACTION = 0.5
COST_FACTOR = 0.1

# 动作和状态空间维度（关键修改：动作空间改为4，匹配隐马尔可夫环境）
N_ACTIONS = 4  # 环境动作空间为0-3（mine, stop, follow_a, follow_b）
N_STATES = 4  # 观测状态维度保持4


class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.lstm = nn.LSTM(
            input_size=N_STATES,
            hidden_size=64,
            num_layers=1,
            batch_first=True
        )
        self.fc = nn.Linear(64, 32)
        self.fc.weight.data.normal_(0, 0.1)
        self.out = nn.Linear(32, N_ACTIONS)  # 输出维度改为4
        self.out.weight.data.normal_(0, 0.1)

    def forward(self, x, hidden=None):
        # x形状: (batch_size, seq_len, input_size)
        batch_size = x.size(0)

        # 初始化隐藏状态（关键修改：移除x.device，避免未指定设备报错）
        if hidden is None:
            h0 = torch.zeros(1, batch_size, 64)  # 不指定设备，默认使用CPU
            c0 = torch.zeros(1, batch_size, 64)
            hidden = (h0, c0)
        else:
            # 隐藏状态与输入在同一设备（默认CPU）
            h0, c0 = hidden
            hidden = (h0, c0)

        # LSTM前向传播（利用历史序列记忆隐藏状态）
        lstm_out, hidden = self.lstm(x, hidden)

        # 取最后一个时间步的输出（综合历史信息的决策依据）
        last_out = lstm_out[:, -1, :]

        # 全连接层处理
        x = F.relu(self.fc(last_out))
        actions_value = self.out(x)
        return actions_value, hidden  # 返回动作价值和更新后的隐藏状态


class DRQN(object):
    def __init__(self):
        self.eval_net, self.target_net = Net(), Net()
        self.learn_step_counter = 0
        self.memory_counter = 0
        # 经验缓冲区大小调整（匹配SEQ_LEN*N_STATES*2 + 2，包含状态序列、动作、奖励）
        self.memory = np.zeros((MEMORY_CAPACITY, SEQ_LEN * N_STATES * 2 + 2))
        self.optimizer = torch.optim.Adam(self.eval_net.parameters(), lr=LEARNING_RATE)
        self.loss_func = nn.MSELoss()

        # 存储最近的观测状态（用于构建LSTM输入序列，适配部分可观测性）
        self.recent_obs = []
        # 推理时的LSTM隐藏状态（记忆历史信息，辅助估计隐藏状态）
        self.inference_hidden = None

    def choose_action(self, obs, reset_hidden=False):
        # 维护观测序列（关键：用历史观测辅助估计隐藏状态）
        self.recent_obs.append(obs)
        if len(self.recent_obs) > SEQ_LEN:
            self.recent_obs.pop(0)
        # 不足SEQ_LEN时用零填充（保证序列长度固定）
        while len(self.recent_obs) < SEQ_LEN:
            self.recent_obs.insert(0, np.zeros_like(obs))

        # 转换为LSTM输入格式：(1, SEQ_LEN, N_STATES)
        obs_seq = np.array(self.recent_obs).reshape(1, SEQ_LEN, N_STATES)
        x = torch.FloatTensor(obs_seq)

        # 重置隐藏状态（如episode开始时）
        if reset_hidden:
            self.inference_hidden = None

        # ε-贪婪策略选择动作
        if np.random.uniform() < EPSILON:
            # 用评估网络和当前隐藏状态决策（利用历史记忆）
            actions_value, self.inference_hidden = self.eval_net(x, self.inference_hidden)
            action = torch.max(actions_value, 1)[1].item()
        else:
            # 随机探索（动作空间为0-3）
            action = np.random.randint(0, N_ACTIONS)
        return action

    def choose_action_by_target_net(self, obs, reset_hidden=False):
        # 与choose_action逻辑一致，仅使用目标网络
        self.recent_obs.append(obs)
        if len(self.recent_obs) > SEQ_LEN:
            self.recent_obs.pop(0)
        while len(self.recent_obs) < SEQ_LEN:
            self.recent_obs.insert(0, np.zeros_like(obs))

        obs_seq = np.array(self.recent_obs).reshape(1, SEQ_LEN, N_STATES)
        x = torch.FloatTensor(obs_seq)

        if reset_hidden:
            self.inference_hidden = None

        if np.random.uniform() < EPSILON:
            actions_value, self.inference_hidden = self.target_net(x, self.inference_hidden)
            action = torch.max(actions_value, 1)[1].item()
        else:
            action = np.random.randint(0, N_ACTIONS)
        return action

    def store_transition(self, s_seq, a, r, s_seq_):
        # 存储状态序列、动作、奖励、下一状态序列
        s_seq_flat = s_seq.flatten()
        s_seq__flat = s_seq_.flatten()
        transition = np.hstack((s_seq_flat, [a, r], s_seq__flat))
        index = self.memory_counter % MEMORY_CAPACITY
        self.memory[index, :] = transition
        self.memory_counter += 1

    def learn(self):
        # 更新目标网络
        if self.learn_step_counter % TARGET_REPLACE_ITER == 0:
            self.target_net.load_state_dict(self.eval_net.state_dict())
        self.learn_step_counter += 1

        # 从缓冲区采样批次
        sample_index = np.random.choice(MEMORY_CAPACITY, BATCH_SIZE)
        b_memory = self.memory[sample_index, :]

        # 解析经验（状态序列、动作、奖励、下一状态序列）
        seq_state_size = SEQ_LEN * N_STATES
        b_s_seq = torch.FloatTensor(b_memory[:, :seq_state_size]).view(BATCH_SIZE, SEQ_LEN, N_STATES)
        b_a = torch.LongTensor(b_memory[:, seq_state_size:seq_state_size + 1].astype(int))
        b_r = torch.FloatTensor(b_memory[:, seq_state_size + 1:seq_state_size + 2])
        b_s_seq_ = torch.FloatTensor(b_memory[:, -seq_state_size:]).view(BATCH_SIZE, SEQ_LEN, N_STATES)

        # 计算当前Q值（忽略训练时的隐藏状态，让LSTM自动初始化）
        q_eval, _ = self.eval_net(b_s_seq)
        q_eval = q_eval.gather(1, b_a)

        # 计算目标Q值（下一状态的最大Q值）
        q_next, _ = self.target_net(b_s_seq_)
        q_next = q_next.detach()  # 不参与梯度更新
        q_target = b_r + GAMMA * q_next.max(1)[0].view(BATCH_SIZE, 1)

        # 优化损失
        loss = self.loss_func(q_eval, q_target)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

    def flush_buffer(self):
        # 重置缓冲区和状态（每个episode开始时）
        self.learn_step_counter = 0
        self.memory_counter = 0
        self.memory = np.zeros((MEMORY_CAPACITY, SEQ_LEN * N_STATES * 2 + 2))
        self.recent_obs = []  # 清空历史观测
        self.inference_hidden = None  # 重置隐藏状态


def training_op(env, model_path, alpha, beta):
    drqn = DRQN()

    for i in range(EPISODE_NUM):
        print(f'<<<<<<<<< Episode: {i}')
        obs = env.reset()  # 初始观测（部分可观测状态）
        drqn.flush_buffer()  # 重置DRQN状态

        # 初始化观测序列（适配LSTM输入）
        obs_sequence = [obs for _ in range(SEQ_LEN)]

        while True:
            # 选择动作（首次调用时重置隐藏状态）
            a = drqn.choose_action(obs, reset_hidden=(len(drqn.recent_obs) == 0))

            # 执行动作（与隐马尔可夫环境交互）
            obs_, r, done, info = env.step(obs, a)

            # 更新观测序列（记录历史，辅助下一决策）
            obs_sequence.append(obs_)
            obs_sequence.pop(0)
            next_obs_sequence = obs_sequence.copy()
            next_obs_sequence.append(obs_)
            next_obs_sequence.pop(0)

            # 存储经验（观测序列而非单个状态）
            drqn.store_transition(np.array(obs_sequence), a, r, np.array(next_obs_sequence))

            # 更新当前观测
            obs = obs_

            # 缓冲区满后开始学习
            if drqn.memory_counter > MEMORY_CAPACITY:
                drqn.learn()

            if done:
                print(f'>>>>>>>>>>> Episode {i} finish: \n')
                # 计算相对奖励
                rela_att, rela_agent, rela_other = util.rela_reward_calculate(
                    env.total_valid_blocks,
                    env.attacker_valid_blocks,
                    env.agent_valid_blocks
                )
                # 获取分叉率和诚实区块存活率
                fork_rate, honest_survival_rate = env.get_fork_metrics()
                # 安全裁剪到 [0,1] 区间
                fork_rate = min(1.0, max(0.0, fork_rate))
                honest_survival_rate = min(1.0, max(0.0, honest_survival_rate))
                # 写入结果（包含分叉率指标）
                output_data = [alpha, beta, i, rela_att, rela_agent, rela_other,
                               fork_rate, honest_survival_rate]
                with open('Result/output1.csv', 'a', newline='') as file:
                    writer = csv.writer(file)
                    if file.tell() == 0:  # 首次写入时添加表头
                        writer.writerow(['alpha', 'beta', 'episode', 'rela_att', 'rela_agent', 'rela_other',
                                         'fork_rate', 'honest_survival'])
                    writer.writerow(output_data)
                break

    # 保存模型（关键修改：使用自定义方法保存参数，避免序列化错误）
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    torch.save({
        'eval_net': drqn.eval_net.state_dict(),
        'target_net': drqn.target_net.state_dict(),
        'optimizer': drqn.optimizer.state_dict()
    }, model_path)


def evaluate_model(drqn, env, test_episodes=10):
    """评估训练好的模型"""
    print("\n" + "=" * 50)
    print("Model Evaluation")
    print("=" * 50)

    test_results = {
        'total_rewards': [],
        'optimal_action_counts': [],
        'convergence_times': [],
        'q_value_stability': []
    }

    for test_ep in range(test_episodes):
        obs = env.reset()
        drqn.recent_obs = []  # 重置观测序列
        drqn.inference_hidden = None  # 重置LSTM状态

        episode_reward = 0
        steps = 0
        q_values_history = []

        while True:
            # 使用确定性策略（epsilon=1.0）测试
            obs_seq = []
            if len(drqn.recent_obs) == 0:
                # 初始序列
                obs_seq = [obs for _ in range(SEQ_LEN)]
            else:
                obs_seq = drqn.recent_obs.copy()
                while len(obs_seq) < SEQ_LEN:
                    obs_seq.insert(0, np.zeros_like(obs))

            obs_seq_array = np.array(obs_seq).reshape(1, SEQ_LEN, N_STATES)
            x = torch.FloatTensor(obs_seq_array)

            # 获取Q值（用于评估策略稳定性）
            with torch.no_grad():
                q_values, drqn.inference_hidden = drqn.eval_net(x, drqn.inference_hidden)
                q_values_history.append(q_values.tolist())

            # 选择最优动作（贪婪策略）
            action = torch.argmax(q_values).item()

            # 执行动作
            obs_, reward, done, info = env.step(obs, action)
            episode_reward += reward
            steps += 1

            # 更新观测序列
            drqn.recent_obs.append(obs_)
            if len(drqn.recent_obs) > SEQ_LEN:
                drqn.recent_obs.pop(0)

            obs = obs_

            if done:
                # 计算Q值稳定性
                q_values_array = np.array(q_values_history)
                q_std = np.std(q_values_array[-10:]) if len(q_values_array) >= 10 else 0

                test_results['total_rewards'].append(episode_reward)
                test_results['convergence_times'].append(steps)
                test_results['q_value_stability'].append(q_std)

                print(f"Test Episode {test_ep}: "
                      f"Reward={episode_reward:.2f}, "
                      f"Steps={steps}, "
                      f"Q-stability={q_std:.4f}")
                break

    # 计算评估指标
    avg_reward = np.mean(test_results['total_rewards'])
    std_reward = np.std(test_results['total_rewards'])
    avg_steps = np.mean(test_results['convergence_times'])
    avg_q_stability = np.mean(test_results['q_value_stability'])

    print(f"\nEvaluation Summary:")
    print(f"Average Reward: {avg_reward:.2f} ± {std_reward:.2f}")
    print(f"Average Steps per Episode: {avg_steps:.1f}")
    print(f"Q-value Stability: {avg_q_stability:.4f}")

    # 计算"准确率" - 基于奖励的达成率
    success_threshold = np.percentile(test_results['total_rewards'], 50)  # 中位数作为阈值
    success_count = sum(1 for r in test_results['total_rewards'] if r >= success_threshold)
    accuracy = success_count / test_episodes

    print(f"Success Rate (Accuracy): {accuracy:.2%}")

    return {
        'accuracy': accuracy,
        'avg_reward': avg_reward,
        'std_reward': std_reward,
        'q_stability': avg_q_stability
    }
def drqn_training():
    # 遍历参数组合训练
    alphas = [0.25, 0.3, 0.35, 0.4, 0.45]
    betas = [0.1, 0.2, 0.3, 0.35, 0.4, 0.5]

    for alpha in alphas:
        for beta in betas:
            # 初始化隐马尔可夫环境
            env = Environment(
                total_rounds=TOTAL_ROUNDS,
                attacker_power=alpha,
                agent_power=beta,
                follower_fraction=FOLLOW_FRACTION,
                cost=0
            )
            print(f"Training with alpha={alpha}, beta={beta}")
            model_path = f'C:/Users/23945/Desktop/DRQN1/drqn_{EPISODE_NUM}episodes_alpha{alpha}_beta{beta}_.pt'
            training_op(env, model_path, alpha, beta)


if __name__ == '__main__':
    drqn_training()