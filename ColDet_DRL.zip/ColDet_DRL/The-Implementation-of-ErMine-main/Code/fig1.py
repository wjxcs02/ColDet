import numpy as np
import scienceplots
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from matplotlib import patheffects
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.axes_grid1.inset_locator import inset_axes,mark_inset

import cmaps

import statistics



def count_for_cost_plot():

    #x轴
    cost_factors = np.arange(0.1, 0.6, 0.05)

    # cost_factors 相应的 stop 次数
    # lambda 从 0.1 到 1 when beta = 0.25 时 stop的次数（10000轮中）

    stop_count_for_cost_factors_alpha010=[0.021354545,0.044472727,0.107045455,0.136336364,0.1766,0.202154545,0.211890909,0.213327273,0.208836364,0.381036364,0.296545455,0.331845455,0.329127273]
    stop_count_for_cost_factors_alpha015=[0.030936364,0.060418182,0.0648,0.090390909,0.154772727,0.278845455,0.234854545,0.270372727,0.199645455,0.324009091,0.508636364,0.487272727,0.528527273]
    stop_count_for_cost_factors_alpha020=[0.034227273,0.037054545,0.102445455,0.158090909,0.201772727,0.2261,0.256818182,0.306045455,0.363290909,0.460172727,0.6393,0.5124,0.542872727]
    stop_count_for_cost_factors_alpha025 = [0.064763636,0.089609091,0.0497,0.238145455,0.248509091,0.174418182,0.335572727,0.223881818,0.487836364,0.469063636,0.576127273,0.692245455,0.646709091]
    stop_count_for_cost_factors_alpha030=[0.100390909,0.149809091,0.200427273,0.242045455,0.3827,0.360563636,0.470590909,0.569254545,0.677890909,0.874518182]
    stop_count_for_cost_factors_alpha035=[0.053054545,0.093190909,0.104118182,0.252718182,0.306627273,0.419990909,0.2772,0.5676,0.624127273,0.660309091,0.826327273,0.7757,0.87]
    stop_count_for_cost_factors_alpha040=[0.133972727,0.093163636,0.282554545,0.313827273,0.315081818,0.297163636,0.574809091,0.620409091,0.618445455,0.7256,0.749981818,0.83,0.86]
    stop_count_for_cost_factors_alpha045=[0.101436364,0.172118182,0.219290909,0.298045455,0.487709091,0.307772727,0.678254545,0.389009091,0.878127273,0.9001,0.87,0.94,0.96]
    # stop_count_for_cost_factors_alpha050=[[0.097345455,0.133409091,0.258509091,0.440718182,0.521218182,0.563054545,0.692372727,0.867545455,1,1,1,1,1]



def count_for_cost_plot_030():
    cost_factors = np.arange(0.1, 0.6, 0.05)
    # 第一张a=0.3
    # stop_count_for_cost_factors_alpha030 = [0.160390909, 0.209809091, 0.260427273, 0.352045455, 0.4927, 0.580563636,
    #                                         0.640590909, 0.679254545, 0.767890909, 0.874518182]
    stop_count_for_cost_factors_alpha030 = [0.100390909, 0.149809091, 0.200427273, 0.242045455, 0.3027, 0.360563636,
                                            0.470590909, 0.569254545, 0.677890909, 0.874518182]
    SM1030 = [0.0714, 0.119908, 0.1743, 0.2111, 0.274199, 0.316532,0.38348, 0.47063,  0.54748, 0.633918]
    befor_alpha030 = [0.09024, 0.13514, 0.18317, 0.22562, 0.28958, 0.33551, 0.419077, 0.502107, 0.5919, 0.6971]
    honset=[0.05,0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50]
    err0=[0.0756,0.0626,0.0547,0.0576,0.0426,0.0436,0.0356,0.0456,0.02356,0.0256]
    err1 = [0.075, 0.066, 0.0547, 0.056, 0.0426, 0.0316, 0.036, 0.0346, 0.02736, 0.0305]
    err2 = [0.075, 0.0766, 0.06547, 0.0656, 0.05426, 0.05316, 0.0536, 0.04346, 0.042736, 0.0355]
    err3 = [0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03]
    color_line=["#014382","#C9631B","#FDC101","#55A868"]
    color_back=['#1E90FF','#E63946','#FFB90F','#9ACD32']
    label_name=["ErMine_DQRN","ErMine_DQN","SM1","Honest"]
    markstyle=['s','o','^','d']


    x=cost_factors
    y=[stop_count_for_cost_factors_alpha030,befor_alpha030,SM1030,honset]
    err=[err0,err1,err2,err3]



    with plt.style.context(['science', 'bright', 'no-latex']):
        fig, ax = plt.subplots(figsize=(18, 11))


        #画折线
        for i in range(4):

            #插值
            f = interp1d(x, y[i], kind='linear', fill_value="extrapolate")
            f1 = interp1d(x, err[i], kind='linear', fill_value="extrapolate")
            # 插值结果
            x_new = np.linspace(0.1, 0.55, 18)
            y_new = f(x_new)
            err_re = f1(x_new)
            plt.errorbar(x_new, y_new, yerr=err_re, capsize=5, linestyle='-', linewidth=5,
                         marker=markstyle[i], markevery=1, color=color_line[i],
                         markersize=15, label=label_name[i])
            ax.fill_between(x_new,
                            np.array(y_new) - err_re,
                            np.array(y_new) + err_re,
                            alpha=0.2, color=color_back[i])

        plt.xlabel("γ", fontdict={'family': 'Times New Roman', 'size': 36})
        plt.ylabel("$R_r^{rela}$", fontdict={'family': 'Times New Roman', 'size': 36})
        # plt.title('The relative reward of Rational Miner',
        #           fontdict={'family': 'Times New Roman', 'size': 43, 'weight': 'bold'})

        plt.legend(loc='lower right', handlelength=2,
                   prop={'family': 'Times New Roman', 'size': 27})
        plt.xticks(fontproperties='Times New Roman', size=36)
        plt.yticks(fontproperties='Times New Roman', size=36)

        plt.grid(True)



        # #加竖线表示差值
        # #0.55
        # plt.plot([ cost_factors[9], cost_factors[9]], [stop_count_for_cost_factors_alpha030[9], SM1030[9]],
        #          color='red', linestyle='--', linewidth=3, alpha=0.9)
        # plt.annotate(f'Δ=0.1306',
        #              (cost_factors[9]+0.007, stop_count_for_cost_factors_alpha030[9] - 0.1),
        #              xytext=(0.55, 0.55), textcoords='offset points',
        #              fontsize=14, fontweight='bold',
        #              bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.8),
        #              verticalalignment='center')





    # 添加插图
    ax_inset = inset_axes(ax, width="50%", height="66%",bbox_to_anchor=(.09, .36, .7, .6),
                   bbox_transform=ax.transAxes, loc='upper left')

    for i in range(4):
        # 插值
        f = interp1d(x, y[i], kind='linear', fill_value="extrapolate")
        x_new = np.linspace(0.1, 0.55, 15)
        y_new = f(x_new)

        ax_inset.plot(x_new, y_new, label=label_name[i], linestyle='-',
                      color=color_line[i], marker=markstyle[i], linewidth=2.5,
                      markersize=7)



    # #0.2
    # plt.plot([cost_factors[2]-0.002, cost_factors[2]-0.002], [stop_count_for_cost_factors_alpha030[2], SM1030[2]],
    #          color='red', linestyle='--', linewidth=3, alpha=0.9)
    # plt.annotate(f'Δ=0.0261',
    #              (cost_factors[2]+0.007, stop_count_for_cost_factors_alpha030[2]-0.013),
    #              xytext=(0.2, 0.25), textcoords='offset points',
    #              fontsize=12, fontweight='bold',
    #              bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.8),
    #              verticalalignment='center')
    #
    # #0.35
    #
    #
    # plt.plot([cost_factors[5]+0.009, cost_factors[5]+0.009], [stop_count_for_cost_factors_alpha030[5]+0.02, SM1030[5]+0.006],
    #          color='red', linestyle='--', linewidth=3, alpha=0.9)
    # plt.annotate(f'Δ=0.044',
    #              (cost_factors[5] + 0.015, stop_count_for_cost_factors_alpha030[5] - 0.02),
    #              xytext=(0.2, 0.25), textcoords='offset points',
    #              fontsize=12, fontweight='bold',
    #              bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.8),
    #              verticalalignment='center')





    ax_inset.set_xlim(0.19,0.37)
    ax_inset.set_ylim(0.13, 0.385)
    mark_inset(ax, ax_inset, loc1=3, loc2=1, fc="none", ec='k', lw=0.7)  # 1 (右上) 2 (左上) 3(左下) 4(右下)
    plt.grid(True)
    ax_inset.tick_params(axis='both', which='major', labelsize=17)  # 设置刻度标签的字体大小
    plt.xticks(fontproperties='Times New Roman', size=36)
    plt.yticks(fontproperties='Times New Roman', size=36)
    plt.savefig('C:/Users/23945/Desktop/result/fig1_b030.png')
    plt.show()



def count_for_cost_plot_035():
    cost_factors = np.arange(0.1, 0.6, 0.05)
    # 第一张a=0.3
    # stop_count_for_cost_factors_alpha030 = [0.160390909, 0.209809091, 0.260427273, 0.352045455, 0.4927, 0.580563636,
    #                                         0.640590909, 0.679254545, 0.767890909, 0.874518182]
    stop_count_for_cost_factors_alpha035 = [0.093190909, 0.154118182, 0.222718182, 0.286627273, 0.359990909,
                                            0.43676, 0.504127273, 0.5857, 0.666327273, 0.812]
    SM1035 = [0.05934, 0.11361, 0.1767, 0.2266, 0.2912, 0.36988, 0.4348, 0.5076, 0.58924, 0.6681]
    befor_alpha035 = [0.0734, 0.1361, 0.197, 0.246, 0.3112, 0.38988, 0.4648, 0.5376, 0.6224, 0.6981]
    honset = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50]
    err0=[0.0756,0.0626,0.0547,0.0576,0.0426,0.0436,0.0356,0.0456,0.02356,0.0256]
    err1 = [0.075, 0.066, 0.0547, 0.056, 0.0426, 0.0316, 0.036, 0.0346, 0.02736, 0.0305]
    err2 = [0.075, 0.0766, 0.06547, 0.0656, 0.05426, 0.05316, 0.0536, 0.04346, 0.042736, 0.0355]
    err3 = [0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03]
    color_line=["#014382","#C9631B","#FDC101","#55A868"]
    color_back=['#1E90FF','#E63946','#FFB90F','#9ACD32']
    label_name=["ErMine_DQRN","ErMine_DQN","SM1","Honest"]
    markstyle=['s','o','^','d']


    x=cost_factors
    y=[stop_count_for_cost_factors_alpha035,befor_alpha035,SM1035,honset]
    err=[err0,err1,err2,err3]



    with plt.style.context(['science', 'bright', 'no-latex']):
        fig, ax = plt.subplots(figsize=(18, 11))


        #画折线
        for i in range(4):

            #插值
            f = interp1d(x, y[i], kind='linear', fill_value="extrapolate")
            f1 = interp1d(x, err[i], kind='linear', fill_value="extrapolate")
            # 插值结果
            x_new = np.linspace(0.1, 0.55, 18)
            y_new = f(x_new)
            err_re = f1(x_new)
            plt.errorbar(x_new, y_new, yerr=err_re, capsize=5, linestyle='-', linewidth=5,
                         marker=markstyle[i], markevery=1, color=color_line[i],
                         markersize=15, label=label_name[i])
            ax.fill_between(x_new,
                            np.array(y_new) - err_re,
                            np.array(y_new) + err_re,
                            alpha=0.2, color=color_back[i])

        plt.xlabel("γ", fontdict={'family': 'Times New Roman', 'size': 36})
        plt.ylabel("$R_r^{rela}$", fontdict={'family': 'Times New Roman', 'size': 36})
        # plt.title('The relative reward of Rational Miner',
        #           fontdict={'family': 'Times New Roman', 'size': 43, 'weight': 'bold'})

        plt.legend(loc='lower right', handlelength=2,
                   prop={'family': 'Times New Roman', 'size': 27})
        plt.xticks(fontproperties='Times New Roman', size=36)
        plt.yticks(fontproperties='Times New Roman', size=36)

        plt.grid(True)



        # #加竖线表示差值
        # #0.55
        # plt.plot([ cost_factors[9], cost_factors[9]], [stop_count_for_cost_factors_alpha035[9], SM1035[9]],
        #          color='red', linestyle='--', linewidth=3, alpha=0.9)
        # plt.annotate(f'Δ=0.1439',
        #              (cost_factors[9]+0.007, stop_count_for_cost_factors_alpha035[9] - 0.05),
        #              xytext=(0.55, 0.55), textcoords='offset points',
        #              fontsize=14, fontweight='bold',
        #              bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.8),
        #              verticalalignment='center')





    # 添加插图
    ax_inset = inset_axes(ax, width="50%", height="66%",bbox_to_anchor=(.09, .36, .7, .6),
                   bbox_transform=ax.transAxes, loc='upper left')

    for i in range(4):
        # 插值
        f = interp1d(x, y[i], kind='linear', fill_value="extrapolate")
        x_new = np.linspace(0.1, 0.55, 15)
        y_new = f(x_new)

        ax_inset.plot(x_new, y_new, label=label_name[i], linestyle='-',
                      color=color_line[i], marker=markstyle[i], linewidth=2.5,
                      markersize=7)



    # #0.2
    # plt.plot([cost_factors[2]-0.002, cost_factors[2]-0.002], [stop_count_for_cost_factors_alpha035[2], SM1035[2]],
    #          color='red', linestyle='--', linewidth=3, alpha=0.9)
    # plt.annotate(f'Δ=0.046',
    #              (cost_factors[2]+0.009, stop_count_for_cost_factors_alpha035[2]-0.013),
    #              xytext=(0.2, 0.25), textcoords='offset points',
    #              fontsize=12, fontweight='bold',
    #              bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.8),
    #              verticalalignment='center')
    #
    # #0.35
    # plt.plot([cost_factors[5]+0.009, cost_factors[5]+0.009], [stop_count_for_cost_factors_alpha035[5]+0.02, SM1035[5]-0.006],
    #          color='red', linestyle='--', linewidth=3, alpha=0.9)
    # plt.annotate(f'Δ=0.0668',
    #              (cost_factors[5] + 0.018, stop_count_for_cost_factors_alpha035[5] - 0.027),
    #              xytext=(0.2, 0.25), textcoords='offset points',
    #              fontsize=12, fontweight='bold',
    #              bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.8),
    #              verticalalignment='center')





    ax_inset.set_xlim(0.19,0.37)
    ax_inset.set_ylim(0.13, 0.45)
    mark_inset(ax, ax_inset, loc1=3, loc2=1, fc="none", ec='k', lw=0.7)  # 1 (右上) 2 (左上) 3(左下) 4(右下)
    plt.grid(True)
    ax_inset.tick_params(axis='both', which='major', labelsize=17)  # 设置刻度标签的字体大小
    plt.xticks(fontproperties='Times New Roman', size=36)
    plt.yticks(fontproperties='Times New Roman', size=36)
    plt.savefig('C:/Users/23945/Desktop/result/fig1_b035.png')
    plt.show()


def count_for_cost_plot_040():
    cost_factors = np.arange(0.1, 0.6, 0.05)
    stop_count_for_cost_factors_alpha040 = [0.133972727, 0.1802554545, 0.2483827273, 0.305081818,
                                            0.3909394809091, 0.4610409091, 0.545609956, 0.629981818, 0.730179, 0.83335]
    befor_alpha040 = [0.11553, 0.169898, 0.228989, 0.29385, 0.33534, 0.40051, 0.4626, 0.5357, 0.6279, 0.71335]
    SM1040 = [0.1034, 0.1614, 0.2217, 0.2762, 0.3258, 0.3851, 0.4377, 0.5107, 0.6019, 0.69971]
    honset = [0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55]
    err0=[0.0756,0.0626,0.0547,0.0576,0.0426,0.0436,0.0356,0.0456,0.02356,0.0256]
    err1 = [0.075, 0.066, 0.0547, 0.056, 0.0426, 0.0316, 0.036, 0.0346, 0.02736, 0.0305]
    err2 = [0.075, 0.0766, 0.06547, 0.0656, 0.05426, 0.05316, 0.0536, 0.04346, 0.042736, 0.0355]
    err3 = [0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03, 0.03]
    color_line=["#014382","#C9631B","#FDC101","#55A868"]
    color_back=['#1E90FF','#E63946','#FFB90F','#9ACD32']
    label_name=["ErMine_DQRN","ErMine_DQN","SM1","Honest"]
    markstyle=['s','o','^','d']


    x=cost_factors
    y=[stop_count_for_cost_factors_alpha040,befor_alpha040,SM1040,honset]
    err=[err0,err1,err2,err3]



    with plt.style.context(['science', 'bright', 'no-latex']):
        fig, ax = plt.subplots(figsize=(18, 11))


        #画折线
        for i in range(4):

            #插值
            f = interp1d(x, y[i], kind='linear', fill_value="extrapolate")
            f1 = interp1d(x, err[i], kind='linear', fill_value="extrapolate")
            # 插值结果
            x_new = np.linspace(0.1, 0.55, 18)
            y_new = f(x_new)
            err_re = f1(x_new)
            plt.errorbar(x_new, y_new, yerr=err_re, capsize=5, linestyle='-', linewidth=5,
                         marker=markstyle[i], markevery=1, color=color_line[i],
                         markersize=15, label=label_name[i])
            ax.fill_between(x_new,
                            np.array(y_new) - err_re,
                            np.array(y_new) + err_re,
                            alpha=0.2, color=color_back[i])

        plt.xlabel("γ", fontdict={'family': 'Times New Roman', 'size': 36})
        plt.ylabel("$R_r^{rela}$", fontdict={'family': 'Times New Roman', 'size': 36})
        # plt.title('The relative reward of Rational Miner',
        #           fontdict={'family': 'Times New Roman', 'size': 43, 'weight': 'bold'})

        plt.legend(loc='lower right', handlelength=2,
                   prop={'family': 'Times New Roman', 'size': 27})

        plt.xticks(fontproperties='Times New Roman', size=36)
        plt.yticks(fontproperties='Times New Roman', size=36)

        #plt.tight_layout()

        plt.grid(True)



        # #加竖线表示差值
        # #0.55
        # plt.plot([ cost_factors[9], cost_factors[9]], [stop_count_for_cost_factors_alpha040[9], SM1040[9]],
        #          color='red', linestyle='--', linewidth=3, alpha=0.9)
        # plt.annotate(f'Δ=0.2013',
        #              (cost_factors[9]+0.007, stop_count_for_cost_factors_alpha040[9] - 0.05),
        #              xytext=(0.55, 0.55), textcoords='offset points',
        #              fontsize=14, fontweight='bold',
        #              bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.8),
        #              verticalalignment='center')





    # 添加插图
    ax_inset = inset_axes(ax, width="50%", height="66%",bbox_to_anchor=(.09, .36, .7, .6),
                   bbox_transform=ax.transAxes, loc='upper left')

    for i in range(4):
        # 插值
        f = interp1d(x, y[i], kind='linear', fill_value="extrapolate")
        x_new = np.linspace(0.1, 0.55, 15)
        y_new = f(x_new)

        ax_inset.plot(x_new, y_new, label=label_name[i], linestyle='-',
                      color=color_line[i], marker=markstyle[i], linewidth=2.5,
                      markersize=7)



    # #0.2
    # plt.plot([cost_factors[2]-0.0025, cost_factors[2]-0.0025], [stop_count_for_cost_factors_alpha040[2], SM1040[2]],
    #          color='red', linestyle='--', linewidth=3, alpha=0.9)
    # plt.annotate(f'Δ=0.0869',
    #              (cost_factors[2]+0.009, stop_count_for_cost_factors_alpha040[2]-0.013),
    #              xytext=(0.2, 0.25), textcoords='offset points',
    #              fontsize=12, fontweight='bold',
    #              bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.8),
    #              verticalalignment='center')
    #
    # #0.35
    # plt.plot([cost_factors[5]+0.007, cost_factors[5]+0.007], [stop_count_for_cost_factors_alpha040[5]+0.017, SM1040[5]],
    #          color='red', linestyle='--', linewidth=3, alpha=0.9)
    # plt.annotate(f'Δ=0.1352',
    #              (cost_factors[5] + 0.018, stop_count_for_cost_factors_alpha040[5] - 0.027),
    #              xytext=(0.2, 0.25), textcoords='offset points',
    #              fontsize=12, fontweight='bold',
    #              bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.8),
    #              verticalalignment='center')





    ax_inset.set_xlim(0.19,0.37)
    ax_inset.set_ylim(0.18, 0.5)
    mark_inset(ax, ax_inset, loc1=3, loc2=1, fc="none", ec='k', lw=0.7)  # 1 (右上) 2 (左上) 3(左下) 4(右下)
    plt.grid(True)
    ax_inset.tick_params(axis='both', which='major', labelsize=17)  # 设置刻度标签的字体大小
    plt.xticks(fontproperties='Times New Roman', size=36)
    plt.yticks(fontproperties='Times New Roman', size=36)
    plt.savefig('C:/Users/23945/Desktop/result/fig1_b040.png')
    plt.show()






if __name__ == '__main__':
    # count_for_cost_plot_030()
    # count_for_cost_plot_035()
    count_for_cost_plot_040()