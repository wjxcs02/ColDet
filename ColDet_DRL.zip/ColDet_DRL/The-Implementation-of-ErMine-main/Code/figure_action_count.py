import numpy as np
import scienceplots
import matplotlib.pyplot as plt
from matplotlib import patheffects
from matplotlib.ticker import MaxNLocator

import cmaps

import statistics



def count_for_cost_plot():

    cost_factors = np.arange(0.1, 1.1, 0.1)

    # cost_factors 相应的 stop 次数
    # lambda 从 0.1 到 1 when beta = 0.25 时 stop的次数（10000轮中）

    stop_count_for_cost_factors_alpha025 = [0.4634, 0.4414, 0.4717, 0.4662, 0.4758, 0.491, 0.5177, 0.5107, 0.5319, 0.5571]
    stop_count_for_cost_factors_alpha03 = [0.4414,  0.4408 , 0.4543, 0.4712,  0.4799,  0.4948 , 0.5063,  0.5132, 0.5348,   0.5518]

    stop_count_for_cost_factors_alpha035 = [0.4491, 0.471, 0.4975, 0.494, 0.5144, 0.5261, 0.5308, 0.5421, 0.5568, 0.5496]
    stop_count_for_cost_factors_alpha04 = [0.5014, 0.5361, 0.547, 0.566, 0.5412, 0.5588, 0.5848, 0.5876, 0.6524, 0.6081]

    stop_count_for_cost_factors_alpha045 = [0.553, 0.5898, 0.5889, 0.6385, 0.6534, 0.6051, 0.6126, 0.7157, 0.6579, 0.6335]



    # fraction = []
    # for count in stop_count_for_cost_factors:
    #     fraction.append(round(count/10000, 4))

    with plt.style.context(['science', 'bright', 'no-latex']):
        fig, ax = plt.subplots(figsize=(10, 6.5))

        # 控制边框的显示与否
        # ax.spines['right'].set_visible(False)
        # ax.spines['top'].set_visible(False)
        # ax.spines['left'].set_color('none')

        # color='#C44E52',

        # ax.plot(cost_factors, stop_count_for_cost_factors_alpha025, linestyle='-', linewidth=4, marker='s', markevery=1,
        #         markersize=17, label="alpha = 0.25")

        ax.plot(cost_factors, stop_count_for_cost_factors_alpha03,  linestyle='-', linewidth=4,
                marker='s', markevery=1,
                markersize=17, label="alpha = 0.3")

        ax.plot(cost_factors, stop_count_for_cost_factors_alpha035,  linestyle='-', linewidth=4,
                marker='s', markevery=1,
                markersize=17, label="alpha = 0.35")

        ax.plot(cost_factors, stop_count_for_cost_factors_alpha04,  linestyle='-', linewidth=4,
                marker='s', markevery=1,
                markersize=17, label="alpha = 0.4")

        # ax.plot(cost_factors, stop_count_for_cost_factors_alpha045,  linestyle='-', linewidth=4,
        #         marker='s', markevery=1,
        #         markersize=17, label="alpha = 0.45")


        # 控制显示的坐标刻度的个数
        # ax.xaxis.set_major_locator(MaxNLocator(4))
        # ax.yaxis.set_major_locator(MaxNLocator(6))

        # plt.ylim(0.4, 0.85)
        # plt.xlim(0, 0.5)
        plt.xlabel(r"cost factor $\lambda$", fontdict={'family': 'Times New Roman', 'size': 35})
        plt.ylabel("fraction", fontdict={'family': 'Times New Roman', 'size': 35})

        plt.legend(loc='upper left', handlelength=2,
                   prop={'family': 'Times New Roman', 'size': 33})

        plt.xticks(fontproperties='Times New Roman', size=33)
        plt.yticks(fontproperties='Times New Roman', size=33)

        plt.show()



if __name__ == '__main__':
    count_for_cost_plot()