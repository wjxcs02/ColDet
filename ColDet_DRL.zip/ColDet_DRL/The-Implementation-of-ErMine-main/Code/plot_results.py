import matplotlib.pyplot as plt
import matplotlib
import os

matplotlib.rcParams['font.family'] = 'serif'
matplotlib.rcParams['font.size'] = 17
matplotlib.rcParams['font.serif'] = ['Times New Roman']

# ============================================================
# Hardcoded data for all three beta values
# ============================================================
DATA = {
    '0.3': {
        'alphas': [0.350000,0.383333,0.416667,0.450000,0.483333,0.516667,0.550000,0.583333,0.616667,0.650000],
        'sm1_other': [0.1661, 0.1841, 0.2057, 0.23519, 0.26915, 0.3082, 0.3269, 0.3598, 0.3785, 0.4079],


        'nonparam_other':[0.2422000,0.2713111,0.3004222,0.3295333,0.3586444,0.3877556,0.4168667,0.4459778,0.4750889,0.5042000],
        'la_other': [0.2407,0.2690,0.2973,0.3256,0.3539,0.3822,0.4105,0.4388,0.4671,0.4954],
        'efficient_other': [0.238480,0.265949,0.293418,0.320887,0.348356,0.375824,0.403293,0.430762,0.458231,0.485700],
        'semi_other': [0.22410,0.24842,0.27274,0.29707,0.32139,0.34571,0.37003,0.39436,0.41868,0.44300],
        'forkdec_other': [0.21420,0.23891,0.26362,0.28833,0.31304,0.33776,0.36247,0.38718,0.41189,0.43660],

        #'sm1_att': [0.873900,0.849356,0.818675,0.781858,0.738906,0.689817,0.654592,0.613231,0.575733,0.532100],
        'sm1_att': [0.5921,0.6215,0.6402,0.6731,0.6918,0.73085,0.76481,0.7943,0.8159,0.8339],
        #'nonparam_att': [0.76922,0.734218,0.699216,0.664213,0.629211,0.594209,0.559207,0.524204,0.489202,0.4542],
        'nonparam_att': [0.4958000,0.5249111,0.5540222,0.5831333,0.6122444,0.6413556,0.6704667,0.6995778,0.7286889,0.7578000],
        #'la_att': [0.763,0.730956,0.698911,0.666867,0.634822,0.602778,0.570733,0.538689,0.506644,0.4746],
        'la_att':[0.5046,0.5329,0.5612,0.5895,0.6178,0.6461,0.6744,0.7027,0.7310,0.7593],
        #'efficient_att': [0.7852,0.751767,0.718333,0.6849,0.651467,0.618033,0.5846,0.551167,0.517733,0.4843],
        'efficient_att':[0.514300,0.541769,0.569238,0.596707,0.624176,0.651644,0.679113,0.706582,0.734051,0.761520],
        #'semi_att': [0.7959,0.762689,0.729478,0.696267,0.663056,0.629844,0.596633,0.563422,0.530211,0.497],
        'semi_att':[0.55700,0.58132,0.60564,0.62997,0.65429,0.67861,0.70293,0.72726,0.75158,0.77590],
        #'forkdec_att': [0.8058,0.7722,0.7386,0.705,0.6714,0.6378,0.6042,0.5706,0.537,0.5034],
        'forkdec_att':[0.56340,0.58811,0.61282,0.63753,0.66224,0.68696,0.71167,0.73638,0.76109,0.78580],


        'sm1_agent': [0,0,0,0,0,0,0,0,0,0],
        'nonparam_agent': [0,0,0,0,0,0,0,0,0,0],
        'la_agent': [0,0,0,0,0,0,0,0,0,0],
        'efficient_agent': [0,0,0,0,0,0,0,0,0,0],
        'semi_agent': [0,0,0,0,0,0,0,0,0,0],
        'forkdec_agent': [0,0,0,0,0,0,0,0,0,0],



        #'ermine_att': [0.55349, 0.554, 0.4131, 0.40735, 0.23009, 0.2197, 0.025, 0.02475, 0.01465, 0.0455],
        'ermine_att':[0.0455,0.01465,0.02475, 0.025,0.2197,0.23009, 0.40735,0.4131,0.554,0.55349,],
        'ermine_agent': [0.172485, 0.1456, 0.2428, 0.2436, 0.4223, 0.4085, 0.60123, 0.5943, 0.581, 0.5777],
        'ermine_other': [0.446,0.44651,0.5869,0.59265,0.76991,0.7803,0.9545,0.975,0.97525,0.98535],
        #'ermine_other': [0.2766, 0.3104, 0.2641, 0.2663, 0.7869, 0.77918, 0.9877, 0.9882, 0.9825, 0.9868],
        'erm_att_std': [0.0985, 0.0958, 0.093, 0.1018, 0.1144, 0.1252, 0.1341, 0.1302, 0.0878, 0.0454],
        'erm_agent_std': [0.0519, 0.0516, 0.0513, 0.0504, 0.0493, 0.0517, 0.0574, 0.0561, 0.0341, 0.0121],
        'erm_other_std': [0.08, 0.0773, 0.0746, 0.0741, 0.0743, 0.0757, 0.0783, 0.0767, 0.0625, 0.0482],
    },

    '0.35': {
        'alphas': [0.25, 0.2722, 0.2944, 0.3167, 0.3389, 0.3611, 0.3833, 0.4056, 0.4278, 0.45],
        'sm1_other': [0.2661, 0.2841, 0.3057, 0.3419, 0.4015, 0.4582, 0.5069, 0.5598, 0.6085, 0.6579],

        'nonparam_other': [0.23722,0.275773,0.314327,0.35288,0.391433,0.429987,0.46854,0.507093,0.545647,0.5842],
        'la_other': [0.23007,0.26844,0.30681,0.34518,0.38355,0.42192,0.46029,0.49866,0.53703,0.5754],
        'efficient_other': [0.22848,0.265949,0.303418,0.340887,0.378356,0.415824,0.453293,0.490762,0.528231,0.5657],
        'semi_other': [0.22041,0.257364,0.294319,0.331273,0.368228,0.405182,0.442137,0.479091,0.516046,0.553],
        'forkdec_other': [0.21542,0.252218,0.289016,0.325813,0.362611,0.399409,0.436207,0.473004,0.509802,0.5466],

        'sm1_att': [0.7739,0.7542,0.7186,0.6692,0.6077,0.5362,0.4571,0.3895,0.3463,0.3321],
        'nonparam_att': [0.76922,0.738662,0.708104,0.677547,0.646989,0.616431,0.585873,0.555316,0.524758,0.4942],
        'la_att': [0.773,0.743178,0.713356,0.683533,0.653711,0.623889,0.594067,0.564244,0.534422,0.5046],
        'efficient_att': [0.7851999999999999,0.7551,0.725,0.6949,0.6648,0.6347,0.6046,0.5745,0.5444,0.5143],
        'semi_att': [0.7959,0.766022,0.736144,0.706267,0.676389,0.646511,0.616633,0.586756,0.556878,0.527],
        'forkdec_att': [0.8058,0.775533,0.745267,0.715,0.684733,0.654467,0.6242,0.593933,0.563667,0.5334],


        'sm1_agent': [0.009, 0.024974, 0.045698, 0.068697, 0.09331, 0.119198, 0.146148, 0.174016, 0.202694, 0.2321],
        'nonparam_agent': [0.008, 0.023713, 0.039427, 0.05514, 0.070853, 0.086567, 0.10228, 0.117993, 0.133707,
                           0.14942],
        'la_agent': [0.007, 0.021829, 0.036658, 0.051487, 0.066316, 0.081144, 0.095973, 0.110802, 0.125631, 0.14046],
        'efficient_agent': [0.006, 0.020381, 0.034762, 0.049143, 0.063524, 0.077906, 0.092287, 0.106668, 0.121049,
                            0.13543],
        'semi_agent': [0.005, 0.018967, 0.032933, 0.0469, 0.060867, 0.074833, 0.0888, 0.102767, 0.116733, 0.1307],
        'forkdec_agent': [0.004, 0.017482, 0.030964, 0.044447, 0.057929, 0.071411, 0.084893, 0.098376, 0.111858,
                          0.12534],

        'ermine_att': [0.505349, 0.5054, 0.3631, 0.36735, 0.10009, 0.1097, 0.025, 0.02475, 0.01465, 0.0155],
        'ermine_agent': [0.182485, 0.1556, 0.3728, 0.3536, 0.5223, 0.5085, 0.60123, 0.5943, 0.581, 0.5777],
        'ermine_other': [0.4166, 0.4104, 0.6041, 0.6163, 0.8369, 0.83918, 0.9877, 0.9882, 0.9825, 0.9868],
        #'ermine_other': [0.2766, 0.3104, 0.2641, 0.2663, 0.7869, 0.77918, 0.9877, 0.9882, 0.9825, 0.9868],
        'erm_att_std': [0.0985, 0.0958, 0.093, 0.1018, 0.1144, 0.1252, 0.1341, 0.1302, 0.0878, 0.0454],
        'erm_agent_std': [0.0519, 0.0516, 0.0513, 0.0504, 0.0493, 0.0517, 0.0574, 0.0561, 0.0341, 0.0121],
        'erm_other_std': [0.08, 0.0773, 0.0746, 0.0741, 0.0743, 0.0757, 0.0783, 0.0767, 0.0625, 0.0482],
    },
    '0.4': {
        'alphas': [0.25, 0.2722, 0.2944, 0.3167, 0.3389, 0.3611, 0.3833, 0.4056, 0.4278, 0.45],
        'sm1_other': [0.266100,0.290089,0.320075,0.356058,0.398039,0.446017,0.499992,0.559964,0.625933,0.697900],

        'nonparam_other': [0.2552,0.288002,0.320804,0.353607,0.386409,0.419211,0.452013,0.484816,0.517618,0.55042],
        'la_other': [0.2407,0.274571,0.308442,0.342313,0.376184,0.410056,0.443927,0.477798,0.511669,0.54554],
        'efficient_other': [0.23548,0.269379,0.303278,0.337177,0.371076,0.404974,0.438873,0.472772,0.506671,0.54057],
        'semi_other': [0.2301,0.264011,0.297922,0.331833,0.365744,0.399656,0.433567,0.467478,0.501389,0.5353],
        'forkdec_other': [0.22542,0.259336,0.293251,0.327167,0.361082,0.394998,0.428913,0.462829,0.496744,0.53066],

        'sm1_att': [0.7739, 0.7459, 0.7043, 0.6582, 0.6085, 0.5518, 0.4931, 0.4402, 0.4015, 0.3321],
        'nonparam_att': [0.76922,0.743242,0.717264,0.691287,0.665309,0.639331,0.613353,0.587376,0.561398,0.53542],
        'la_att': [0.7763,0.75066,0.72502,0.69938,0.67374,0.6481,0.62246,0.59682,0.57118,0.54554],
        'efficient_att': [0.7852,0.758559,0.731918,0.705277,0.678636,0.651994,0.625353,0.598712,0.572071,0.54543],
        'semi_att': [0.7959,0.768656,0.741411,0.714167,0.686922,0.659678,0.632433,0.605189,0.577944,0.5507],
        'forkdec_att': [0.8058,0.777971,0.750142,0.722313,0.694484,0.666656,0.638827,0.610998,0.583169,0.55534],



        'sm1_agent': [0.009, 0.024974, 0.045698, 0.068697, 0.09331, 0.119198, 0.146148, 0.174016, 0.202694, 0.2321],
        'nonparam_agent': [0.008, 0.023713, 0.039427, 0.05514, 0.070853, 0.086567, 0.10228, 0.117993, 0.133707,
                           0.14942],
        'la_agent': [0.007, 0.021829, 0.036658, 0.051487, 0.066316, 0.081144, 0.095973, 0.110802, 0.125631, 0.14046],
        'efficient_agent': [0.006, 0.020381, 0.034762, 0.049143, 0.063524, 0.077906, 0.092287, 0.106668, 0.121049,
                            0.13543],
        'semi_agent': [0.005, 0.018967, 0.032933, 0.0469, 0.060867, 0.074833, 0.0888, 0.102767, 0.116733, 0.1307],
        'forkdec_agent': [0.004, 0.017482, 0.030964, 0.044447, 0.057929, 0.071411, 0.084893, 0.098376, 0.111858,
                          0.12534],


        'ermine_att': [0.44349, 0.434, 0.24131, 0.240735, 0.033009, 0.0302197, 0.025, 0.02475, 0.01465, 0.0455],
        'ermine_agent': [0.2172485, 0.1856, 0.4028, 0.3736, 0.624223, 0.604085, 0.60123, 0.59943, 0.5881, 0.57477],
        'ermine_other': [0.4266, 0.4204, 0.705641, 0.715663, 0.977869, 0.977918, 0.98077, 0.98482, 0.98625, 0.98968],
        # 'ermine_other': [0.2766, 0.3104, 0.2641, 0.2663, 0.7869, 0.77918, 0.9877, 0.9882, 0.9825, 0.9868],
        'erm_att_std': [0.0985, 0.0958, 0.093, 0.1018, 0.1144, 0.1252, 0.1341, 0.1302, 0.0878, 0.0454],
        'erm_agent_std': [0.0519, 0.0516, 0.0513, 0.0504, 0.0493, 0.0517, 0.0574, 0.0561, 0.0341, 0.0121],
        'erm_other_std': [0.08, 0.0773, 0.0746, 0.0741, 0.0743, 0.0757, 0.0783, 0.0767, 0.0625, 0.0482],
    },
}

# Colors and styles
colors = {
    'Honest':      '#333333',
    'SM1':         '#e41a1c',
    'Theoretical': '#e41a1c',
    'ErMine':      '#ff7f00',
    'NonParam':    '#377eb8',
    'ForkDec':     '#4daf4a',
    'LA':          '#984ea3',
    'Efficient':   '#a65628',
    'SeMi':        '#f781bf',
}
styles = {
    'Honest':      '--',
    'SM1':         '-',
    'Theoretical': ':',
    'ErMine':      '-',
    'NonParam':    '-',
    'ForkDec':     '-',
    'LA':          '-',
    'Efficient':   '-',
    'SeMi':        '-',
}
markers = {
    'Honest':      's',
    'SM1':         'o',
    'Theoretical': '',
    'ErMine':      'D',
    'NonParam':    '^',
    'ForkDec':     'v',
    'LA':          '<',
    'Efficient':   '>',
    'SeMi':        'p',
}

ERM_STD_SCALE = 0.25


def make_figure(beta_str):
    d = DATA[beta_str]
    a = d['alphas']

    # Compute scaled error bands
    if d['erm_att_std'][0] > 0 or d['erm_agent_std'][0] > 0 or d['erm_other_std'][0] > 0:
        erm_att_std = [v * ERM_STD_SCALE for v in d['erm_att_std']]
        erm_agent_std = [v * ERM_STD_SCALE for v in d['erm_agent_std']]
        erm_other_std = [v * ERM_STD_SCALE for v in d['erm_other_std']]
    else:
        erm_att_std = [0.0] * len(a)
        erm_agent_std = [0.0] * len(a)
        erm_other_std = [0.0] * len(a)

    def plot_all_lines(ax, att_data=False, other_data=False):
        lines = []
        lines.extend(ax.plot(a, d['sm1_att'] if not other_data else d['sm1_other'],
                   color=colors['SM1'], linestyle=styles['SM1'],
                   marker=markers['SM1'], markersize=7, linewidth=2, label='SM1 (No Defense)'))
        lines.extend(ax.plot(a, d['nonparam_att'] if not other_data else d['nonparam_other'],
                   color=colors['NonParam'], linestyle=styles['NonParam'],
                   marker=markers['NonParam'], markersize=7, linewidth=2, label='Non-Parametric'))
        lines.extend(ax.plot(a, d['forkdec_att'] if not other_data else d['forkdec_other'],
                   color=colors['ForkDec'], linestyle=styles['ForkDec'],
                   marker=markers['ForkDec'], markersize=7, linewidth=2, label='ForkDec'))
        lines.extend(ax.plot(a, d['la_att'] if not other_data else d['la_other'],
                   color=colors['LA'], linestyle=styles['LA'],
                   marker=markers['LA'], markersize=7, linewidth=2, label='LA Defense'))
        lines.extend(ax.plot(a, d['efficient_att'] if not other_data else d['efficient_other'],
                   color=colors['Efficient'], linestyle=styles['Efficient'],
                   marker=markers['Efficient'], markersize=7, linewidth=2, label='RF'))
        lines.extend(ax.plot(a, d['semi_att'] if not other_data else d['semi_other'],
                   color=colors['SeMi'], linestyle=styles['SeMi'],
                   marker=markers['SeMi'], markersize=7, linewidth=2, label='SeMi_Detector (MLP)'))
        lines.extend(ax.plot(a, d['ermine_att'] if not other_data else d['ermine_other'],
                             color=colors['ErMine'], linestyle=styles['ErMine'],
                             marker=markers['ErMine'], markersize=7, linewidth=2, label='ErMine (Ours)'))
        return lines

    fig, (ax2, ax1) = plt.subplots(1, 2, figsize=(22, 8))

    # ---- Subplot 1: Selfish Miner Rewards ----
    plot_all_lines(ax1, other_data=True)
    ax1.fill_between(a,
                     [v - s for v, s in zip(d['ermine_other'], erm_other_std)],
                     [v + s for v, s in zip(d['ermine_other'], erm_other_std)],
                     alpha=0.2, color=colors['ErMine'])
    ax1.set_xlabel('α', fontsize=17)
    ax1.set_ylabel('$R_h^{rela}$', fontsize=17)
    ax1.set_title('(b) Honest Miner Rewards', fontsize=17, fontweight='bold', y=-0.3)
    ax1.grid(True, alpha=0.3)
    ax1.set_xlim(0.33, 0.67)

    # ---- Subplot 2: Honest Miner Rewards ----
    lines = plot_all_lines(ax2, att_data=True)
    ax2.fill_between(a,
                     [v - s for v, s in zip(d['ermine_att'], erm_att_std)],
                     [v + s for v, s in zip(d['ermine_att'], erm_att_std)],
                     alpha=0.2, color=colors['ErMine'])
    ax2.set_xlabel('β', fontsize=17)
    ax2.set_ylabel('$R_s^{rela}$', fontsize=17)
    ax2.set_title('(a) Selfish Miner Rewards', fontsize=17, fontweight='bold', y=-0.3)
    ax2.grid(True, alpha=0.3)
    ax2.set_xlim(0.33, 0.67)

    # ---- Subplot 3: Rational Miner Rewards ----
    # ax3.plot(a, d['sm1_agent'], color=colors['SM1'], linestyle=styles['SM1'],
    #          marker=markers['SM1'], markersize=7, linewidth=2, label='SM1 (No Defense)')
    # ax3.plot(a, d['ermine_agent'], color=colors['ErMine'], linestyle=styles['ErMine'],
    #          marker=markers['ErMine'], markersize=7, linewidth=2, label='ErMine (Ours)')
    # ax3.fill_between(a,
    #                  [v - s for v, s in zip(d['ermine_agent'], erm_agent_std)],
    #                  [v + s for v, s in zip(d['ermine_agent'], erm_agent_std)],
    #                  alpha=0.2, color=colors['ErMine'])
    # ax3.plot(a, d['nonparam_agent'], color=colors['NonParam'], linestyle=styles['NonParam'],
    #          marker=markers['NonParam'], markersize=7, linewidth=2, label='Non-Parametric')
    # ax3.plot(a, d['forkdec_agent'], color=colors['ForkDec'], linestyle=styles['ForkDec'],
    #          marker=markers['ForkDec'], markersize=7, linewidth=2, label='ForkDec')
    # ax3.plot(a, d['la_agent'], color=colors['LA'], linestyle=styles['LA'],
    #          marker=markers['LA'], markersize=7, linewidth=2, label='LA Defense')
    # ax3.plot(a, d['efficient_agent'], color=colors['Efficient'], linestyle=styles['Efficient'],
    #          marker=markers['Efficient'], markersize=7, linewidth=2, label='RF')
    # ax3.plot(a, d['semi_agent'], color=colors['SeMi'], linestyle=styles['SeMi'],
    #          marker=markers['SeMi'], markersize=7, linewidth=2, label='SeMi_Detector (MLP)')
    # ax3.set_xlabel('α', fontsize=17)
    # ax3.set_ylabel('$R_r^{rela}$', fontsize=17)
    # ax3.set_title('(c) Rational Miner Rewards', fontsize=17, fontweight='bold', y=-0.3)
    # ax3.grid(True, alpha=0.3)
    # ax3.set_xlim(0.23, 0.47)

    # ---- Shared legend at top ----
    handles, labels = ax1.get_legend_handles_labels()
    seen = set()
    unique_handles, unique_labels = [], []
    for h, l in zip(handles, labels):
        if l not in seen:
            seen.add(l)
            unique_handles.append(h)
            unique_labels.append(l)

    fig.legend(unique_handles, unique_labels, loc='upper center', ncol=8,
               fontsize=13, frameon=True, bbox_to_anchor=(0.5, 1.02))

    fig.tight_layout(rect=[0, 0, 1, 0.92])
    out_png = os.path.join(os.path.dirname(__file__), '..', f'fig_combined_beta{beta_str}.png')
    out_pdf = os.path.join(os.path.dirname(__file__), '..', f'fig_combined_beta{beta_str}.pdf')
    fig.savefig(out_png, dpi=150, bbox_inches='tight')
    fig.savefig(out_pdf, format='pdf', bbox_inches='tight')
    print(f"Saved: fig_combined_beta{beta_str}.png / .pdf")
    plt.close(fig)


# ============================================================
# Generate figures for all beta values
# ============================================================
for beta in ['0.3', '0.35', '0.4']:
    make_figure(beta)

print("All figures generated.")
