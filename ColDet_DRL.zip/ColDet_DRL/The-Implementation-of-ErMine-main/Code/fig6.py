import matplotlib.pyplot as plt
import numpy as np

# 1. 先创建一个大画布
fig = plt.figure(figsize=(15, 5))

# 2. 用 add_subplot 添加子图，参数 (1, 3, 1) 表示 1行3列的第1个
ax1 = fig.add_subplot(1, 3, 1)
ax2 = fig.add_subplot(1, 3, 2)
ax3 = fig.add_subplot(1, 3, 3)

# 示例数据
x = np.linspace(0, 10, 100)
# 3. 在 ax1 上绘图，代码和方法一类似
ax1.plot(x, np.sin(x))
ax1.set_title('子图 1')

ax2.scatter(x, np.cos(x))
ax2.set_title('子图 2')

ax3.plot(x, np.tanh(x))
ax3.set_title('子图 3')

# 为整个画布添加总标题
fig.suptitle('并排图表的总标题', fontsize=16)

# 自动调整布局
plt.tight_layout()
plt.show()