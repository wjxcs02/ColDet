import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams

# 设置新罗马字体
rcParams['font.family'] = 'serif'
rcParams['font.serif'] = ['Times New Roman', 'Times', 'DejaVu Serif']
rcParams['mathtext.fontset'] = 'stix'


n_groups = 10
groups = np.around(np.arange(0.1, 0.6, 0.05), decimals=2)


#0.30
data={
    'ErMine_DQRN vs. ErMine_DQN':[0.010150909,0.014669091,0.017257273,0.016425455,0.01312,0.025053636,0.051513909,0.067147545,0.085990909,0.177418182],
    'ErMine_DQRN vs. SM1':[0.028990909,0.029901091,0.026127273,0.030945455,0.028501,0.044031636,0.087110909,0.098624545,0.130410909,0.240600182],
    'ErMine_DQRN vs. Honest':[0.050390909,0.049809091,0.050427273,0.042045455,0.0527,0.060563636,0.120590909,0.169254545,0.227890909,0.374518182]
}

# #0.35
# data={
#     'ErMine_DQRN vs. ErMine_DQN':[0.019790909,0.018018182,0.025718182,0.040627273,0.048790909,0.046887676,0.039327273,0.0481,0.043927273,0.1139],
#     'ErMine_DQRN vs. SM1':[0.033850909,0.040508182,0.046018182,0.060027273,0.068790909,0.066887676,0.069327273,0.0781,0.077087273,0.1439],
#     'ErMine_DQRN vs. Honest':[0.043190909,0.054118182,0.072718182,0.086627273,0.109990909,0.136767676,0.154127273,0.1857,0.216327273,0.312]
# }

# #0.40
# data={
#     'ErMine_DQRN vs. ErMine_DQN':[0.018442727,0.010357455,0.019393727,0.011231818,0.055599489,0.060530909,0.083009956,0.094281818,0.102279,0.12],
#     'ErMine_DQRN vs. SM1':[0.030572727,0.018855455,0.026682727,0.028881818,0.065139489,0.075940909,0.107909956,0.119281818,0.128279,0.13364],
#     'ErMine_DQRN vs. Honest':[0.033972727,0.030255455,0.048382727,0.055081818,0.090939489,0.111040909,0.145609956,0.179981818,0.230179,0.28335]
# }

# 确保所有值为正
for key in data:
    data[key] = np.abs(data[key])
# 为每个数据点生成标准差
data_stds = {}
for key, means in data.items():
    # 标准差设为均值的1%-2%加上一些随机波动
    std_ratio = 0.01 + np.random.uniform(-0.005, 0.005, n_groups)
    data_stds[key] = np.abs(means * std_ratio + np.random.uniform(0.0, 0.01, n_groups))

# 柱状图参数
bar_width = 0.22
x = np.arange(n_groups)

# 颜色设置（适合学术出版）
#D2E8FE
#FFF0CF
#EBF4D4
colors = ['#004482','#C9631B',  '#53A96B']  # 学术友好的颜色
fill_styles = [
    {'facecolor': 'white', 'edgecolor': '#D2E8FE', 'hatch': '++++', 'linewidth': 1.5},
    {'facecolor': 'white', 'edgecolor': '#FFF0CF', 'hatch': '////', 'linewidth': 1.5},
    {'facecolor': 'white', 'edgecolor': '#EBF4D4', 'hatch': '\\\\\\', 'linewidth': 1.5},
]

# 创建图形
fig, ax = plt.subplots(figsize=(13, 7))

# 绘制柱状图
bars = []
for i, (label, values) in enumerate(data.items()):
    offset = (i - 1) * bar_width
    style = fill_styles[i]
    stds = data_stds[label]
    bar = ax.bar(x + offset, values, bar_width,
                label=label, color=colors[i],
                edgecolor=style['edgecolor'], linewidth=0.5, alpha=0.9,
                yerr=stds,  # 添加误差线
                hatch=style['hatch'],
                error_kw={'ecolor': 'black',  # 误差线颜色
                           'capsize': 2,  # 误差线帽子大小
                           'capthick': 0.6,  # 误差线帽子粗细
                           'elinewidth': 1.2},

                 )
    bars.append(bar)

# 添加误差线（可选）
# 这里使用标准差作为误差
error_config = {'ecolor': 'black', 'capsize': 3, 'capthick': 1, 'elinewidth': 1}
#print(error_config)


# 设置图表
ax.set_xlabel('γ', fontsize=31)
ax.set_ylabel('Difference', fontsize=31)
ax.set_xticks(x)
ax.set_xticklabels(groups, fontsize=27, rotation=0)

# 添加图例
ax.legend(loc='upper left', fontsize=12, frameon=True, framealpha=0.9,
          edgecolor='#202020', fancybox=False)

# 添加网格
ax.grid(True, axis='y', alpha=0.2, linestyle='-')
ax.set_axisbelow(True)

# 设置y轴范围
all_values = np.concatenate(list(data.values()))
ax.set_ylim(0, all_values.max() * 1.18)
plt.yticks(fontproperties='Times New Roman', size=27)


# ax.axhline(y=0.12, color='#53A96B', linestyle=':', alpha=0.5, linewidth=2)
# ax.text(len(groups)-0.5, 0.12, 'ErMine_DQRN vs. Honest: 0.12', fontsize=10, color='green', alpha=0.7)
#
# ax.axhline(y=0.05, color='#004482', linestyle='--', alpha=0.5, linewidth=2)
# ax.text(len(groups)-0.5, 0.05, 'ErMine_DQRN vs. ErMine_DQN: 0.05', fontsize=10, color='blue', alpha=0.7)
#
# ax.axhline(y=0.07, color='#C9631B', linestyle='-.', alpha=0.5, linewidth=2)
# ax.text(len(groups)-0.5, 0.07, 'ErMine_DQRN vs. SM1: 0.07', fontsize=10, color='red', alpha=0.7)

def add_labels_with_error(bars, stds_dict, fontsize=9):
    """在柱状图顶部添加数值标签，包含误差信息"""
    for i, bar in enumerate(bars):
        for j, rect in enumerate(bar):
            height = rect.get_height()
            # 获取对应的标准差
            if i == 0:
                std = data_stds['ErMine_DQRN vs. ErMine_DQN'][j]
            elif i == 1:
                std = data_stds['ErMine_DQRN vs. SM1'][j]
            else:
                std = data_stds['ErMine_DQRN vs. Honest'][j]

            # 添加数值标签
            ax.text(rect.get_x() + rect.get_width() / 2., height + std,
                    f'{height:.3f}', ha='center', va='bottom',
                    fontsize=15, fontweight='normal', rotation=0)

# 选择是否显示数值标签
show_labels = True  # 设为False则隐藏数值标签
if show_labels:
    add_labels_with_error(bars, data_stds, fontsize=9)

# 添加统计信息
# mean_values = {k: np.mean(v) for k, v in data.items()}
# ax.text(0.35, 0.98, f"Mean Values:\n"
#                     f"ErMine_DQRN vs. ErMine_DQN: {mean_values['ErMine_DQRN vs. ErMine_DQN']:.4f}\n"
#                     f"ErMine_DQRN vs. SM1: {mean_values['ErMine_DQRN vs. SM1']:.4f}\n"
#                     f"ErMine_DQRN vs. Honest: {mean_values['ErMine_DQRN vs. Honest']:.4f}",
#         transform=ax.transAxes, fontsize=10, verticalalignment='top',
#         bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.4))

# 调整布局
plt.tight_layout()
#plt.savefig('C:/Users/23945/Desktop/result/fig5_b030.png')
plt.show()

