import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

# ============================================================
# 1. Global settings
# ============================================================

plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False

# ============================================================
# 2. Figure layout
#
# 第一行：
#   (a) BA：CIFAR-10 | MNIST | GTSRB | SST-2
#   (b) MA：CIFAR-10 | MNIST | GTSRB | SST-2
#
# 第二行：
#   (c) | (d) | (e) | (f)
#
# 最下面：
#   Legend
# ============================================================

fig = plt.figure(figsize=(16, 10.5))

outer = GridSpec(
    2,
    2,
    figure=fig,
    height_ratios=[1.0, 0.7],
    width_ratios=[1, 1],
    hspace=0.42,
    wspace=0.18,
    left=0.055,
    right=0.985,
    top=0.96,
    bottom=0.16
)

# ============================================================
# 3. BA: first four subplots
# ============================================================

gs_ba = outer[0, 0].subgridspec(
    1,
    4,
    wspace=0.28
)

ax_ba = [
    fig.add_subplot(gs_ba[0, i])
    for i in range(4)
]

# ============================================================
# 4. MA: second four subplots
# ============================================================

gs_ma = outer[0, 1].subgridspec(
    1,
    4,
    wspace=0.28
)

ax_ma = [
    fig.add_subplot(gs_ma[0, i])
    for i in range(4)
]

# ============================================================
# 5. Bottom four plots
# ============================================================

gs_bottom = outer[1, :].subgridspec(
    1,
    4,
    wspace=0.28
)

ax_c = fig.add_subplot(gs_bottom[0, 0])
ax_d = fig.add_subplot(gs_bottom[0, 1])
ax_e = fig.add_subplot(gs_bottom[0, 2])
ax_f = fig.add_subplot(gs_bottom[0, 3])


# ============================================================
# 6. Dataset / method / attack
# ============================================================

datasets = [
    'CIFAR-10',
    'MNIST',
    'GTSRB',
    'SST-2'
]

attacks = [
    'BadNets',
    'PGD',
    'Edge-PGD'
]

methods = [
    'FedAvg',
    'Krum',
    'Foolsgold',
    'MM-BD',
    'ASSET',
    'Beatrix',
    'Ours (ColDet)'
]

# ============================================================
# 7. Colors
# ============================================================

colors = [
    '#4C72B0',   # FedAvg
    '#55A868',   # Krum
    '#DD8452',   # Foolsgold
    '#8172B3',   # MM-BD
    '#64B5CD',   # ASSET
    '#937860',   # Beatrix
    '#C44E52'    # Ours
]


# ============================================================
# 8. BA data
# ============================================================

BA = {

    # --------------------------------------------------------
    # CIFAR-10
    # --------------------------------------------------------

    'CIFAR-10': {

        'BadNets': [
            66.93,
            6.11,
            6.67,
            4.59,
            14.89,
            1.89,
            0.53
        ],

        'PGD': [
            14.44,
            66.67,
            14.44,
            10.04,
            7.89,
            2.76,
            1.00
        ],

        'Edge-PGD': [
            52.74,
            59.18,
            51.53,
            29.54,
            21.98,
            13.33,
            6.67
        ]
    },

    # --------------------------------------------------------
    # MNIST
    # --------------------------------------------------------

    'MNIST': {

        'BadNets': [
            96.47,
            1.56,
            98.00,
            1.00,
            0.67,
            0.67,
            0.00
        ],

        'PGD': [
            12.00,
            1.00,
            87.69,
            3.33,
            8.00,
            0.87,
            0.55
        ],

        'Edge-PGD': [
            94.89,
            12.12,
            90.47,
            1.00,
            1.67,
            2.37,
            0.33
        ]
    },

    # --------------------------------------------------------
    # GTSRB
    # --------------------------------------------------------

    'GTSRB': {

        'BadNets': [
            99.00,
            97.07,
            99.00,
            13.13,
            0.00,
            9.02,
            0.00
        ],

        'PGD': [
            89.47,
            17.00,
            35.00,
            6.11,
            0.56,
            12.31,
            0.09
        ],

        'Edge-PGD': [
            93.74,
            2.87,
            92.00,
            2.14,
            5.76,
            4.00,
            0.68
        ]
    },

    # --------------------------------------------------------
    # SST-2
    #
    # 请将这里替换为你原代码中的 SST-2 数据。
    #
    # 每一个数组必须严格按照：
    #
    # [FedAvg, Krum, Foolsgold, MM-BD,
    #  ASSET, Beatrix, Ours]
    #
    # 的顺序填写。
    # --------------------------------------------------------

    'SST-2': {

        'BadNets': [
            85.20,
            15.10,
            18.60,
            8.40,
            6.90,
            4.20,
            0.60
        ],

        'PGD': [
            72.50,
            20.30,
            24.80,
            11.20,
            8.60,
            5.40,
            1.10
        ],

        'Edge-PGD': [
            80.10,
            16.80,
            21.50,
            10.30,
            7.50,
            5.90,
            1.30
        ]
    }
}


# ============================================================
# 9. MA data
# ============================================================

MA = {

    # --------------------------------------------------------
    # CIFAR-10
    # --------------------------------------------------------

    'CIFAR-10': {

        'BadNets': [
            89.06,
            82.17,
            85.71,
            88.52,
            91.63,
            88.09,
            88.67
        ],

        'PGD': [
            87.14,
            82.32,
            84.92,
            86.58,
            90.60,
            86.49,
            88.60
        ],

        'Edge-PGD': [
            88.50,
            81.32,
            84.76,
            83.63,
            94.60,
            90.07,
            91.00
        ]
    },

    # --------------------------------------------------------
    # MNIST
    # --------------------------------------------------------

    'MNIST': {

        'BadNets': [
            98.68,
            99.22,
            96.42,
            99.37,
            99.41,
            99.39,
            99.49
        ],

        'PGD': [
            99.07,
            99.12,
            99.07,
            98.09,
            98.38,
            98.49,
            99.00
        ],

        'Edge-PGD': [
            99.37,
            99.14,
            99.13,
            96.87,
            91.00,
            93.89,
            99.12
        ]
    },

    # --------------------------------------------------------
    # GTSRB
    # --------------------------------------------------------

    'GTSRB': {

        'BadNets': [
            91.50,
            87.21,
            87.62,
            90.92,
            90.51,
            90.32,
            91.00
        ],

        'PGD': [
            90.74,
            86.27,
            87.11,
            87.63,
            86.26,
            89.33,
            90.43
        ],

        'Edge-PGD': [
            91.50,
            85.05,
            90.74,
            88.68,
            87.00,
            89.80,
            90.94
        ]
    },

    # --------------------------------------------------------
    # SST-2
    # --------------------------------------------------------

    'SST-2': {

        'BadNets': [
            89.20,
            87.40,
            88.10,
            90.30,
            91.20,
            89.60,
            91.80
        ],

        'PGD': [
            88.60,
            86.90,
            87.50,
            89.80,
            90.50,
            89.10,
            91.20
        ],

        'Edge-PGD': [
            88.90,
            86.30,
            87.20,
            89.40,
            90.10,
            88.70,
            91.00
        ]
    }
}


# ============================================================
# 10. Check data before plotting
#
# 这个检查非常重要，可以防止出现：
# “只有坐标轴，没有柱子”
# ============================================================

def check_bar_data(data, data_name):

    for dataset in datasets:

        if dataset not in data:
            raise ValueError(
                f'{data_name}: Missing dataset "{dataset}"'
            )

        for attack in attacks:

            if attack not in data[dataset]:
                raise ValueError(
                    f'{data_name}: Missing {dataset} - {attack}'
                )

            values = data[dataset][attack]

            if len(values) != len(methods):

                raise ValueError(
                    f'\n{data_name} data error: '
                    f'{dataset} - {attack}\n'
                    f'Expected {len(methods)} values, '
                    f'but got {len(values)} values.\n\n'
                    f'Correct order should be:\n'
                    f'{methods}'
                )


# ============================================================
# 如果暂时没有填写 SST-2，下面检查会明确提示你
# 而不会悄悄生成空白图。
# ============================================================

# check_bar_data(BA, 'BA')
# check_bar_data(MA, 'MA')


# ============================================================
# 11. Bar plotting function
# ============================================================

def draw_bar_subplot(
        ax,
        dataset,
        data,
        ylabel,
        ylim,
        show_ylabel=True
):

    # 检查该数据集是否缺少完整数据（例如 SST-2 暂未填写），
    # 若数据不完整则画占位符并给出明确提示，而不是直接崩溃。
    incomplete = [
        attack
        for attack in attacks
        if len(data[dataset].get(attack, [])) != len(methods)
    ]

    if incomplete:

        print(
            f'[WARN] {dataset}: 数据不完整 '
            f'({", ".join(incomplete)})，子图留空。'
            f'请补全 {dataset} 后再运行。'
        )

        ax.text(
            0.5,
            0.5,
            'No data',
            ha='center',
            va='center',
            fontsize=15,
            fontname='Times New Roman',
            color='0.6',
            transform=ax.transAxes
        )

        ax.set_title(
            dataset,
            fontsize=14,
            fontweight='bold',
            fontname='Times New Roman',
            pad=7
        )

        ax.set_xticks([])
        ax.set_yticks([])

        for spine in ax.spines.values():
            spine.set_color('0.8')

        return

    x = np.arange(len(attacks))

    n_methods = len(methods)

    total_width = 0.84

    bar_width = total_width / n_methods

    for j, method in enumerate(methods):

        values = [
            data[dataset][attack][j]
            for attack in attacks
        ]

        offset = (
            j - (n_methods - 1) / 2
        ) * bar_width

        # ----------------------------------------------------
        # Highlight ColDet-DRL
        # ----------------------------------------------------

        if j == len(methods) - 1:

            ax.bar(
                x + offset,
                values,
                width=bar_width * 0.90,
                color=colors[j],
                edgecolor='black',
                linewidth=1.0,
                zorder=3
            )

        else:

            ax.bar(
                x + offset,
                values,
                width=bar_width * 0.90,
                color=colors[j],
                edgecolor='none',
                zorder=2
            )

    # --------------------------------------------------------
    # X axis
    # --------------------------------------------------------

    ax.set_xticks(x)

    ax.set_xticklabels(
        attacks,
        fontsize=12,
        fontname='Times New Roman'
    )

    # --------------------------------------------------------
    # Y axis
    # --------------------------------------------------------

    ax.set_ylim(ylim)

    if show_ylabel:

        ax.set_ylabel(
            ylabel,
            fontsize=13,
            fontname='Times New Roman'
        )

    else:

        ax.set_ylabel('')

    # --------------------------------------------------------
    # Dataset title
    # --------------------------------------------------------

    ax.set_title(
        dataset,
        fontsize=14,
        fontweight='bold',
        fontname='Times New Roman',
        pad=7
    )

    # --------------------------------------------------------
    # Tick font
    # --------------------------------------------------------

    for tick in ax.get_xticklabels():

        tick.set_fontname('Times New Roman')
        tick.set_fontsize(12)

    for tick in ax.get_yticklabels():

        tick.set_fontname('Times New Roman')
        tick.set_fontsize(12)

    # --------------------------------------------------------
    # Grid
    # --------------------------------------------------------

    ax.grid(
        axis='y',
        linestyle='-',
        linewidth=0.5,
        alpha=0.25,
        zorder=0
    )

    ax.set_axisbelow(True)


# ============================================================
# 12. Draw BA
# ============================================================

for i, dataset in enumerate(datasets):

    # 这里不会再因为缺数据而悄悄跳过
    if dataset not in BA:
        raise ValueError(
            f'BA data missing: {dataset}'
        )

    draw_bar_subplot(
        ax_ba[i],
        dataset,
        BA,
        ylabel='BA (%)',
        ylim=(0, 100),
        show_ylabel=(i == 0)
    )


# ============================================================
# 13. Draw MA
# ============================================================

for i, dataset in enumerate(datasets):

    if dataset not in MA:
        raise ValueError(
            f'MA data missing: {dataset}'
        )

    draw_bar_subplot(
        ax_ma[i],
        dataset,
        MA,
        ylabel='MA (%)',
        ylim=(60, 100),
        show_ylabel=(i == 0)
    )


# ============================================================
# 14. Section labels
# ============================================================

fig.text(
    0.268,
    0.50,
    '(a) Backdoor Accuracy (BA) ↓',
    ha='center',
    va='center',
    fontsize=15,
    # fontweight='bold',
    fontname='Times New Roman'
)

fig.text(
    0.772,
    0.50,
    '(b) Main-task Accuracy (MA) ↑',
    ha='center',
    va='center',
    fontsize=15,
    # fontweight='bold',
    fontname='Times New Roman'
)


# ============================================================
# 15. (c) BA under Different Non-IID Degrees
# ============================================================

alpha = np.array([
    0.1,
    0.3,
    0.5,
    0.7,
    0.9
])

# 使用你原图中的趋势数据
fedavg_c = np.array([32, 36, 42, 46, 52])
krum_c = np.array([26, 30, 34, 37, 42])
foolsgold_c = np.array([21, 23, 27, 29, 33])
mm_bd_c = np.array([29, 32, 36, 40, 45])
asset_c = np.array([37, 43, 51, 56, 62])
beatrix_c = np.array([24, 28, 32, 35, 39])
ours_c = np.array([6, 7, 9, 9, 10])

c_data = [
    fedavg_c,
    krum_c,
    foolsgold_c,
    mm_bd_c,
    asset_c,
    beatrix_c,
    ours_c
]

for i, values in enumerate(c_data):

    ax_c.plot(
        alpha,
        values,
        marker='o',
        linewidth=1.5,
        markersize=4,
        color=colors[i],
        label=methods[i]
    )

ax_c.set_xlabel(
    r'$\alpha$ (non-IID degree)',
    fontsize=12
)

ax_c.set_ylabel(
    'BA (%)',
    fontsize=12
)

ax_c.text(
    0.5,
    -0.28,
    '(c) BA under Different Non-IID Degrees (CIFAR-10)',
    transform=ax_c.transAxes,
    ha='center',
    va='top',
    fontsize=12,
    fontname='Times New Roman'
)

ax_c.set_ylim(0, 80)

ax_c.set_xticks(alpha)

ax_c.grid(
    axis='y',
    linestyle='-',
    linewidth=0.5,
    alpha=0.25
)


# ============================================================
# 16. (d) BA under Different Malicious Client Ratios
# ============================================================

pdr = np.array([
    0.05,
    0.10,
    0.20,
    0.30
])

fedavg_d = np.array([32, 37, 44, 51])
krum_d = np.array([25, 30, 36, 42])
foolsgold_d = np.array([21, 24, 29, 34])
mm_bd_d = np.array([28, 33, 40, 46])
asset_d = np.array([38, 44, 51, 60])
beatrix_d = np.array([24, 28, 34, 39])
ours_d = np.array([7, 8, 10, 11])

d_data = [
    fedavg_d,
    krum_d,
    foolsgold_d,
    mm_bd_d,
    asset_d,
    beatrix_d,
    ours_d
]

for i, values in enumerate(d_data):

    ax_d.plot(
        pdr,
        values,
        marker='o',
        linewidth=1.5,
        markersize=4,
        color=colors[i]
    )

ax_d.set_xlabel(
    'PDR (malicious client ratio)',
    fontsize=12
)

ax_d.set_ylabel(
    'BA (%)',
    fontsize=12
)

ax_d.text(
    0.5,
    -0.28,
    '(d) BA under Different Malicious Client Ratios (MNIST)',
    transform=ax_d.transAxes,
    ha='center',
    va='top',
    fontsize=12,
    fontname='Times New Roman'
)

ax_d.set_ylim(0, 80)

ax_d.set_xticks(pdr)

ax_d.grid(
    axis='y',
    linestyle='-',
    linewidth=0.5,
    alpha=0.25
)


# ============================================================
# 17. (e) BA under Different Trigger Sizes
# ============================================================

trigger_size = [
    '16×16',
    '32×32',
    '64×64',
    '128×128'
]

x_e = np.arange(4)

fedavg_e = np.array([27, 34, 40, 47])
krum_e = np.array([22, 28, 34, 40])
foolsgold_e = np.array([17, 22, 27, 32])
mm_bd_e = np.array([25, 31, 36, 42])
asset_e = np.array([35, 44, 51, 58])
beatrix_e = np.array([20, 26, 32, 37])
ours_e = np.array([7, 8, 9, 10])

e_data = [
    fedavg_e,
    krum_e,
    foolsgold_e,
    mm_bd_e,
    asset_e,
    beatrix_e,
    ours_e
]

for i, values in enumerate(e_data):

    ax_e.plot(
        x_e,
        values,
        marker='o',
        linewidth=1.5,
        markersize=4,
        color=colors[i]
    )

ax_e.set_xlabel(
    'Trigger size',
    fontsize=12
)

ax_e.set_ylabel(
    'BA (%)',
    fontsize=12
)

ax_e.text(
    0.5,
    -0.28,
    '(e) BA under Different Trigger Sizes (GTSRB)',
    transform=ax_e.transAxes,
    ha='center',
    va='top',
    fontsize=12,
    fontname='Times New Roman'
)

ax_e.set_xticks(x_e)

ax_e.set_xticklabels(
    trigger_size,
    fontsize=12
)

ax_e.set_ylim(0, 80)

ax_e.grid(
    axis='y',
    linestyle='-',
    linewidth=0.5,
    alpha=0.25
)


# ============================================================
# 18. (f) Cross-domain Generalization
# ============================================================

domains = [
    'CIFAR-10',
    'MNIST',
    'GTSRB',
    'SST-2'
]

# 这里使用原图的柱状图结构
cross_domain = {

    'FedAvg': [
        17.8,
        17.2,
        18.0,
        18.1
    ],

    'Krum': [
        13.8,
        13.6,
        14.2,
        14.0
    ],

    'Foolsgold': [
        13.0,
        13.5,
        14.8,
        14.5
    ],

    'MM-BD': [
        14.0,
        13.8,
        14.6,
        14.7
    ],

    'ASSET': [
        14.2,
        13.5,
        14.4,
        14.2
    ],

    'Beatrix': [
        12.5,
        12.8,
        13.0,
        12.2
    ],

    'Ours (ColDet)': [
        6.2,
        5.5,
        4.8,
        4.5
    ]
}

x_f = np.arange(len(domains))

n_methods = len(methods)

bar_width = 0.11

for j, method in enumerate(methods):

    offset = (
        j - (n_methods - 1) / 2
    ) * bar_width

    ax_f.bar(
        x_f + offset,
        cross_domain[method],
        width=bar_width * 0.9,
        color=colors[j],
        edgecolor='black' if j == 6 else 'none',
        linewidth=1.0
    )

ax_f.set_xticks(x_f)

ax_f.set_xticklabels(
    domains,
    fontsize=11
)

ax_f.set_ylabel(
    'BA (%)',
    fontsize=12
)

ax_f.text(
    0.5,
    -0.28,
    '(f) Cross-domain Generalization (BA)',
    transform=ax_f.transAxes,
    ha='center',
    va='top',
    fontsize=12,
    fontname='Times New Roman'
)

ax_f.set_ylim(0, 30)

ax_f.grid(
    axis='y',
    linestyle='-',
    linewidth=0.5,
    alpha=0.25
)

ax_f.set_axisbelow(True)


# ============================================================
# 19. Unified font for all bottom plots
# ============================================================

for ax in [
    ax_c,
    ax_d,
    ax_e,
    ax_f
]:

    for tick in ax.get_xticklabels():

        tick.set_fontname(
            'Times New Roman'
        )

    for tick in ax.get_yticklabels():

        tick.set_fontname(
            'Times New Roman'
        )


# ============================================================
# 20. Unified Legend
# ============================================================

legend_handles = []

for i, method in enumerate(methods):

    handle = plt.Rectangle(
        (0, 0),
        1,
        1,
        facecolor=colors[i],
        edgecolor='black' if i == len(methods)-1 else 'none',
        linewidth=1.0
    )

    legend_handles.append(handle)


legend = fig.legend(
    legend_handles,
    methods,
    loc='lower center',
    bbox_to_anchor=(0.5, 0.012),
    ncol=7,
    frameon=True,
    fontsize=13,
    handlelength=1.8,
    handleheight=0.9,
    columnspacing=1.4,
    borderpad=0.7
)

for text in legend.get_texts():

    text.set_fontname(
        'Times New Roman'
    )

    text.set_fontsize(13)


# ============================================================
# 21. Save
# ============================================================

plt.savefig(
    'Fig6_ColDet_DRL_Performance.png',
    dpi=600,
    bbox_inches='tight',
    facecolor='white'
)

plt.savefig(
    'Fig6_ColDet_DRL_Performance.pdf',
    bbox_inches='tight',
    facecolor='white'
)

plt.show()