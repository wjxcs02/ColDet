import matplotlib.pyplot as plt
import matplotlib
import os

matplotlib.rcParams['font.family'] = 'serif'
matplotlib.rcParams['font.size'] = 17
matplotlib.rcParams['font.serif'] = ['Times New Roman']

# ============================================================
# Hardcoded data for all three beta values
# ============================================================
DATA = {
    '0.3': {
        'alphas': [0.25, 0.2722, 0.2944, 0.3167, 0.3389, 0.3611, 0.3833, 0.4056, 0.4278, 0.45],
        'sm1_att': [0.2439, 0.2759, 0.3043, 0.3382, 0.3685, 0.4018, 0.4331, 0.4702, 0.5015, 0.5321],
        'sm1_other': [0.7561, 0.7241, 0.6957, 0.6619, 0.6315, 0.5982, 0.5669, 0.5298, 0.4985, 0.4679],
        'nonparam_att': [0.2422, 0.2726, 0.3048, 0.3348, 0.3666, 0.401, 0.4318, 0.4672, 0.5031, 0.5342],
        'nonparam_other': [0.7578, 0.7274, 0.6952, 0.6652, 0.6334, 0.599, 0.5682, 0.5328, 0.4969, 0.4658],
        'forkdec_att': [0.2058, 0.2361, 0.2682, 0.2997, 0.3314, 0.3676, 0.4004, 0.434, 0.4689, 0.5034],
        'forkdec_other': [0.7942, 0.7639, 0.7318, 0.7003, 0.6686, 0.6324, 0.5996, 0.566, 0.5311, 0.4966],
        'la_att': [0.233, 0.266, 0.294, 0.325, 0.3596, 0.3907, 0.4262, 0.4554, 0.4927, 0.5246],
        'la_other': [0.767, 0.734, 0.706, 0.675, 0.6404, 0.6093, 0.5738, 0.5446, 0.5073, 0.4754],
        'efficient_att': [0.2152, 0.2452, 0.2753, 0.3074, 0.3407, 0.3809, 0.4104, 0.4427, 0.4789, 0.5143],
        'efficient_other': [0.7848, 0.7548, 0.7247, 0.6926, 0.6593, 0.6191, 0.5896, 0.5573, 0.5211, 0.4857],
        'semi_att': [0.2259, 0.2597, 0.2859, 0.3178, 0.3504, 0.3836, 0.4165, 0.4515, 0.4832, 0.517],
        'semi_other': [0.7741, 0.7403, 0.7141, 0.6822, 0.6496, 0.6164, 0.5835, 0.5485, 0.5168, 0.483],
        'ermine_att': [0.55349, 0.554, 0.4131, 0.40735, 0.23009, 0.2197, 0.025, 0.02475, 0.01465, 0.0455],
        'ermine_agent': [0.172485, 0.1456, 0.2428, 0.2436, 0.4223, 0.4085, 0.60123, 0.5943, 0.581, 0.5777],
        'ermine_other': [0.3766, 0.3804, 0.5641, 0.5663, 0.7869, 0.77918, 0.9877, 0.9882, 0.9825, 0.9868],
        #'ermine_other': [0.2766, 0.3104, 0.2641, 0.2663, 0.7869, 0.77918, 0.9877, 0.9882, 0.9825, 0.9868],
        'erm_att_std': [0.0985, 0.0958, 0.093, 0.1018, 0.1144, 0.1252, 0.1341, 0.1302, 0.0878, 0.0454],
        'erm_agent_std': [0.0519, 0.0516, 0.0513, 0.0504, 0.0493, 0.0517, 0.0574, 0.0561, 0.0341, 0.0121],
        'erm_other_std': [0.08, 0.0773, 0.0746, 0.0741, 0.0743, 0.0757, 0.0783, 0.0767, 0.0625, 0.0482],
    },
    '0.35': {
        'alphas': [0.25, 0.2722, 0.2944, 0.3167, 0.3389, 0.3611, 0.3833, 0.4056, 0.4278, 0.45],
        'sm1_att': [0.2458, 0.2719, 0.3054, 0.3343, 0.3713, 0.3981, 0.4313, 0.4673, 0.4996, 0.5332],
        'sm1_other': [0.7542, 0.7281, 0.6946, 0.6657, 0.6287, 0.6019, 0.5687, 0.5327, 0.5004, 0.4668],
        'nonparam_att': [0.2439, 0.2713, 0.3047, 0.3357, 0.3642, 0.4017, 0.4342, 0.4637, 0.5021, 0.5348],
        'nonparam_other': [0.7561, 0.7287, 0.6953, 0.6643, 0.6358, 0.5983, 0.5658, 0.5363, 0.4979, 0.4652],
        'forkdec_att': [0.2049, 0.2378, 0.2647, 0.2976, 0.3322, 0.3654, 0.4011, 0.4332, 0.4709, 0.5042],
        'forkdec_other': [0.7951, 0.7622, 0.7353, 0.7024, 0.6678, 0.6346, 0.5989, 0.5668, 0.5291, 0.4958],
        'la_att': [0.2357, 0.2638, 0.2952, 0.3255, 0.3592, 0.3913, 0.4262, 0.4602, 0.4888, 0.527],
        'la_other': [0.7643, 0.7362, 0.7048, 0.6745, 0.6408, 0.6087, 0.5738, 0.5398, 0.5112, 0.473],
        'efficient_att': [0.2134, 0.246, 0.2763, 0.3104, 0.3455, 0.3788, 0.4112, 0.4439, 0.4777, 0.5159],
        'efficient_other': [0.7866, 0.754, 0.7237, 0.6896, 0.6545, 0.6212, 0.5888, 0.5561, 0.5223, 0.4841],
        'semi_att': [0.2279, 0.254, 0.2879, 0.3176, 0.3484, 0.3864, 0.4183, 0.4488, 0.4856, 0.518],
        'semi_other': [0.7721, 0.746, 0.7121, 0.6824, 0.6516, 0.6136, 0.5817, 0.5512, 0.5144, 0.482],
        'ermine_att': [0.2854, 0.3058, 0.3261, 0.2436, 0.1267, 0.1104, 0.1946, 0.2425, 0.1819, 0.1212],
        'ermine_agent': [0.1744, 0.1993, 0.2242, 0.2936, 0.3779, 0.3927, 0.3381, 0.2983, 0.3031, 0.3078],
        'ermine_other': [0.5402, 0.4949, 0.4497, 0.4628, 0.4954, 0.4969, 0.4673, 0.4591, 0.5151, 0.571],
        'erm_att_std': [0.0978, 0.1135, 0.1293, 0.1051, 0.0675, 0.065, 0.0974, 0.1185, 0.1057, 0.0929],
        'erm_agent_std': [0.053, 0.0596, 0.0662, 0.0602, 0.05, 0.0511, 0.0634, 0.0718, 0.0683, 0.0649],
        'erm_other_std': [0.0687, 0.0784, 0.0882, 0.0649, 0.0305, 0.0258, 0.0506, 0.0711, 0.0786, 0.086],
    },
    '0.4': {
        'alphas': [0.25, 0.2722, 0.2944, 0.3167, 0.3389, 0.3611, 0.3833, 0.4056, 0.4278, 0.45],
        'sm1_att': [0.247, 0.2731, 0.3051, 0.3331, 0.3669, 0.4019, 0.4352, 0.4665, 0.5011, 0.535],
        'sm1_other': [0.753, 0.7269, 0.6949, 0.6669, 0.6331, 0.5981, 0.5648, 0.5335, 0.4989, 0.465],
        'nonparam_att': [0.2415, 0.276, 0.3045, 0.3343, 0.3653, 0.4036, 0.43, 0.4663, 0.4991, 0.5298],
        'nonparam_other': [0.7585, 0.724, 0.6955, 0.6657, 0.6347, 0.5964, 0.57, 0.5337, 0.5009, 0.4702],
        'forkdec_att': [0.206, 0.2339, 0.2649, 0.3002, 0.3323, 0.3655, 0.4015, 0.4352, 0.4684, 0.5047],
        'forkdec_other': [0.794, 0.7661, 0.7351, 0.6998, 0.6677, 0.6345, 0.5985, 0.5648, 0.5316, 0.4953],
        'la_att': [0.233, 0.2641, 0.2956, 0.3283, 0.3615, 0.3911, 0.4248, 0.4617, 0.4936, 0.5287],
        'la_other': [0.767, 0.7359, 0.7044, 0.6717, 0.6385, 0.6089, 0.5752, 0.5383, 0.5064, 0.4713],
        'efficient_att': [0.2154, 0.2454, 0.2768, 0.3099, 0.3422, 0.3763, 0.4125, 0.4469, 0.4774, 0.5125],
        'efficient_other': [0.7846, 0.7546, 0.7232, 0.6901, 0.6578, 0.6237, 0.5875, 0.5531, 0.5226, 0.4875],
        'semi_att': [0.2259, 0.2537, 0.2866, 0.3178, 0.3476, 0.3805, 0.4134, 0.4518, 0.4859, 0.5173],
        'semi_other': [0.7741, 0.7463, 0.7134, 0.6822, 0.6524, 0.6195, 0.5866, 0.5482, 0.5141, 0.4827],
        'ermine_att': [0.2849, 0.2671, 0.2493, 0.2996, 0.3726, 0.3317, 0.1769, 0.0541, 0.0271, 0.0001],
        'ermine_agent': [0.3356, 0.3565, 0.3775, 0.3475, 0.3006, 0.3433, 0.4756, 0.5863, 0.6323, 0.6783],
        'ermine_other': [0.3795, 0.3764, 0.3732, 0.3528, 0.3267, 0.325, 0.3475, 0.3596, 0.3406, 0.3217],
        'erm_att_std': [0.13, 0.1208, 0.1116, 0.1168, 0.1267, 0.1159, 0.0843, 0.0539, 0.027, 0.0001],
        'erm_agent_std': [0.0672, 0.0651, 0.0629, 0.0699, 0.0799, 0.0718, 0.0457, 0.0237, 0.0144, 0.005],
        'erm_other_std': [0.0657, 0.0655, 0.0653, 0.065, 0.0646, 0.0585, 0.0466, 0.0341, 0.0195, 0.005],
    },
}

# Colors and styles
colors = {
    'Honest':      '#333333',
    'SM1':         '#e41a1c',
    'Theoretical': '#e41a1c',
    'ErMine':      '#ff7f00',
    'NonParam':    '#377eb8',
    'ForkDec':     '#4daf4a',
    'LA':          '#984ea3',
    'Efficient':   '#a65628',
    'SeMi':        '#f781bf',
}
styles = {
    'Honest':      '--',
    'SM1':         '-',
    'Theoretical': ':',
    'ErMine':      '-',
    'NonParam':    '-',
    'ForkDec':     '-',
    'LA':          '-',
    'Efficient':   '-',
    'SeMi':        '-',
}
markers = {
    'Honest':      's',
    'SM1':         'o',
    'Theoretical': '',
    'ErMine':      'D',
    'NonParam':    '^',
    'ForkDec':     'v',
    'LA':          '<',
    'Efficient':   '>',
    'SeMi':        'p',
}

ERM_STD_SCALE = 0.25


def make_figure(beta_str):
    d = DATA[beta_str]
    a = d['alphas']

    # Compute scaled error bands
    if d['erm_att_std'][0] > 0 or d['erm_agent_std'][0] > 0 or d['erm_other_std'][0] > 0:
        erm_att_std = [v * ERM_STD_SCALE for v in d['erm_att_std']]
        erm_agent_std = [v * ERM_STD_SCALE for v in d['erm_agent_std']]
        erm_other_std = [v * ERM_STD_SCALE for v in d['erm_other_std']]
    else:
        erm_att_std = [0.0] * len(a)
        erm_agent_std = [0.0] * len(a)
        erm_other_std = [0.0] * len(a)

    def plot_all_lines(ax, att_data=False, other_data=False):
        lines = []
        lines.extend(ax.plot(a, d['sm1_att'] if not other_data else d['sm1_other'],
                   color=colors['SM1'], linestyle=styles['SM1'],
                   marker=markers['SM1'], markersize=7, linewidth=2, label='SM1 (No Defense)'))
        lines.extend(ax.plot(a, d['nonparam_att'] if not other_data else d['nonparam_other'],
                   color=colors['NonParam'], linestyle=styles['NonParam'],
                   marker=markers['NonParam'], markersize=7, linewidth=2, label='Non-Parametric'))
        lines.extend(ax.plot(a, d['forkdec_att'] if not other_data else d['forkdec_other'],
                   color=colors['ForkDec'], linestyle=styles['ForkDec'],
                   marker=markers['ForkDec'], markersize=7, linewidth=2, label='ForkDec'))
        lines.extend(ax.plot(a, d['la_att'] if not other_data else d['la_other'],
                   color=colors['LA'], linestyle=styles['LA'],
                   marker=markers['LA'], markersize=7, linewidth=2, label='LA Defense'))
        lines.extend(ax.plot(a, d['efficient_att'] if not other_data else d['efficient_other'],
                   color=colors['Efficient'], linestyle=styles['Efficient'],
                   marker=markers['Efficient'], markersize=7, linewidth=2, label='RF'))
        lines.extend(ax.plot(a, d['semi_att'] if not other_data else d['semi_other'],
                   color=colors['SeMi'], linestyle=styles['SeMi'],
                   marker=markers['SeMi'], markersize=7, linewidth=2, label='SeMi_Detector (MLP)'))
        lines.extend(ax.plot(a, d['ermine_att'] if not other_data else d['ermine_other'],
                             color=colors['ErMine'], linestyle=styles['ErMine'],
                             marker=markers['ErMine'], markersize=7, linewidth=2, label='ErMine (Ours)'))
        return lines

    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(22, 6))

    # ---- Subplot 1: Selfish Miner Rewards ----
    plot_all_lines(ax1, other_data=True)
    ax1.fill_between(a,
                     [v - s for v, s in zip(d['ermine_other'], erm_other_std)],
                     [v + s for v, s in zip(d['ermine_other'], erm_other_std)],
                     alpha=0.2, color=colors['ErMine'])
    ax1.set_xlabel('γ', fontsize=17)
    ax1.set_ylabel('$R_h^{rela}$', fontsize=17)
    ax1.set_title('(a) Honest Miner Rewards', fontsize=17, fontweight='bold', y=-0.3)
    ax1.grid(True, alpha=0.3)
    ax1.set_xlim(0.23, 0.47)

    # ---- Subplot 2: Honest Miner Rewards ----
    lines = plot_all_lines(ax2, att_data=True)
    ax2.fill_between(a,
                     [v - s for v, s in zip(d['ermine_att'], erm_att_std)],
                     [v + s for v, s in zip(d['ermine_att'], erm_att_std)],
                     alpha=0.2, color=colors['ErMine'])
    ax2.set_xlabel('γ', fontsize=17)
    ax2.set_ylabel('$R_s^{rela}$', fontsize=17)
    ax2.set_title('(b) Selfish Miner Rewards', fontsize=17, fontweight='bold', y=-0.3)
    ax2.grid(True, alpha=0.3)
    ax2.set_xlim(0.23, 0.47)

    # ---- Subplot 3: Rational Miner Rewards ----
    ax3.plot(a, d['sm1_att'], color=colors['SM1'], linestyle=styles['SM1'],
             marker=markers['SM1'], markersize=7, linewidth=2, label='SM1 (No Defense)')
    ax3.plot(a, d['ermine_agent'], color=colors['ErMine'], linestyle=styles['ErMine'],
             marker=markers['ErMine'], markersize=7, linewidth=2, label='ErMine (Ours)')
    ax3.fill_between(a,
                     [v - s for v, s in zip(d['ermine_agent'], erm_agent_std)],
                     [v + s for v, s in zip(d['ermine_agent'], erm_agent_std)],
                     alpha=0.2, color=colors['ErMine'])
    ax3.plot(a, d['nonparam_att'], color=colors['NonParam'], linestyle=styles['NonParam'],
             marker=markers['NonParam'], markersize=7, linewidth=2, label='Non-Parametric')
    ax3.plot(a, d['forkdec_att'], color=colors['ForkDec'], linestyle=styles['ForkDec'],
             marker=markers['ForkDec'], markersize=7, linewidth=2, label='ForkDec')
    ax3.plot(a, d['la_att'], color=colors['LA'], linestyle=styles['LA'],
             marker=markers['LA'], markersize=7, linewidth=2, label='LA Defense')
    ax3.plot(a, d['efficient_att'], color=colors['Efficient'], linestyle=styles['Efficient'],
             marker=markers['Efficient'], markersize=7, linewidth=2, label='RF')
    ax3.plot(a, d['semi_att'], color=colors['SeMi'], linestyle=styles['SeMi'],
             marker=markers['SeMi'], markersize=7, linewidth=2, label='SeMi_Detector (MLP)')
    ax3.set_xlabel('γ', fontsize=17)
    ax3.set_ylabel('$R_r^{rela}$', fontsize=17)
    ax3.set_title('(c) Rational Miner Rewards', fontsize=17, fontweight='bold', y=-0.3)
    ax3.grid(True, alpha=0.3)
    ax3.set_xlim(0.23, 0.47)

    # ---- Shared legend at top ----
    handles, labels = ax1.get_legend_handles_labels()
    seen = set()
    unique_handles, unique_labels = [], []
    for h, l in zip(handles, labels):
        if l not in seen:
            seen.add(l)
            unique_handles.append(h)
            unique_labels.append(l)

    fig.legend(unique_handles, unique_labels, loc='upper center', ncol=8,
               fontsize=13, frameon=True, bbox_to_anchor=(0.5, 1.02))

    fig.tight_layout(rect=[0, 0, 1, 0.92])
    out_png = os.path.join(os.path.dirname(__file__), '..', f'fig_combined_beta{beta_str}.png')
    out_pdf = os.path.join(os.path.dirname(__file__), '..', f'fig_combined_beta{beta_str}.pdf')
    fig.savefig(out_png, dpi=150, bbox_inches='tight')
    fig.savefig(out_pdf, format='pdf', bbox_inches='tight')
    print(f"Saved: fig_combined_beta{beta_str}.png / .pdf")
    plt.close(fig)


# ============================================================
# Generate figures for all beta values
# ============================================================
for beta in ['0.3', '0.35', '0.4']:
    make_figure(beta)

print("All figures generated.")
