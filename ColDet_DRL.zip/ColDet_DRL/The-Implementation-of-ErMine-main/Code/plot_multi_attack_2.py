import matplotlib.pyplot as plt
import matplotlib
import csv
import os
import numpy as np

matplotlib.rcParams['font.family'] = 'serif'
matplotlib.rcParams['font.size'] = 17
matplotlib.rcParams['font.serif'] = ['Times New Roman']

# ============================================================
# Attack types and colors
# ============================================================
attack_names = ['SM', 'OSM', 'STM', 'BSM', 'ISM', 'FAW']
attack_labels = {
    'SM':  'SM (Eyal & Sirer)',
    'OSM': 'OSM (Sapirshtein)',
    'STM': 'STM (Nayak et al.)',
    'BSM': 'BSM (Bonneau)',
    'ISM': 'ISM',
    'FAW': 'FAW (Kwon et al.)',
}
colors = {
    'SM':  '#e41a1c',
    'OSM': '#377eb8',
    'STM': '#4daf4a',
    'BSM': '#ff7f00',
    'ISM': '#984ea3',
    'FAW': '#a65628',
}
markers = {
    'SM':  'o',
    'OSM': 's',
    'STM': 'D',
    'BSM': '^',
    'ISM': 'v',
    'FAW': 'p',
}


def load_data(beta_str):
    csv_path = os.path.join(os.path.dirname(__file__), '..', '..', 'Result', f'multi_attack_results_beta{beta_str}.csv')
    if not os.path.exists(csv_path):
        print(f"ERROR: {csv_path} not found.")
        return None

    data = {att: {'alpha': [], 'no_def_att': [], 'erm_att': [],
                  'no_def_honest': [], 'erm_honest': [],
                  'no_def_agent': [], 'erm_agent': []} for att in attack_names}

    with open(csv_path, 'r') as f:
        for row in csv.DictReader(f):
            att = row['attack']
            if att not in data:
                continue
            data[att]['alpha'].append(float(row['alpha']))
            data[att]['no_def_att'].append(float(row['no_def_att']))
            data[att]['erm_att'].append(float(row['erm_att']))
            data[att]['no_def_honest'].append(float(row['no_def_honest']))
            data[att]['erm_honest'].append(float(row['erm_honest']))
            data[att]['no_def_agent'].append(float(row['no_def_agent']))
            data[att]['erm_agent'].append(float(row['erm_agent']))

    return data


def make_figure(beta_str):
    d = load_data(beta_str)
    if d is None:
        return

    beta_val = float(beta_str)

    # Convert alpha → r = 1 - α - β for x-axis
    r_data = {}  # r_data[att] = [r0, r1, ...]
    for att in attack_names:
        r_data[att] = [1.0 - a - beta_val for a in d[att]['alpha']]

    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(24, 7))

    # Helper: compute smart y-limits from data (exclude NaN, add 8% margin)
    def auto_ylim(ax, *data_lists):
        all_vals = []
        for lst in data_lists:
            all_vals.extend([v for v in lst if v == v])  # filter NaN
        if not all_vals:
            return
        lo, hi = min(all_vals), max(all_vals)
        margin = max((hi - lo) * 0.08, 0.01)
        ax.set_ylim(lo - margin, hi + margin)

    # Compute x-axis range: r_max (left, weak attacker) → r_min (right, strong attacker)
    all_r = [v for att in attack_names for v in r_data[att]]
    r_lo, r_hi = min(all_r), max(all_r)
    x_pad = (r_hi - r_lo) * 0.04

    # ---- Subplot 1: Selfish Miner (Attacker) Revenue ----
    for att in attack_names:
        r = r_data[att]
        ax1.plot(r, d[att]['no_def_att'], color=colors[att], linestyle='-',
                 marker=markers[att], markersize=7, linewidth=2,
                 label=f'{att} (No Def)')
        # ax1.plot(r, d[att]['erm_att'], color=colors[att], linestyle='--',
        #          marker=markers[att], markersize=7, linewidth=2,
        #          label=f'{att} (ErMine)', markerfacecolor='white')

    # Baseline: under honest mining, attacker revenue = α = 1 - r - β
    r_base = r_data['SM']
    baseline_att = [1.0 - rv - beta_val for rv in r_base]
    ax1.plot(r_base, baseline_att, color='gray', linestyle=':',
             linewidth=1.5, alpha=0.6, label='Honest baseline')
    ax1.set_xlabel(r'γ ', fontsize=17)
    ax1.set_ylabel(r'$R_s^{rela}$', fontsize=17)
    ax1.set_title(f'(a) Selfish Miner Rewards  (β={beta_str})', fontsize=17, fontweight='bold',y=-0.2)
    ax1.grid(True, alpha=0.25)
    ax1.set_xlim(r_lo - x_pad, r_hi + x_pad)
    auto_ylim(ax1, baseline_att,
              *[d[att]['no_def_att'] for att in attack_names],
              *[d[att]['erm_att'] for att in attack_names if any(v == v for v in d[att]['erm_att'])])

    # ---- Subplot 2: Honest Miner Revenue ----
    for att in attack_names:
        r = r_data[att]
        ax2.plot(r, d[att]['no_def_honest'], color=colors[att], linestyle='-',
                 marker=markers[att], markersize=7, linewidth=2)
        # ax2.plot(r, d[att]['erm_honest'], color=colors[att], linestyle='--',
        #          marker=markers[att], markersize=7, linewidth=2, markerfacecolor='white')

    # Baseline: fair honest share = r (since r = 1 - α - β)
    r_base = r_data['SM']
    fair_honest = r_base  # y = r
    ax2.plot(r_base, fair_honest, color='gray', linestyle=':',
             linewidth=1.5, alpha=0.6)
    ax2.set_xlabel(r'γ ', fontsize=17)
    ax2.set_ylabel(r'$R_h^{rela}$', fontsize=17)
    ax2.set_title(f'(b) Honest Miner Rewards  (β={beta_str})', fontsize=17, fontweight='bold',y=-0.2)
    ax2.grid(True, alpha=0.25)
    ax2.set_xlim(r_lo - x_pad, r_hi + x_pad)
    auto_ylim(ax2, fair_honest,
              *[d[att]['no_def_honest'] for att in attack_names],
              *[d[att]['erm_honest'] for att in attack_names if any(v == v for v in d[att]['erm_honest'])])

    # ---- Subplot 3: Rational Miner (Agent) Revenue ----
    for att in attack_names:
        r = r_data[att]
        ax3.plot(r, d[att]['no_def_agent'], color=colors[att], linestyle='-',
                 marker=markers[att], markersize=7, linewidth=2)
        # ax3.plot(r, d[att]['erm_agent'], color=colors[att], linestyle='--',
        #          marker=markers[att], markersize=7, linewidth=2, markerfacecolor='white')
    # Baseline: under honest mining, rational miner revenue = β (constant)
    r_base = r_data['SM']
    baseline_agent = [beta_val] * len(r_base)
    ax3.plot(r_base, baseline_agent, color='gray', linestyle=':',
             linewidth=1.5, alpha=0.6)
    ax3.set_xlabel(r'γ ', fontsize=17)
    ax3.set_ylabel(r'$R_r^{rela}$', fontsize=17)
    ax3.set_title(f'(c) Rational Miner Rewards  (β={beta_str})', fontsize=17, fontweight='bold',y=-0.2)
    ax3.grid(True, alpha=0.25)
    ax3.set_xlim(r_lo - x_pad, r_hi + x_pad)
    auto_ylim(ax3, baseline_agent,
              *[d[att]['no_def_agent'] for att in attack_names],
              *[d[att]['erm_agent'] for att in attack_names if any(v == v for v in d[att]['erm_agent'])])

    # ---- Build legend: attack-type rows, solid=No Def, dashed=ErMine ----
    from matplotlib.lines import Line2D
    legend_elements = []
    # Add attack type lines
    for att in attack_names:
        legend_elements.append(Line2D([0], [0], color=colors[att], linestyle='-',
                                      marker=markers[att], markersize=8, linewidth=2,
                                      label=f'{att}'))
    legend_elements.append(Line2D([0], [0], color='gray', linestyle=':', linewidth=1.5, label='Honest (Baseline)'))
    #legend_elements.append(Line2D([0], [0], color='black', linestyle='--', linewidth=2, label='ErMine Defense'))

    fig.legend(handles=legend_elements, loc='upper center', ncol=len(legend_elements),
               fontsize=13, frameon=True, bbox_to_anchor=(0.5, 1.0))

    fig.tight_layout(rect=[0, 0, 1, 0.90])
    out_path = os.path.join(os.path.dirname(__file__), '..', f'fig_multi_attack_beta{beta_str}.png')
    fig.savefig(out_path, dpi=150, bbox_inches='tight')
    print(f"Saved: fig_multi_attack_beta{beta_str}.png")
    plt.close(fig)


# ============================================================
# Generate figures for all beta values
# ============================================================
for beta in ['0.2', '0.3', '0.4']:
    make_figure(beta)

print("All figures generated.")
