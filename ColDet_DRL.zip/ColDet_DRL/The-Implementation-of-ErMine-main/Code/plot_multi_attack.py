import matplotlib.pyplot as plt
import matplotlib
import csv
import os
import numpy as np

matplotlib.rcParams['font.family'] = 'serif'
matplotlib.rcParams['font.size'] = 17
matplotlib.rcParams['font.serif'] = ['Times New Roman']

# ============================================================
# Attack types and colors
# ============================================================
attack_names = ['SM', 'OSM', 'STM', 'BSM', 'ISM', 'FAW']
attack_labels = {
    'SM':  'SM (Eyal & Sirer)',
    'OSM': 'OSM (Sapirshtein)',
    'STM': 'STM (Nayak et al.)',
    'BSM': 'BSM (Bonneau)',
    'ISM': 'ISM',
    'FAW': 'FAW (Kwon et al.)',
}
colors = {
    'SM':  '#e41a1c',
    'OSM': '#377eb8',
    'STM': '#4daf4a',
    'BSM': '#ff7f00',
    'ISM': '#984ea3',
    'FAW': '#a65628',
}
markers = {
    'SM':  'o',
    'OSM': 's',
    'STM': 'D',
    'BSM': '^',
    'ISM': 'v',
    'FAW': 'p',
}


def load_data(beta_str):
    csv_path = os.path.join(os.path.dirname(__file__), '..', '..', 'Result', f'multi_attack_results_beta{beta_str}.csv')
    if not os.path.exists(csv_path):
        print(f"ERROR: {csv_path} not found.")
        return None

    data = {att: {'alpha': [], 'no_def_att': [], 'erm_att': [],
                  'no_def_honest': [], 'erm_honest': [],
                  'no_def_agent': [], 'erm_agent': []} for att in attack_names}

    with open(csv_path, 'r') as f:
        for row in csv.DictReader(f):
            att = row['attack']
            if att not in data:
                continue
            data[att]['alpha'].append(float(row['alpha']))
            data[att]['no_def_att'].append(float(row['no_def_att']))
            data[att]['erm_att'].append(float(row['erm_att']))
            data[att]['no_def_honest'].append(float(row['no_def_honest']))
            data[att]['erm_honest'].append(float(row['erm_honest']))
            data[att]['no_def_agent'].append(float(row['no_def_agent']))
            data[att]['erm_agent'].append(float(row['erm_agent']))

    return data


# ============================================================
# Role configuration
# ============================================================
ROLE_CONFIG = {
    'att':    {'data_key': 'no_def_att',    'ylabel': r'$R_s^{rela}$', 'title': 'Honest Miner Rewards',
               'letter': 'a', 'filename': 'selfish'},
    'honest': {'data_key': 'no_def_honest', 'ylabel': r'$R_h^{rela}$', 'title': 'Selfish Miner Rewards',
               'letter': 'b', 'filename': 'honest'},
    'agent':  {'data_key': 'no_def_agent',  'ylabel': r'$R_r^{rela}$', 'title': 'Rational Miner Rewards',
               'letter': 'c', 'filename': 'rational'},
}


def preload_all_data():
    """Load data for all betas at once. Returns {beta_str: (data_dict, beta_val, r_data)}."""
    all_data = {}
    all_r_vals = []

    for beta_str in ['0.2', '0.3', '0.4']:
        d = load_data(beta_str)
        if d is None:
            continue
        beta_val = float(beta_str)
        r_data = {}
        for att in attack_names:
            r_vals = [1.0 - a - beta_val for a in d[att]['alpha']]
            r_data[att] = r_vals
            all_r_vals.extend(r_vals)
        all_data[beta_str] = (d, beta_val, r_data)

    r_lo, r_hi = (min(all_r_vals), max(all_r_vals)) if all_r_vals else (0, 1)
    return all_data


def make_role_figure(role, all_data):
    """Generate a 3-subplot figure for a given role across beta=0.2, 0.3, 0.4."""
    cfg = ROLE_CONFIG[role]
    betas = ['0.2', '0.3', '0.4']

    fig, axes = plt.subplots(1, 3, figsize=(24, 7))

    for idx, beta_str in enumerate(betas):
        ax = axes[idx]
        if beta_str not in all_data:
            continue
        d, beta_val, r_data = all_data[beta_str]

        # Plot all attack lines
        for att in attack_names:
            r = r_data[att]
            ax.plot(r, d[att][cfg['data_key']], color=colors[att], linestyle='-',
                    marker=markers[att], markersize=7, linewidth=2)

        ax.set_xlabel(r'γ', fontsize=17)
        ax.set_ylabel(cfg['ylabel'], fontsize=17)
        ax.set_title(f'{["(a)", "(b)", "(c)"][idx]}  {cfg["title"]}  (β={beta_str})',
                     fontsize=17, fontweight='bold', y=-0.2)
        ax.grid(True, alpha=0.25)

        # Per-subplot x-range from this beta's own data
        sub_r_vals = [v for att in attack_names for v in r_data[att]]
        sub_lo, sub_hi = min(sub_r_vals), max(sub_r_vals)
        sub_pad = (sub_hi - sub_lo) * 0.04
        ax.set_xlim(sub_lo - sub_pad, sub_hi + sub_pad)

        # Auto y-lim: fit to data range with 15% padding, don't force y=0
        all_vals = []
        for att in attack_names:
            all_vals.extend([v for v in d[att][cfg['data_key']] if v == v])
        if all_vals:
            lo, hi = min(all_vals), max(all_vals)
            span = hi - lo
            margin = max(span * 0.15, 0.02)
            ax.set_ylim(lo - margin, hi + margin)

    # ---- Shared legend ----
    from matplotlib.lines import Line2D
    legend_elements = []
    for att in attack_names:
        legend_elements.append(Line2D([0], [0], color=colors[att], linestyle='-',
                                      marker=markers[att], markersize=8, linewidth=2,
                                      label=f'{att}'))
    fig.legend(handles=legend_elements, loc='upper center', ncol=len(legend_elements),
               fontsize=13, frameon=True, bbox_to_anchor=(0.5, 1.0))

    fig.tight_layout(rect=[0, 0, 1, 0.88])
    out_path = os.path.join(os.path.dirname(__file__), '..', f'fig_multi_attack_{cfg["filename"]}.pdf')
    fig.savefig(out_path, format='pdf', bbox_inches='tight')
    print(f"Saved: fig_multi_attack_{cfg['filename']}.pdf")
    plt.close(fig)


# ============================================================
# Generate figures: one per role, each with 3 beta subplots
# ============================================================
all_data = preload_all_data()

for role in ['att', 'honest', 'agent']:
    make_role_figure(role, all_data)

print("All figures generated.")
