"""
Split the 3-panel multi_attack figures into individual beta×role figures.
Each figure: one role, one beta, 6 attack types with no_def + ErMine lines.
Outputs 9 individual figures.
Legend matches original big figures (2 rows × 4 cols).
"""
import matplotlib.pyplot as plt
import matplotlib
import csv
import os
import numpy as np

matplotlib.rcParams['font.family'] = 'serif'
matplotlib.rcParams['font.size'] = 18
matplotlib.rcParams['font.serif'] = ['Times New Roman']

BASE = os.path.join(os.path.dirname(__file__), '..', '..')

attack_names = ['SM', 'OSM', 'STM', 'BSM', 'ISM', 'FAW']

colors = {
    'SM':  '#e41a1c',
    'OSM': '#377eb8',
    'STM': '#4daf4a',
    'BSM': '#ff7f00',
    'ISM': '#984ea3',
    'FAW': '#a65628',
}
markers = {
    'SM':  'o',
    'OSM': 's',
    'STM': 'D',
    'BSM': '^',
    'ISM': 'v',
    'FAW': 'p',
}

ROLE_CONFIG = {
    'selfish': {
        'data_key_no_def': 'no_def_att', 'data_key_erm': 'erm_att',
        'ylabel': r'$R_s^{rela}$', 'filename': 'selfish',
    },
    'honest': {
        'data_key_no_def': 'no_def_honest', 'data_key_erm': 'erm_honest',
        'ylabel': r'$R_h^{rela}$', 'filename': 'honest',
    },
    'rational': {
        'data_key_no_def': 'no_def_agent', 'data_key_erm': 'erm_agent',
        'ylabel': r'$R_r^{rela}$', 'filename': 'rational',
    },
}


def load_data(beta_str):
    csv_path = os.path.join(BASE, 'Result', f'multi_attack_results_beta{beta_str}.csv')
    if not os.path.exists(csv_path):
        print(f"ERROR: {csv_path} not found.")
        return None

    data = {att: {'alpha': [], 'r': [], 'no_def_att': [], 'erm_att': [],
                  'no_def_honest': [], 'erm_honest': [],
                  'no_def_agent': [], 'erm_agent': []} for att in attack_names}

    beta_val = float(beta_str)
    with open(csv_path, 'r') as f:
        for row in csv.DictReader(f):
            att = row['attack']
            if att not in data:
                continue
            alpha = float(row['alpha'])
            r_val = 1.0 - alpha - beta_val
            data[att]['alpha'].append(alpha)
            data[att]['r'].append(r_val)
            data[att]['no_def_att'].append(float(row['no_def_att']))
            data[att]['erm_att'].append(float(row['erm_att']) if row['erm_att'] != 'nan' else float('nan'))
            data[att]['no_def_honest'].append(float(row['no_def_honest']))
            data[att]['erm_honest'].append(float(row['erm_honest']) if row['erm_honest'] != 'nan' else float('nan'))
            data[att]['no_def_agent'].append(float(row['no_def_agent']))
            data[att]['erm_agent'].append(float(row['erm_agent']) if row['erm_agent'] != 'nan' else float('nan'))

    return data


def make_single_figure(beta_str, role):
    d = load_data(beta_str)
    if d is None:
        return
    cfg = ROLE_CONFIG[role]
    beta_val = float(beta_str)

    fig, ax = plt.subplots(figsize=(10, 6))

    # Plot attack types: solid lines only (same as original big figure)
    for att in attack_names:
        r = d[att]['r']
        key_nd = cfg['data_key_no_def']
        ax.plot(r, d[att][key_nd], color=colors[att], linestyle='-',
                marker=markers[att], markersize=8, linewidth=2.5,
                label=att)

    # Baseline
    r_base = d['SM']['r']
    if role == 'selfish':
        baseline = [1.0 - rv - beta_val for rv in r_base]
    elif role == 'honest':
        baseline = r_base
    else:
        baseline = [beta_val] * len(r_base)
    ax.plot(r_base, baseline, color='gray', linestyle=':', linewidth=1.8, alpha=0.7,
            label='Honest (Baseline)')

    ax.set_xlabel(r'$\gamma$', fontsize=22)
    ax.set_ylabel(cfg['ylabel'], fontsize=22)
    ax.grid(True, alpha=0.3)
    ax.tick_params(labelsize=16)

    # x-range
    all_r = [v for att in attack_names for v in d[att]['r']]
    r_lo, r_hi = min(all_r), max(all_r)
    pad = (r_hi - r_lo) * 0.05
    ax.set_xlim(r_lo - pad, r_hi + pad)

    # Auto y-lim
    all_vals = list(baseline)
    for att in attack_names:
        all_vals.extend([v for v in d[att][cfg['data_key_no_def']] if v == v])
        all_vals.extend([v for v in d[att][cfg['data_key_erm']] if v == v])
    if all_vals:
        lo, hi = min(all_vals), max(all_vals)
        span = hi - lo
        margin = max(span * 0.1, 0.02)
        ax.set_ylim(lo - margin, hi + margin)

    # Legend: 2 rows × 4 cols, same content as original big figure
    from matplotlib.lines import Line2D
    legend_elements = []
    for att in attack_names:
        legend_elements.append(Line2D([0], [0], color=colors[att], linestyle='-',
                                     marker=markers[att], markersize=8, linewidth=2.5,
                                     label=att))
    legend_elements.append(Line2D([0], [0], color='gray', linestyle=':', linewidth=1.8,
                                 label='Honest (Baseline)'))
    ax.legend(handles=legend_elements, loc='upper center', fontsize=13,
              frameon=True, ncol=4, handlelength=2.5, columnspacing=1.0)

    fig.tight_layout()
    out_path = os.path.join(BASE, 'Figure', f'fig_multi_{cfg["filename"]}_beta{beta_str}.png')
    fig.savefig(out_path, dpi=200, bbox_inches='tight')
    print(f"Saved: fig_multi_{cfg['filename']}_beta{beta_str}.png")
    plt.close(fig)


if __name__ == '__main__':
    for beta_str in ['0.2', '0.3', '0.4']:
        for role in ['selfish', 'honest', 'rational']:
            make_single_figure(beta_str, role)
    print("\nAll 9 individual figures generated.")
