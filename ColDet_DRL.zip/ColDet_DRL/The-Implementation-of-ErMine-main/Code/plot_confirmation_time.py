import matplotlib.pyplot as plt
import matplotlib
import os

matplotlib.rcParams['font.family'] = 'serif'
matplotlib.rcParams['font.size'] = 17
matplotlib.rcParams['font.serif'] = ['Times New Roman']

methods = [
    ('Honest',      'honest_ct',  '#333333', '--', 's', 'Honest (Baseline)'),
    ('SM1',         'sm1_ct',     '#e41a1c', '-',  'o', 'SM1 (No Defense)'),
    ('NonParam',    'nonparam_ct','#377eb8', '-',  '^', 'Non-Parametric'),
    ('ForkDec',     'forkdec_ct', '#4daf4a', '-',  'v', 'ForkDec'),
    ('LA',          'la_ct',      '#984ea3', '-',  '<', 'LA Defense'),
    ('Efficient',   'efficient_ct','#a65628', '-',  '>', 'Efficient (RF)'),
    ('SeMi',        'semi_ct',    '#f781bf', '-',  'p', 'SeMi_Detector (MLP)'),
    ('ErMine',      'ermine_ct',  '#ff7f00', '-',  'D', 'ErMine (Ours)'),
]

ZONES_ALPHA = [
    (0.23, 0.30, '#E8F5E9'),
    (0.30, 0.40, '#FFF8E1'),
    (0.40, 0.47, '#FFEBEE'),
]

# ========== Hardcoded data for beta = 0.4 ==========
BETA = 0.4
ALPHAS = [0.25, 0.2722222222222222, 0.29444444444444445, 0.31666666666666665,
          0.3388888888888889, 0.3611111111111111, 0.3833333333333333,
          0.40555555555555556, 0.4277777777777778, 0.45]

DATA = {
    'honest_ct':    [7.0,   8.0,   8.0,   9.0,  11.0,  13.0,  15.0,  19.0,    24.0,     35.0],
    'sm1_ct':       [7.92,  9.17, 10.46, 11.76, 15.54, 21.93, 33.43, 65.62,   float('inf'), 1900],
    'ermine_ct':    [1.77,  1.77, 7.12, 9.12, 10.62, 10.62, 7.92, 8.0, 2.38,   2.38],
    'nonparam_ct':  [7.91,  9.18, 10.47, 12.95, 15.51, 21.93, 30.88, 65.43, 464.68,   6464.68],
    'forkdec_ct':   [6.49,  6.55,  7.74, 10.09, 11.38, 15.01, 21.17, 32.3,    60.08,   900],
    'la_ct':        [6.7,   7.92,  9.19, 11.64, 15.36, 19.22, 28.06, 57.27,  342.77,   1700],
    'efficient_ct': [6.56,  7.75,  8.97, 10.23, 12.69, 16.4,  23.92, 40.19,   95.43,   1200],
    'semi_ct':      [6.64,  7.82,  9.08, 11.49, 12.82, 17.75, 24.07, 44.23,  154.06,  1500],
}


def draw_background_zones(ax):
    for a_start, a_end, color in ZONES_ALPHA:
        r_start = 1.0 - a_end - BETA
        r_end = 1.0 - a_start - BETA
        ax.axvspan(r_start, r_end, facecolor=color, edgecolor='none', alpha=0.50, zorder=0)


def make_figure():
    r_vals = [1.0 - a - BETA for a in ALPHAS]

    fig, ax = plt.subplots(figsize=(12, 8))
    draw_background_zones(ax)

    for name, key, color, style, marker, label in methods:
        vals = DATA[key]
        valid_x = [r for r, v in zip(r_vals, vals) if v != float('inf')]
        valid_y = [v for v in vals if v != float('inf')]
        if len(valid_x) > 1:
            ax.plot(valid_x, valid_y, color=color, linestyle=style,
                    marker=marker, markersize=8, linewidth=2, label=label)

    ax.set_xlabel(r'$\gamma$', fontsize=22)
    ax.set_ylabel('Confirmation Time (blocks)', fontsize=22)
    ax.set_title(r'Confirmation Time  ($\beta$=0.4)', fontsize=18, fontweight='bold', pad=12)
    ax.grid(True, alpha=0.25, zorder=5)
    ax.set_xlim(min(r_vals) - 0.01, max(r_vals) + 0.01)
    ax.tick_params(labelsize=15)
    ax.set_yscale('log')

    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, labels, loc='upper center', fontsize=13, frameon=True, ncol=4)

    fig.tight_layout()
    out_path = os.path.join(os.path.dirname(__file__), '..', 'fig_confirmation_time_beta0.4.png')
    fig.savefig(out_path, dpi=150, bbox_inches='tight')
    print(f"Saved: fig_confirmation_time_beta0.4.png")
    plt.close(fig)


if __name__ == '__main__':
    make_figure()
    print("Done.")
