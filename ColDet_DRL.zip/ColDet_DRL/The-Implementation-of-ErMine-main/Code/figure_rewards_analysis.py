
import numpy as np
import scienceplots
import matplotlib.pyplot as plt
from matplotlib import patheffects
from matplotlib.ticker import MaxNLocator

import cmaps



# =========== data for rewards analysis ==============



# 用于绘制 agent 采用 PBMN 和诚实挖矿 时 收益的比较
# 折线图
def agent_rewards_plot():
    betas = [0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45]

    # agent's rewards when alpha = 0.3
    reward_PBMN_alpha03 = [0.1041, 0.1465, 0.2025, 0.2459, 0.2977, 0.3502, 0.4164, 0.4534] # taken PBMN
    reward_honest_alpha03 = [0.0962, 0.1442, 0.1923, 0.2404, 0.2885, 0.3366, 0.3846, 0.4327] # behave honest

    # agent's rewards when alpha = 0.35
    reward_PBMN_alpha035 = [0.0917,0.138, 0.1873, 0.2320, 0.2793, 0.3277, 0.3770, 0.4262]  # taken PBMN
    reward_honest_alpha035 = [0.0898, 0.1348, 0.1797, 0.2246, 0.2695, 0.3145, 0.3594, 0.4043 ]  # behave honest

    # agent's rewards when alpha = 0.4
    reward_PBMN_alpha04 = [0.0837, 0.1243, 0.1623, 0.2046, 0.2460, 0.2901, 0.3342,  0.3692 ]  # taken PBMN
    reward_honest_alpha04 = [0.0791, 0.1186, 0.1581, 0.1977, 0.2372, 0.2767, 0.3163, 0.3558]  # behave honest


    with plt.style.context(['science', 'bright', 'no-latex']):

        fig, ax = plt.subplots(figsize=(10, 6.5))

        # 控制边框的显示与否
        # ax.spines['right'].set_visible(False)
        # ax.spines['top'].set_visible(False)
        # ax.spines['left'].set_color('none')

        ax.plot(betas, reward_PBMN_alpha03, color='#C44E52', linestyle='-', linewidth=4, marker='s', markevery=1, markersize=17,label="ErMine")
        ax.plot(betas, reward_honest_alpha03,  color='#55A868', linestyle='-', linewidth=4, marker='o', markevery=1, markersize=17,label="SM1")

        # 控制显示的坐标刻度的个数
        # ax.xaxis.set_major_locator(MaxNLocator(4))
        ax.yaxis.set_major_locator(MaxNLocator(6))

        plt.ylim(0.05, 0.5)
        # plt.xlim(0, 0.5)
        plt.xlabel(r"agent's mining power $\beta$", fontdict={'family': 'Times New Roman', 'size': 35})
        plt.ylabel("$R_a^{rela}$", fontdict={'family': 'Times New Roman', 'size': 35})

        plt.legend(loc='upper left', handlelength=2,
                   prop={'family': 'Times New Roman', 'size': 33})

        plt.xticks(fontproperties='Times New Roman', size=33)
        plt.yticks(fontproperties='Times New Roman', size=33)

        plt.show()



# 绘制 attacker 的收益 受 PBMN的影响:
# 热力图：alpha from 0.25 to 0.45; beta form 0.25 to 0.45
def attacker_rewards_heatmap():

    betas = [0.25, 0.3, 0.35, 0.4, 0.45]
    alphas = [0.45, 0.4, 0.35, 0.3, 0.25]

    harvest = np.array([[0.2188, 0.3176, 0.3830, 0.5021, 0.6581],
                        [0.2414, 0.3118, 0.3872, 0.4961, 0.6582],
                        [0.2507, 0.3011, 0.3913, 0.5228, 0.6629],
                        [0.2498, 0.3059, 0.3937, 0.5076, 0.6657],
                        [0.2316, 0.3095, 0.3987, 0.5095, 0.6697] ])


    with plt.style.context(['science', 'bright', 'no-latex']):

        fig, ax = plt.subplots()

        # 使用 cmaps这个包中的 配色
        cmap_color = cmaps.GMT_split
        cmap_color = cmap_color.reversed() # 如需反转colorbar，其方法是cmap_color=cmap_color.reversed()

        im = ax.imshow(harvest, alpha=1 ,cmap=cmap_color)

        # Create colorbar
        cbar = ax.figure.colorbar(im, ax=ax)
        # cbar.ax.set_ylabel(cbarlabel, rotation=-90, va="bottom")

        # Show all ticks and label them with the respective list entries
        ax.set_xticks(np.arange(len(alphas)))
        ax.set_yticks(np.arange(len(betas)))

        # Rotate the tick labels and set their alignment.
        plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
                 rotation_mode="anchor")

        # Loop over data dimensions and create text annotations.
        for i in range(len(betas)):
            for j in range(len(alphas)):
                text = ax.text(j, i, harvest[i, j],
                               ha="center", va="center", color="w")

        ax.set_title("Harvest of local farmers (in tons/year)")
        fig.tight_layout()
        plt.show()



def att_and_honest_rewards_plot():

    alphas = np.arange(0.25, 0.5, 0.05)

    # beta=0.25时，attacker的收益
    att_rewards_PBMN_beta025 = [0.2316, 0.3095, 0.3987, 0.5095, 0.6697] # 采用 PBMN时
    att_rewards_honest_beta025 = [0.25, 0.3269, 0.4160, 0.5256, 0.6806] # 无 PBMN时，attacker 理论收益

    # beta=0.25时，other honest 的收益
    other_rewards_PBMN_beta025 = [0.5121, 0.4446, 0.3692, 0.2859, 0.1806]  # 采用 PBMN时
    other_rewards_honest_beta025 = [0.50, 0.4327, 0.3594, 0.2767, 0.1742]  # 无 PBMN时，attacker 理论收益

    # --------------------

    # beta=0.3时，attacker的收益
    att_rewards_PBMN_beta03 = [0.2498, 0.3059, 0.3937, 0.5076, 0.6657]  # 采用 PBMN时
    att_rewards_honest_beta03 = [0.25, 0.3269, 0.4160, 0.5256, 0.6806]  # 无 PBMN时，attacker 理论收益

    # beta=0.3时，other honest 的收益
    other_rewards_PBMN_beta03 = [0.4474, 0.3964, 0.3270, 0.2464, 0.1524]  # 采用 PBMN时
    other_rewards_honest_beta03 = [0.45, 0.3846, 0.3145, 0.2372, 0.1452]  # 无 PBMN时，attacker 理论收益


    # --------------------

    # beta=0.3时，attacker的收益
    att_rewards_PBMN_beta035 = [0.2507, 0.3011, 0.3913, 0.5228, 0.6629]  # 采用 PBMN时
    att_rewards_honest_beta035 = [0.25, 0.3269, 0.4160, 0.5256, 0.6806]  # 无 PBMN时，attacker 理论收益

    # beta=0.3时，other honest 的收益
    other_rewards_PBMN_beta035 = [0.3871, 0.3487, 0.2811, 0.1871, 0.1224]  # 采用 PBMN时
    other_rewards_honest_beta035 = [0.4, 0.3366, 0.2695, 0.1977, 0.1161]  # 无 PBMN时，attacker 理论收益


    with plt.style.context(['science', 'bright', 'no-latex']):

        fig, ax = plt.subplots(figsize=(10, 6.5))

        ax.plot(alphas, att_rewards_PBMN_beta025, color='#C44E52', linestyle='-', linewidth=4, marker='s', markevery=1, markersize=17,label="$R_s^{rela}$ (ErMine)")
        ax.plot(alphas, att_rewards_honest_beta025,  color='#55A868', linestyle='-', linewidth=4, marker='o', markevery=1, markersize=17,label="$R_s^{rela}$")

        # 暂存前两个图例
        legend1 = plt.legend(loc='upper left',  handlelength=2,
                             prop={'family': 'Times New Roman', 'size': 26})


        l3, = ax.plot(alphas, other_rewards_PBMN_beta025, color='#4C72B0',  linestyle='-', linewidth=4, marker='X', markevery=1, markersize=17,label="$R_h^{rela}$ (ErMine)")
        l4, = ax.plot(alphas, other_rewards_honest_beta025, color='#8172B2',  linestyle='-', linewidth=4, marker='^', markevery=1, markersize=17,label="$R_h^{rela}$")

        # 控制显示的坐标刻度的个数
        ax.xaxis.set_major_locator(MaxNLocator(6))
        # ax.yaxis.set_major_locator(MaxNLocator(6))

        # plt.ylim(0.05, 0.5)
        # plt.xlim(0, 0.5)
        plt.xlabel(r"mining power $\alpha$", fontdict={'family': 'Times New Roman', 'size': 35})
        plt.ylabel("relative reward", fontdict={'family': 'Times New Roman', 'size': 35})

        # 显示后三个图例，该函数会覆盖 前三个图例（legend1）
        plt.legend([l3, l4], ['$R_h^{rela}$ (ErMine)', '$R_h^{rela}$'],
                   loc='upper left', bbox_to_anchor=(0.52, 0.585), handlelength=2,
                   prop={'family': 'Times New Roman', 'size': 26})
        # 重新显示前三个图例
        plt.gca().add_artist(legend1)

        plt.xticks(fontproperties='Times New Roman', size=33)
        plt.yticks(fontproperties='Times New Roman', size=33)


        plt.show()


# 该函数 弃用
def rewards_3parties_plot():


    betas = [0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45]

    # attacker's rewards when alpha = 0.3

    att_reward_PBMN_alpha03 = [0.3166, 0.3195, 0.3123, 0.3095, 0.3059, 0.3011, 0.3118, 0.3176]
    att_reward_honest_alpha03 = [0.3269, 0.3269, 0.3269, 0.3269, 0.3269, 0.3269, 0.3269, 0.3269]

    # agent's rewards when alpha = 0.3
    reward_PBMN_alpha03 = [0.1041, 0.1465, 0.2025, 0.2459, 0.2977, 0.3502, 0.4164, 0.4534]  # taken PBMN
    reward_honest_alpha03 = [0.0962, 0.1442, 0.1923, 0.2404, 0.2885, 0.3366, 0.3846, 0.4327]  # behave honest

    # agent's rewards when alpha = 0.35
    reward_PBMN_alpha035 = [0.0917, 0.138, 0.1873, 0.2320, 0.2793, 0.3277, 0.3770, 0.4262]  # taken PBMN
    reward_honest_alpha035 = [0.0898, 0.1348, 0.1797, 0.2246, 0.2695, 0.3145, 0.3594, 0.4043]  # behave honest

    # agent's rewards when alpha = 0.4
    reward_PBMN_alpha04 = [0.0837, 0.1243, 0.1623, 0.2046, 0.2460, 0.2901, 0.3342, 0.3692]  # taken PBMN
    reward_honest_alpha04 = [0.0791, 0.1186, 0.1581, 0.1977, 0.2372, 0.2767, 0.3163, 0.3558]  # behave honest


    fig, axs = plt.subplots(2, 1)
    axs[0].plot(betas, att_reward_PBMN_alpha03, betas, att_reward_honest_alpha03)
    axs[0].set_ylim(0.1, 0.4)
    # axs[0].set_xlabel('time')
    axs[0].set_ylabel("$R_a^{rela}$", fontdict={'family': 'Times New Roman', 'size': 10})
    axs[0].grid(True)

    axs[1].plot(betas, reward_PBMN_alpha03, betas, reward_honest_alpha03)
    #axs[1].set_ylim(0.1, 0.4)
    axs[1].set_ylabel("$R_s^{rela}$", fontdict={'family': 'Times New Roman', 'size': 10})
    #axs[1].set_ylabel('coherence')
    axs[1].grid(False)



    fig.tight_layout()

    plt.xlabel(r"agent's mining power $\beta$", fontdict={'family': 'Times New Roman', 'size': 10})
    # plt.ylabel("$R_a^{rela}$", fontdict={'family': 'Times New Roman', 'size': 35})
    plt.show()







if __name__ == '__main__':
    # agent_rewards_plot()

    # rewards_3parties_plot() # 弃用

    att_and_honest_rewards_plot()
