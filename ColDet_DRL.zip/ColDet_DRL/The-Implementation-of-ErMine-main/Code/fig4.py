import numpy as np
import scienceplots
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from matplotlib import patheffects
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.axes_grid1.inset_locator import inset_axes,mark_inset

import cmaps

import statistics


def Accuracy_analysis():

    # plt.figure(figsize=(13, 8))

    # 创建数据
    cost_factors = np.arange(0, 2000, 166)

    x = cost_factors

    #Accutacy

    methods = {
        'ErMine': [0,0.59081,0.70095,0.80982,0.85752,0.88682,0.899011,0.90632,0.92777,0.950843,0.970082,0.98763,0.99972],
        'BPNN': [0,0.35245,0.58098,0.68763,0.77987,0.82154,0.84309,0.84632,0.85271,0.87453,0.876532,0.90208,0.90987],
        'Boosting': [0,0.45065,0.632456,0.72463,0.80453,0.85023,0.86964,0.87908,0.88763,0.89832,0.91512,0.93452,0.95633],
        'SM_NEEDLE': [0,0.57132,0.72543,0.82732,0.87764,0.88983,0.89730,0.90963,0.91921,0.93981,0.95872,0.96452,0.979]
    }




    # 绘制各方法曲线
    #colors = plt.cm.Set2(np.linspace(0, 1, len(methods)))
    colors = ["#014382","#C9631B","#FDC101","#55A868"]
    markstyle = ['s', 'o', '^', 'd']



    with plt.style.context(['science', 'bright', 'no-latex']):
        fig, ax = plt.subplots(figsize=(13, 8))
        for i, (name, y) in enumerate(methods.items()):
            plt.plot(x, y, color=colors[i], linewidth=3.5, label=name, marker=markstyle[i], markersize=9)

        # 选择关键点显示差值
        plt.xticks(fontproperties='Times New Roman', size=23)
        plt.yticks(fontproperties='Times New Roman', size=23)
        key_points = [1000]

        for x_point in key_points:
            # 找到最近的数据点索引
            idx = np.argmin(np.abs(x - x_point))

            # 绘制垂直线
            plt.axvline(x=x_point, color='gray', linestyle=':', alpha=0.5, linewidth=1)

            # 收集该点的所有值
            point_values = {}
            for name, y in methods.items():
                point_values[name] = y[idx]

            # 按值排序
            sorted_items = sorted(point_values.items(), key=lambda x: x[1], reverse=True)


        # 设置图表属性
        plt.xlabel('The Number of Training Round', fontsize=33)
        plt.ylabel('Accuracy', fontsize=33 )
        #plt.title('Performance Comparison with Difference Analysis', fontsize=29, fontweight='bold')
        plt.legend(loc='upper left',
                   prop={'family': 'Times New Roman', 'size': 15})
        plt.grid(True, alpha=0.3)



        # 添加插图
        ax_inset = inset_axes(ax, width="50%", height="66%", bbox_to_anchor=(.6, .006, .7, .6),
                              bbox_transform=ax.transAxes, loc='upper left')

        for i, (name, y) in enumerate(methods.items()):
            ax_inset.plot(x, y, color=colors[i], linewidth=3, label=name, marker=markstyle[i], markersize=7)


        ax_inset.set_xlim(1450,2050)
        ax_inset.set_ylim(0.85, 1)
        plt.grid(True)
        mark_inset(ax, ax_inset, loc1=4, loc2=2, fc="none", ec='k', lw=0.7)  # 1 (右上) 2 (左上) 3(左下) 4(右下)
        ax_inset.tick_params(axis='both', which='major', labelsize=23)  # 设置刻度标签的字体大小

        plt.savefig('C:/Users/23945/Desktop/result/fig4_Accuracy.png')
        plt.tight_layout()
        plt.show()




def Precision_analysis():

    # plt.figure(figsize=(13, 8))

    # 创建数据
    cost_factors = np.arange(0, 2000, 166)

    x = cost_factors
    #Precision

    methods = {
        'ErMine' : [0,0.47234,0.67273,0.83984,0.87834,0.90992,0.92364,0.937023,0.959456,0.96345,0.975864,0.98763,0.992972],
        'BPNN' : [0,0.34567,0.57782,0.72763,0.80645,0.83754,0.87084,0.88845,0.90998,0.911783,0.925084,0.94208,0.95534],
        'Boosting' : [0,0.42065,0.60092,0.77934,0.83084,0.87753,0.90093,0.91032,0.919845,0.930845,0.9464,0.95545,0.97045],
        'SM_NEEDLE' : [0,0.49565,0.70045,0.85906,0.90304,0.93234,0.94564,0.951343,0.962643,0.96432,0.964586,0.979535,0.979633]
    }




    # 绘制各方法曲线
    #colors = plt.cm.Set2(np.linspace(0, 1, len(methods)))
    colors = ["#014382","#C9631B","#FDC101","#55A868"]
    markstyle = ['s', 'o', '^', 'd']



    with plt.style.context(['science', 'bright', 'no-latex']):
        fig, ax = plt.subplots(figsize=(13, 8))
        for i, (name, y) in enumerate(methods.items()):
            plt.plot(x, y, color=colors[i], linewidth=3.5, label=name, marker=markstyle[i], markersize=9)

        # 选择关键点显示差值
        plt.xticks(fontproperties='Times New Roman', size=23)
        plt.yticks(fontproperties='Times New Roman', size=23)
        key_points = [1000]

        for x_point in key_points:
            # 找到最近的数据点索引
            idx = np.argmin(np.abs(x - x_point))

            # 绘制垂直线
            plt.axvline(x=x_point, color='gray', linestyle=':', alpha=0.5, linewidth=1)

            # 收集该点的所有值
            point_values = {}
            for name, y in methods.items():
                point_values[name] = y[idx]

            # 按值排序
            sorted_items = sorted(point_values.items(), key=lambda x: x[1], reverse=True)




        # 设置图表属性
        plt.xlabel('The Number of Training Round', fontsize=33 )
        plt.ylabel('Precision', fontsize=33 )
        #plt.title('Performance Comparison with Difference Analysis', fontsize=29, fontweight='bold')
        plt.legend(loc='upper left',
                   prop={'family': 'Times New Roman', 'size': 15})
        plt.grid(True, alpha=0.3)



        # 添加插图
        ax_inset = inset_axes(ax, width="50%", height="66%", bbox_to_anchor=(.6, .006, .7, .6),
                              bbox_transform=ax.transAxes, loc='upper left')

        for i, (name, y) in enumerate(methods.items()):
            ax_inset.plot(x, y, color=colors[i], linewidth=3, label=name, marker=markstyle[i], markersize=7)




        ax_inset.set_xlim(1450,2050)
        ax_inset.set_ylim(0.9, 1)
        plt.grid(True)
        mark_inset(ax, ax_inset, loc1=4, loc2=2, fc="none", ec='k', lw=0.7)  # 1 (右上) 2 (左上) 3(左下) 4(右下)
        ax_inset.tick_params(axis='both', which='major', labelsize=23)  # 设置刻度标签的字体大小

        #plt.savefig('C:/Users/23945/Desktop/result/fig4_Precision.png')
        plt.tight_layout()
        plt.show()


def FNR_analysis():

    # 创建数据
    cost_factors = np.arange(0, 2000, 166)

    x = cost_factors



    #FNR
    methods = {
        "ErMine": [1, 0.78081, 0.40095, 0.15982, 0.10752, 0.085682, 0.066011, 0.05029, 0.039776, 0.025690843, 0.016682, 0.011763, 0.005529093],
        "BPNN": [1, 0.89245, 0.60098, 0.25763, 0.152987, 0.139154, 0.11009, 0.09829, 0.09071, 0.08453, 0.080532,0.076208, 0.06943],
        "Boosting": [1, 0.83506, 0.542456, 0.21463, 0.120453, 0.11023, 0.09964, 0.08759, 0.08087, 0.074892, 0.063512,0.059452, 0.04932],
        "SM_NEEDLE": [1, 0.76132, 0.38543, 0.13732, 0.10764, 0.0892983, 0.063099, 0.059631, 0.0408921, 0.0299981,0.0200872, 0.016452, 0.01093]
    }



    # 绘制各方法曲线
    #colors = plt.cm.Set2(np.linspace(0, 1, len(methods)))
    colors = ["#014382","#C9631B","#FDC101","#55A868"]
    markstyle = ['s', 'o', '^', 'd']



    with plt.style.context(['science', 'bright', 'no-latex']):
        plt.rcParams['text.usetex'] = False  # 确保不启用LaTeX
        plt.rcParams['axes.unicode_minus'] = False  # 避免负号显示问题
        fig, ax = plt.subplots(figsize=(13, 8))
        for i, (name, y) in enumerate(methods.items()):
            plt.plot(x, y, color=colors[i], linewidth=3.5, label=name, marker=markstyle[i], markersize=9)

        # 选择关键点显示差值
        plt.xticks(fontproperties='Times New Roman', size=23)
        plt.yticks(fontproperties='Times New Roman', size=23)
        key_points = [1000]

        for x_point in key_points:
            # 找到最近的数据点索引
            idx = np.argmin(np.abs(x - x_point))

            # 绘制垂直线
            plt.axvline(x=x_point, color='gray', linestyle=':', alpha=0.5, linewidth=1)

            # 收集该点的所有值
            point_values = {}
            for name, y in methods.items():
                point_values[name] = y[idx]

            # 按值排序
            sorted_items = sorted(point_values.items(), key=lambda x: x[1], reverse=True)

            # 计算与最佳方法的差值
            best_method, best_value = sorted_items[0]



        # 设置图表属性
        plt.xlabel('The Number of Training Round', fontsize=33)
        plt.ylabel('FNR', fontsize=33)
        #plt.title('Performance Comparison with Difference Analysis', fontsize=29, fontweight='bold')
        #plt.legend(loc='lower left', fontsize=13)
        plt.legend(loc='lower left',
                   prop={'family': 'Times New Roman', 'size': 15})
        plt.grid(True, alpha=0.3)



        # 添加插图
        ax_inset = inset_axes(ax, width="50%", height="66%", bbox_to_anchor=(.6, .3, .7, .6),
                              bbox_transform=ax.transAxes, loc='upper left')


        for i, (name, y) in enumerate(methods.items()):
            ax_inset.plot(x, y, color=colors[i], linewidth=3, label=name, marker=markstyle[i], markersize=7)



        ax_inset.set_xlim(1450,2050)
        ax_inset.set_ylim(0, 0.12)

        plt.grid(True)
        mark_inset(ax, ax_inset, loc1=4, loc2=3, fc="none", ec='k', lw=0.7)  # 1 (右上) 2 (左上) 3(左下) 4(右下)
        ax_inset.tick_params(axis='both', which='major', labelsize=23)  # 设置刻度标签的字体大小
        # for i in range(4):
        #     # 插值
        #     f = interp1d(x, y[i], kind='linear', fill_value="extrapolate")
        #     x_new = np.linspace(0.1, 0.55, 15)
        #     y_new = f(x_new)
        #
        #     ax_inset.plot(x_new, y_new, label=label_name[i], linestyle='-',
        #                   color=color_line[i], marker=markstyle[i], linewidth=2.5,
        #                   markersize=7)

        plt.savefig('C:/Users/23945/Desktop/result/fig4_FNR.png')
        #plt.tight_layout()
        plt.show()



if __name__ == '__main__':
    Precision_analysis()
    #Accuracy_analysis()
    #FNR_analysis()