import matplotlib.pyplot as plt
import matplotlib
import csv
import os
import numpy as np
import statistics

matplotlib.rcParams['font.family'] = 'serif'
matplotlib.rcParams['font.size'] = 17
matplotlib.rcParams['font.serif'] = ['Times New Roman']

# Methods and colors (same as plot_results.py)
methods = [
    ('Honest',      'honest_fork_rate',      '#333333', '--', 's', 'Honest (Baseline)'),
    ('SM1',         'sm1_fork_rate',          '#e41a1c', '-',  'o', 'SM1 (No Defense)'),
    ('NonParam',    'nonparam_fork_rate',     '#377eb8', '-',  '^', 'Non-Parametric'),
    ('ForkDec',     'forkdec_fork_rate',      '#4daf4a', '-',  'v', 'ForkDec'),
    ('LA',          'la_fork_rate',           '#984ea3', '-',  '<', 'LA Defense'),
    ('Efficient',   'efficient_fork_rate',    '#a65628', '-',  '>', 'Efficient (RF)'),
    ('SeMi',        'semi_fork_rate',         '#f781bf', '-',  'p', 'SeMi_Detector (MLP)'),
    ('ErMine',      'ermine_fork_rate',       '#ff7f00', '-',  'D', 'ErMine (Ours)'),
]

# Vertical background zone definitions (alpha ranges → colors)
ZONES_ALPHA = [
    (0.23, 0.30, '#E8F5E9'),   # light green
    (0.30, 0.40, '#FFF8E1'),   # light yellow
    (0.40, 0.47, '#FFEBEE'),   # light pink
]


def draw_background_zones(ax, beta_val):
    for a_start, a_end, color in ZONES_ALPHA:
        r_start = 1.0 - a_end - beta_val
        r_end = 1.0 - a_start - beta_val
        ax.axvspan(r_start, r_end, facecolor=color, edgecolor='none', alpha=0.50, zorder=0)


def load_data(beta_str):
    csv_path = os.path.join(os.path.dirname(__file__), '..', '..', 'Result',
                            f'comprehensive_results_beta{beta_str}.csv')
    if not os.path.exists(csv_path):
        print(f"ERROR: {csv_path} not found.")
        return None
    alphas = []
    data = {m[1]: [] for m in methods}
    with open(csv_path, 'r') as f:
        for row in csv.DictReader(f):
            alphas.append(float(row['alpha']))
            for _, col, _, _, _, _ in methods:
                val = row.get(col, 'nan')
                data[col].append(float(val) if val and val != 'nan' else float('nan'))
    return alphas, data


def make_figure(beta_str):
    alphas, data = load_data(beta_str)
    if alphas is None:
        return
    beta_val = float(beta_str)

    fig, ax = plt.subplots(figsize=(12, 8))

    # Convert alpha → r = 1 - α - β
    r_vals = [1.0 - a - beta_val for a in alphas]

    # Background zones (converted from alpha to r space)
    draw_background_zones(ax, beta_val)

    # Plot each method
    for name, col, color, style, marker, label in methods:
        vals = data[col]
        valid_x = [r for r, v in zip(r_vals, vals) if v == v]
        valid_y = [v for v in vals if v == v]
        if len(valid_x) > 1:
            ax.plot(valid_x, valid_y, color=color, linestyle=style,
                    marker=marker, markersize=8, linewidth=2, label=label)

    ax.set_xlabel(r'$\gamma$', fontsize=22)
    ax.set_ylabel('Attacker Fork Success Rate', fontsize=22)
    ax.set_title(f'Fork Success Rate  ($\\beta$={beta_str})',
                 fontsize=18, fontweight='bold', pad=12)
    ax.grid(True, alpha=0.25, zorder=5)
    r_lo, r_hi = min(r_vals), max(r_vals)
    ax.set_xlim(r_lo - 0.01, r_hi + 0.01)
    ax.tick_params(labelsize=15)

    # Auto y-lim
    all_y = []
    for _, col, _, _, _, _ in methods:
        all_y.extend([v for v in data[col] if v == v])
    if all_y:
        lo, hi = min(all_y), max(all_y)
        margin = max((hi - lo) * 0.15, 0.02)
        ax.set_ylim(max(0, lo - margin), hi + margin)

    # Legend
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, labels, loc='upper center', fontsize=13, frameon=True, ncol=4)

    fig.tight_layout()
    out_path = os.path.join(os.path.dirname(__file__), '..', f'fig_fork_rate_beta{beta_str}.pdf')
    fig.savefig(out_path, format='pdf', bbox_inches='tight')
    print(f"Saved: fig_fork_rate_beta{beta_str}.pdf")
    plt.close(fig)


# Generate for all beta values
for beta in ['0.3', '0.35', '0.4']:
    make_figure(beta)

print("All fork rate figures generated.")
