import matplotlib.pyplot as plt
import matplotlib
import csv
import os

matplotlib.rcParams['font.family'] = 'serif'
matplotlib.rcParams['font.size'] = 17
matplotlib.rcParams['font.serif'] = ['Times New Roman']

CSV_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'Result',
                        'comprehensive_results_beta0.3_from_img.csv')

colors = {
    'Honest':      '#333333',
    'SM1':         '#e41a1c',
    'Theoretical': '#e41a1c',
    'ErMine':      '#ff7f00',
    'NonParam':    '#377eb8',
    'ForkDec':     '#4daf4a',
    'LA':          '#984ea3',
    'Efficient':   '#a65628',
    'SeMi':        '#f781bf',
}
styles = {
    'Honest':      '--',
    'SM1':         '-',
    'Theoretical': ':',
    'ErMine':      '-',
    'NonParam':    '-',
    'ForkDec':     '-',
    'LA':          '-',
    'Efficient':   '-',
    'SeMi':        '-',
}
markers = {
    'Honest':      's',
    'SM1':         'o',
    'Theoretical': '',
    'ErMine':      'D',
    'NonParam':    '^',
    'ForkDec':     'v',
    'LA':          '<',
    'Efficient':   '>',
    'SeMi':        'p',
}

alphas = []
honest_att, sm1_att, theo_att = [], [], []
ermine_att, ermine_agent, nonparam_att, forkdec_att = [], [], [], []
la_att, efficient_att, semi_att = [], [], []
honest_other, sm1_other, ermine_other = [], [], []
nonparam_other, forkdec_other, la_other = [], [], []
efficient_other, semi_other = [], []

with open(CSV_PATH, 'r') as f:
    for row in csv.DictReader(f):
        alphas.append(float(row['alpha']))
        honest_att.append(float(row['honest_att']))
        sm1_att.append(float(row['sm1_att']))
        theo_att.append(float(row['theo_att']))
        ermine_att.append(float(row['ermine_att']))
        ermine_agent.append(float(row['ermine_agent']))
        nonparam_att.append(float(row['nonparam_att']))
        forkdec_att.append(float(row['forkdec_att']))
        la_att.append(float(row['la_att']))
        efficient_att.append(float(row['efficient_att']))
        semi_att.append(float(row['semi_att']))
        honest_other.append(float(row['honest_other']))
        sm1_other.append(float(row['sm1_other']))
        ermine_other.append(float(row['ermine_other']))
        nonparam_other.append(float(row['nonparam_other']))
        forkdec_other.append(float(row['forkdec_other']))
        la_other.append(float(row['la_other']))
        efficient_other.append(float(row['efficient_other']))
        semi_other.append(float(row['semi_other']))

d = {
    'alphas': alphas, 'honest_att': honest_att, 'sm1_att': sm1_att,
    'theo_att': theo_att, 'ermine_att': ermine_att, 'ermine_agent': ermine_agent,
    'nonparam_att': nonparam_att, 'forkdec_att': forkdec_att,
    'la_att': la_att, 'efficient_att': efficient_att, 'semi_att': semi_att,
    'honest_other': honest_other, 'sm1_other': sm1_other,
    'ermine_other': ermine_other, 'nonparam_other': nonparam_other,
    'forkdec_other': forkdec_other, 'la_other': la_other,
    'efficient_other': efficient_other, 'semi_other': semi_other,
}

a = alphas


def plot_all_lines(ax, att_data=False, other_data=False):
    lines = []
    lines.extend(ax.plot(a, d['honest_att'] if not other_data else d['honest_other'],
               color=colors['Honest'], linestyle=styles['Honest'],
               marker=markers['Honest'], markersize=7, linewidth=2, label='Honest (Baseline)'))
    lines.extend(ax.plot(a, d['sm1_att'] if not other_data else d['sm1_other'],
               color=colors['SM1'], linestyle=styles['SM1'],
               marker=markers['SM1'], markersize=7, linewidth=2, label='SM1 (No Defense)'))
    lines.extend(ax.plot(a, d['nonparam_att'] if not other_data else d['nonparam_other'],
               color=colors['NonParam'], linestyle=styles['NonParam'],
               marker=markers['NonParam'], markersize=7, linewidth=2, label='Non-Parametric'))
    lines.extend(ax.plot(a, d['forkdec_att'] if not other_data else d['forkdec_other'],
               color=colors['ForkDec'], linestyle=styles['ForkDec'],
               marker=markers['ForkDec'], markersize=7, linewidth=2, label='ForkDec'))
    lines.extend(ax.plot(a, d['la_att'] if not other_data else d['la_other'],
               color=colors['LA'], linestyle=styles['LA'],
               marker=markers['LA'], markersize=7, linewidth=2, label='LA Defense'))
    lines.extend(ax.plot(a, d['efficient_att'] if not other_data else d['efficient_other'],
               color=colors['Efficient'], linestyle=styles['Efficient'],
               marker=markers['Efficient'], markersize=7, linewidth=2, label='Efficient (RF)'))
    lines.extend(ax.plot(a, d['semi_att'] if not other_data else d['semi_other'],
               color=colors['SeMi'], linestyle=styles['SeMi'],
               marker=markers['SeMi'], markersize=7, linewidth=2, label='SeMi_Detector (MLP)'))
    lines.extend(ax.plot(a, d['ermine_att'] if not other_data else d['ermine_other'],
                         color=colors['ErMine'], linestyle=styles['ErMine'],
                         marker=markers['ErMine'], markersize=7, linewidth=2, label='ErMine (Ours)'))
    return lines


fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(22, 6))

# ---- Subplot 1: Selfish Miner (Attacker) Revenue ----
plot_all_lines(ax1, att_data=True)
ax1.plot(a, a, color='gray', linestyle='--', linewidth=1, alpha=0.5)
ax1.set_xlabel(r'$\gamma$', fontsize=17)
ax1.set_ylabel('$R_s^{rela}$', fontsize=17)
ax1.set_title('(a) Selfish Miner Revenue', fontsize=17, fontweight='bold', y=-0.3)
ax1.grid(True, alpha=0.3)
ax1.set_xlim(0.23, 0.47)

# ---- Subplot 2: Honest Miner Revenue ----
plot_all_lines(ax2, other_data=True)
ax2.set_xlabel('γ', fontsize=17)
ax2.set_ylabel('$R_h^{rela}$', fontsize=17)
ax2.set_title('(b) Honest Miner Revenue', fontsize=17, fontweight='bold', y=-0.3)
ax2.grid(True, alpha=0.3)
ax2.set_xlim(0.23, 0.47)

# ---- Subplot 3: Rational Miner Revenue ----
ax3.plot(a, a, color=colors['Honest'], linestyle=styles['Honest'],
         marker=markers['Honest'], markersize=7, linewidth=2, label='Honest (Baseline)')
ax3.plot(a, d['sm1_att'], color=colors['SM1'], linestyle=styles['SM1'],
         marker=markers['SM1'], markersize=7, linewidth=2, label='SM1 (No Defense)')
ax3.plot(a, d['ermine_agent'], color=colors['ErMine'], linestyle=styles['ErMine'],
         marker=markers['ErMine'], markersize=7, linewidth=2, label='ErMine (Ours)')
ax3.plot(a, d['nonparam_att'], color=colors['NonParam'], linestyle=styles['NonParam'],
         marker=markers['NonParam'], markersize=7, linewidth=2, label='Non-Parametric')
ax3.plot(a, d['forkdec_att'], color=colors['ForkDec'], linestyle=styles['ForkDec'],
         marker=markers['ForkDec'], markersize=7, linewidth=2, label='ForkDec')
ax3.plot(a, d['la_att'], color=colors['LA'], linestyle=styles['LA'],
         marker=markers['LA'], markersize=7, linewidth=2, label='LA Defense')
ax3.plot(a, d['efficient_att'], color=colors['Efficient'], linestyle=styles['Efficient'],
         marker=markers['Efficient'], markersize=7, linewidth=2, label='Efficient (RF)')
ax3.plot(a, d['semi_att'], color=colors['SeMi'], linestyle=styles['SeMi'],
         marker=markers['SeMi'], markersize=7, linewidth=2, label='SeMi_Detector (MLP)')
ax3.set_xlabel('γ', fontsize=17)
ax3.set_ylabel('$R_r^{rela}$', fontsize=17)
ax3.set_title('(c) Rational Miner Revenue', fontsize=17, fontweight='bold', y=-0.3)
ax3.grid(True, alpha=0.3)
ax3.set_xlim(0.23, 0.47)

# ---- Shared legend ----
handles, labels = ax1.get_legend_handles_labels()
seen = set()
unique_handles, unique_labels = [], []
for h, l in zip(handles, labels):
    if l not in seen and not l.startswith('_'):
        seen.add(l)
        unique_handles.append(h)
        unique_labels.append(l)

fig.legend(unique_handles, unique_labels, loc='upper center', ncol=9,
           fontsize=13, frameon=True, bbox_to_anchor=(0.5, 1.02))

fig.tight_layout(rect=[0, 0, 1, 0.92])
out_path = os.path.join(os.path.dirname(__file__), '..', 'fig_combined_beta0.3_from_img.png')
fig.savefig(out_path, dpi=150, bbox_inches='tight')
print(f"Saved: {out_path}")
plt.close(fig)
