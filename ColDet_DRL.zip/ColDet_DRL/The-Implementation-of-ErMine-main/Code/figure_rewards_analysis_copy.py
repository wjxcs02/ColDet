
import numpy as np
import scienceplots
import matplotlib.pyplot as plt
from matplotlib import patheffects
from matplotlib.ticker import MaxNLocator

import cmaps



def att_and_honest_rewards_plot_030():

    alphas = np.arange(0.1, 0.45, 0.05)



# #b=0.30
#     # beta=0.55时，attacker的收益
    att_rewards_DQRN_beta030 = [0.198056,0.2131854545,0.23271890909,0.245480127273,0.268090909,0.302427273,0.325318182]  # 采用 PBMN时
    att_rewards_SM_beta030 = [0.1756, 0.181854545, 0.1971890909, 0.220127273, 0.238090909, 0.272427273,0.295318182]  # 采用 PBMN时
    att_rewards_DQN_beta030 = [0.18,0.19,0.2092,0.2312,0.2478,0.2809,0.319074]  # 无 PBMN时，attacker 理论收益
    att_rewards_honest_beta030 = [0.1878056, 0.20831854545, 0.238271890909, 0.2305480127273, 0.268028090909, 0.29082427273,0.318225318182]  # 采用 PBMN时

#     # beta=0.55时，other honest 的收益
    other_rewards_SM_beta030 = [0.4563372727,0.42070672727,0.371574,0.3172845455,0.24627273,0.17845455,0.1492509091]# 采用 PBMN时
    other_rewards_DQN_beta030 = [0.443372727, 0.4070672727, 0.3574, 0.292845455, 0.224627273, 0.157845455,0.12092509091]  # 采用 PBMN时
    other_rewards_DQRN_beta030 = [0.43,0.3856,0.33901,0.2843,0.2159,0.1497,0.109]  # 无 PBMN时，attacker 理论收益
    other_rewards_honest_beta030 = [0.425, 0.37956, 0.3150901, 0.277843, 0.209159, 0.1359497, 0.099109]  # 无 PBMN时，attacker 理论收益




    with plt.style.context(['science', 'bright', 'no-latex']):

        fig, ax = plt.subplots(figsize=(12, 8))

        ax.plot(alphas, att_rewards_DQRN_beta030, color='#55A766', linestyle='-', linewidth=3, marker='p', markevery=1,markersize=16, label="$R_h^{rela}$ (ErMine_DQRN)")
        ax.plot(alphas, att_rewards_DQN_beta030, color='#014382', linestyle='-.', linewidth=3, marker='s', markevery=1, markersize=16,label="$R_h^{rela}$ (ErMine_DQN)")
        ax.plot(alphas, att_rewards_SM_beta030,  color='#876EB7', linestyle='--', linewidth=3, marker='d', markevery=1, markersize=16,label="$R_h^{rela}$ (SM1)")
        ax.plot(alphas, att_rewards_honest_beta030, color='#708090', linestyle=':', linewidth=3, marker='>',markevery=1, markersize=16, label="$R_h^{rela}$ (Honest)")


        ax.plot(alphas, other_rewards_DQRN_beta030, color='#B8272C', linestyle='-', linewidth=3, marker='^', markevery=1, markersize=16,label="$R_s^{rela}$ (ErMine_DRQN)")
        ax.plot(alphas, other_rewards_DQN_beta030, color='#C9631B',  linestyle='--', linewidth=3, marker='o', markevery=1, markersize=16,label="$R_s^{rela}$ (ErMine_DRN)")
        ax.plot(alphas, other_rewards_SM_beta030, color='#FDC101', linestyle='-.', linewidth=3, marker='X', markevery=1,markersize=16, label="$R_s^{rela}$ (SM1)")
        ax.plot(alphas, other_rewards_honest_beta030, color='#E377C2', linestyle=':', linewidth=3, marker='h', markevery=1, markersize=16, label="$R_s^{rela}$ (Honest)")
        # 控制显示的坐标刻度的个数
        ax.xaxis.set_major_locator(MaxNLocator(6))

        plt.ylim(0.0, 0.7)
        # plt.xlim(0, 0.5)
        plt.xlabel(r"β", fontdict={'family': 'Times New Roman', 'size': 35})
        plt.ylabel("relative reward", fontdict={'family': 'Times New Roman', 'size': 35})


        # 暂存前两个图例
        #plt.legend(ncol=3)
        legend1 = plt.legend(loc='upper left', handlelength=2,ncol=2,
                             prop={'family': 'Times New Roman', 'size': 18})
        plt.gca().add_artist(legend1)

        plt.xticks(fontproperties='Times New Roman', size=33)
        plt.yticks(fontproperties='Times New Roman', size=33)

        plt.tight_layout()
        #plt.savefig('C:/Users/23945/Desktop/result/fig2_r030.png')
        plt.show()




def att_and_honest_rewards_plot_035():

    alphas = np.arange(0.1, 0.45, 0.05)






# #b=0.35
    # beta=0.35时，attacker的收益
    att_rewards_honest_beta035 = [0.1120972727, 0.13997545455, 0.16506872727, 0.2026581818, 0.2590036364, 0.2890018182,0.3249829]
    att_rewards_DQRN_beta035 = [0.120972727, 0.147545455, 0.1706872727, 0.214581818, 0.250036364, 0.2790018182, 0.309829]
    att_rewards_SM_beta035 = [0.090972727,0.107545455,0.1406872727,0.174581818,0.210036364,0.250018182,0.279]  # 采用 PBMN时
    att_rewards_DQN_beta035 = [0.10, 0.1198, 0.1529956, 0.192, 0.22993, 0.2609, 0.2974]  # 无 PBMN时，attacker 理论收益

    # beta=0.035时，other honest 的收益
    other_rewards_honest_beta035 = [0.3804454545, 0.3094472727, 0.240145455, 0.1923827273, 0.11017536364, 0.0805199690909,0.040656]
    other_rewards_DQRN_beta035 = [0.384454545, 0.314472727, 0.249145455, 0.1993827273, 0.1297536364, 0.09199690909,0.05656]
    other_rewards_DQN_beta035 = [0.404454545,0.334472727,0.269145455,0.2193827273,0.1497536364,0.10999690909,0.07656]  # 采用 PBMN时
    other_rewards_SM_beta035 = [0.43, 0.353, 0.2936, 0.2359, 0.1699, 0.136595, 0.09]  # 无 PBMN时，attacker 理论收益





    with plt.style.context(['science', 'bright', 'no-latex']):

        fig, ax = plt.subplots(figsize=(12, 8))

        ax.plot(alphas, att_rewards_DQRN_beta035, color='#55A766', linestyle='-', linewidth=3, marker='p', markevery=1,markersize=16, label="$R_h^{rela}$ (ErMine_DQRN)")
        ax.plot(alphas, att_rewards_DQN_beta035, color='#014382', linestyle='-.', linewidth=3, marker='s', markevery=1, markersize=16,label="$R_h^{rela}$ (ErMine_DQN)")
        ax.plot(alphas, att_rewards_SM_beta035,  color='#876EB7', linestyle='--', linewidth=3, marker='d', markevery=1, markersize=16,label="$R_h^{rela}$ (SM1)")
        ax.plot(alphas, att_rewards_honest_beta035, color='#708090', linestyle=':', linewidth=3, marker='>',markevery=1, markersize=16, label="$R_h^{rela}$ (Honest)")


        ax.plot(alphas, other_rewards_DQRN_beta035, color='#B8272C', linestyle='-', linewidth=3, marker='^', markevery=1, markersize=16,label="$R_s^{rela}$ (ErMine_DRQN)")
        ax.plot(alphas, other_rewards_DQN_beta035, color='#C9631B',  linestyle='--', linewidth=3, marker='o', markevery=1, markersize=16,label="$R_s^{rela}$ (ErMine_DRN)")
        ax.plot(alphas, other_rewards_SM_beta035, color='#FDC101', linestyle='-.', linewidth=3, marker='X', markevery=1,markersize=16, label="$R_s^{rela}$ (SM1)")
        ax.plot(alphas, other_rewards_honest_beta035, color='#E377C2', linestyle=':', linewidth=3, marker='h', markevery=1, markersize=16, label="$R_s^{rela}$ (Honest)")
        # 控制显示的坐标刻度的个数
        ax.xaxis.set_major_locator(MaxNLocator(6))

        plt.ylim(0.0, 0.7)
        # plt.xlim(0, 0.5)
        plt.xlabel(r"β", fontdict={'family': 'Times New Roman', 'size': 35})
        plt.ylabel("relative reward", fontdict={'family': 'Times New Roman', 'size': 35})


        # 暂存前两个图例
        #plt.legend(ncol=3)
        legend1 = plt.legend(loc='upper left', handlelength=2,ncol=2,
                             prop={'family': 'Times New Roman', 'size': 18})
        plt.gca().add_artist(legend1)

        plt.xticks(fontproperties='Times New Roman', size=33)
        plt.yticks(fontproperties='Times New Roman', size=33)

        plt.tight_layout()
        #plt.savefig('C:/Users/23945/Desktop/result/fig2_r035.png')
        plt.show()




def att_and_honest_rewards_plot_040():

    alphas = np.arange(0.1, 0.45, 0.05)



# #b=0.30
#     # beta=0.55时，attacker的收益
#     att_rewards_POMDP_beta055 = [0.1756,0.181854545,0.1971890909,0.220127273,0.238090909,0.272427273,0.295318182]  # 采用 PBMN时
#     att_rewards_honest_beta055 = [0.18,0.19,0.2092,0.2312,0.2478,0.2809,0.319074]  # 无 PBMN时，attacker 理论收益
#
#     # beta=0.55时，other honest 的收益
#     other_rewards_POMDP_beta055 = [0.443372727,0.4070672727,0.3574,0.292845455,0.224627273,0.157845455,0.1092509091]# 采用 PBMN时
#     other_rewards_honest_beta055 = [0.43,0.3856,0.33901,0.2843,0.2159,0.1497,0.109]  # 无 PBMN时，attacker 理论收益


# #b=0.35
#     # beta=0.60时，attacker的收益
#     att_rewards_POMDP_beta060 = [0.090972727,0.107545455,0.1406872727,0.174581818,0.210036364,0.250018182,0.279]  # 采用 PBMN时
#     att_rewards_honest_beta060 = [0.10, 0.1198, 0.1529956, 0.192, 0.22993, 0.2609, 0.2974]  # 无 PBMN时，attacker 理论收益
#
#     # beta=0.60时，other honest 的收益
#     other_rewards_POMDP_beta060 = [0.404454545,0.334472727,0.269145455,0.2193827273,0.1497536364,0.10999690909,0.07656]  # 采用 PBMN时
#     other_rewards_honest_beta060 = [0.43, 0.353, 0.2936, 0.2359, 0.1699, 0.136595, 0.09]  # 无 PBMN时，attacker 理论收益

# b=0.40

    att_rewards_DQRN_beta040 = [ 0.076863636, 0.1148854545, 0.1843, 0.2518409091, 0.3221181818, 0.36765787,0.39590987]
    att_rewards_DQN_beta040 = [0.053, 0.0925, 0.162, 0.225, 0.2999, 0.3467,0.3798]
    att_rewards_SM_beta040 = [0.040409091, 0.076863636, 0.128854545, 0.2043, 0.278409091, 0.331181818, 0.36765787]
    att_rewards_honest_beta040 = [0.070409091, 0.106863636, 0.188854545, 0.2443, 0.3318409091, 0.351181818, 0.39765787]



    other_rewards_DQN_beta040 = [0.383890909,0.315745455,0.251872727,0.176409091,0.132081818,0.0856543,0.05003]
    other_rewards_DQRN_beta040 = [0.353890909, 0.295745455, 0.231872727, 0.156409091, 0.102081818, 0.0756543, 0.02003]
    other_rewards_SM_beta040 = [0.403890909, 0.355745455, 0.2671872727, 0.2106409091, 0.1482081818, 0.10756543, 0.077003]
    other_rewards_honest_beta040 = [0.34097, 0.2835, 0.2215, 0.15909, 0.110501, 0.079795, 0.023905]



    with plt.style.context(['science', 'bright', 'no-latex']):

        fig, ax = plt.subplots(figsize=(12, 8))

        ax.plot(alphas, att_rewards_DQRN_beta040, color='#55A766', linestyle='-', linewidth=3, marker='p', markevery=1,markersize=16, label="$R_h^{rela}$ (ErMine_DQRN)")
        ax.plot(alphas, att_rewards_DQN_beta040, color='#014382', linestyle='-.', linewidth=3, marker='s', markevery=1, markersize=16,label="$R_h^{rela}$ (ErMine_DQN)")
        ax.plot(alphas, att_rewards_SM_beta040,  color='#876EB7', linestyle='--', linewidth=3, marker='d', markevery=1, markersize=16,label="$R_h^{rela}$ (SM1)")
        ax.plot(alphas, att_rewards_honest_beta040, color='#708090', linestyle=':', linewidth=3, marker='>',markevery=1, markersize=16, label="$R_h^{rela}$ (Honest)")


        ax.plot(alphas, other_rewards_DQRN_beta040, color='#B8272C', linestyle='-', linewidth=3, marker='^', markevery=1, markersize=16,label="$R_s^{rela}$ (ErMine_DRQN)")
        ax.plot(alphas, other_rewards_DQN_beta040, color='#C9631B',  linestyle='--', linewidth=3, marker='o', markevery=1, markersize=16,label="$R_s^{rela}$ (ErMine_DRN)")
        ax.plot(alphas, other_rewards_SM_beta040, color='#FDC101', linestyle='-.', linewidth=3, marker='X', markevery=1,markersize=16, label="$R_s^{rela}$ (SM1)")
        ax.plot(alphas, other_rewards_honest_beta040, color='#E377C2', linestyle=':', linewidth=3, marker='h', markevery=1, markersize=16, label="$R_s^{rela}$ (Honest)")
        # 控制显示的坐标刻度的个数
        ax.xaxis.set_major_locator(MaxNLocator(6))

        plt.ylim(0.0, 0.7)
        # plt.xlim(0, 0.5)
        plt.xlabel(r"β", fontdict={'family': 'Times New Roman', 'size': 35})
        plt.ylabel("relative reward", fontdict={'family': 'Times New Roman', 'size': 35})


        # 暂存前两个图例
        #plt.legend(ncol=3)
        legend1 = plt.legend(loc='upper left', handlelength=2,ncol=2,
                             prop={'family': 'Times New Roman', 'size': 18})
        plt.gca().add_artist(legend1)

        plt.xticks(fontproperties='Times New Roman', size=33)
        plt.yticks(fontproperties='Times New Roman', size=33)

        plt.tight_layout()
        #plt.savefig('C:/Users/23945/Desktop/result/fig2_r040.png')
        plt.show()







if __name__ == '__main__':

    att_and_honest_rewards_plot_035()

