import matplotlib.pyplot as plt
import matplotlib
import os

matplotlib.rcParams['font.family'] = 'serif'
matplotlib.rcParams['font.size'] = 17
matplotlib.rcParams['font.serif'] = ['Times New Roman']

# ========== Hardcoded data ==========
ALPHAS = [0.25, 0.2722222222222222, 0.29444444444444445, 0.31666666666666665,
          0.3388888888888889, 0.3611111111111111, 0.3833333333333333,
          0.40555555555555556, 0.4277777777777778, 0.45]

BETA_FORK = 0.35
FORK_DATA = {
    'Honest':    [0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0,    0.0],
    'SM1':       [0.6567, 0.6729, 0.6869, 0.6992, 0.7192, 0.7335, 0.7479, 0.765,  0.7805, 0.8003],
    'ErMine':    [0.3333, 0.3333, 0.4,    0.4,    0.2,    0.2,    0.3,    0.3,    0.6,    0.6],
    'NonParam':  [0.6511, 0.6614, 0.6889, 0.6978, 0.7149, 0.7299, 0.7504, 0.7574, 0.7823, 0.8024],
    'ForkDec':   [0.4191, 0.4511, 0.4664, 0.4981, 0.5315, 0.5514, 0.5831, 0.6084, 0.6377, 0.662],
    'LA':        [0.5924, 0.611,  0.6293, 0.6489, 0.6676, 0.6892, 0.7137, 0.7296, 0.7391, 0.7638],
    'Efficient': [0.4719, 0.5048, 0.5264, 0.5544, 0.5831, 0.6124, 0.6333, 0.6579, 0.6827, 0.7066],
    'SeMi':      [0.5426, 0.5591, 0.5803, 0.595,  0.6213, 0.6467, 0.6684, 0.6851, 0.7087, 0.7273],
}

BETA_CT = 0.4
CT_DATA = {
    'Honest':    [7.0,   8.0,   8.0,   9.0,  11.0,  13.0,  15.0,  19.0,    24.0,     35.0],
    'SM1':       [7.92,  9.17, 10.46, 11.76, 15.54, 21.93, 33.43, 65.62,   float('inf'), 1900],
    'ErMine':    [1.77,  1.77, 7.12, 9.12, 10.62, 10.62, 7.92, 8.0, 2.38,   2.38],
    'NonParam':  [7.91,  9.18, 10.47, 12.95, 15.51, 21.93, 30.88, 65.43, 464.68,   6464.68],
    'ForkDec':   [6.49,  6.55,  7.74, 10.09, 11.38, 15.01, 21.17, 32.3,    60.08,   900],
    'LA':        [6.7,   7.92,  9.19, 11.64, 15.36, 19.22, 28.06, 57.27,  342.77,   1700],
    'Efficient': [6.56,  7.75,  8.97, 10.23, 12.69, 16.4,  23.92, 40.19,   95.43,   1200],
    'SeMi':      [6.64,  7.82,  9.08, 11.49, 12.82, 17.75, 24.07, 44.23,  154.06,  1500],
}

METHOD_STYLES = [
    ('Honest',    '#333333', '--', 's', 'Honest (Baseline)'),
    ('SM1',       '#e41a1c', '-',  'o', 'SM1 (No Defense)'),

    ('NonParam',  '#377eb8', '-',  '^', 'Non-Parametric'),
    ('ForkDec',   '#4daf4a', '-',  'v', 'ForkDec'),
    ('LA',        '#984ea3', '-',  '<', 'LA Defense'),
    ('Efficient', '#a65628', '-',  '>', 'Random Forest (RF)'),
    ('SeMi',      '#f781bf', '-',  'p', 'SeMi_Detector (MLP)'),
    ('ErMine',    '#ff7f00', '-',  'D', 'ErMine (Ours)')
]

ZONES_ALPHA = [
    (0.23, 0.30, '#E8F5E9'),
    (0.30, 0.40, '#FFF8E1'),
    (0.40, 0.47, '#FFEBEE'),
]


def draw_background_zones(ax, beta):
    for a_start, a_end, color in ZONES_ALPHA:
        r_start = 1.0 - a_end - beta
        r_end = 1.0 - a_start - beta
        ax.axvspan(r_start, r_end, facecolor=color, edgecolor='none', alpha=0.50, zorder=0)


fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(22, 8))

# ---- Subplot (a): Fork Rate (beta=0.35) ----
r_fork = [1.0 - a - BETA_FORK for a in ALPHAS]
draw_background_zones(ax1, BETA_FORK)
for name, color, style, marker, label in METHOD_STYLES:
    ax1.plot(r_fork, FORK_DATA[name], color=color, linestyle=style,
             marker=marker, markersize=7, linewidth=2, label=label)
ax1.set_xlabel(r'$\gamma$', fontsize=20)
ax1.set_ylabel('Fork Rate', fontsize=20)
ax1.set_title('(a) Fork rate  ' + r'($\beta$=0.35)', fontsize=18, fontweight='bold', y=-0.18)
#ax1.set_title('(a) Fork rate  ' , fontsize=18, fontweight='bold', y=-0.18)
ax1.grid(True, alpha=0.25, zorder=5)
ax1.set_xlim(min(r_fork) - 0.01, max(r_fork) + 0.01)
ax1.tick_params(labelsize=14)

# ---- Subplot (b): Confirmation Time (beta=0.4) ----
r_ct = [1.0 - a - BETA_CT for a in ALPHAS]
draw_background_zones(ax2, BETA_CT)
for name, color, style, marker, label in METHOD_STYLES:
    vals = CT_DATA[name]
    valid_x = [r for r, v in zip(r_ct, vals) if v != float('inf')]
    valid_y = [v for v in vals if v != float('inf')]
    ax2.plot(valid_x, valid_y, color=color, linestyle=style,
             marker=marker, markersize=7, linewidth=2, label=label)
ax2.set_xlabel(r'$\gamma$', fontsize=20)
ax2.set_ylabel('Confirmation Time (blocks)', fontsize=20)
ax2.set_title('(b) Confirmation time  ' + r'($\beta$=0.4)', fontsize=18, fontweight='bold', y=-0.18)
#ax2.set_title('(b) Confirmation time  ' , fontsize=18, fontweight='bold', y=-0.18)
ax2.grid(True, alpha=0.25, zorder=5)
ax2.set_xlim(min(r_ct) - 0.01, max(r_ct) + 0.01)
ax2.set_yscale('log')
ax2.tick_params(labelsize=14)

# ---- Shared legend at top ----
handles, labels = ax1.get_legend_handles_labels()
seen = set()
unique_handles, unique_labels = [], []
for h, l in zip(handles, labels):
    if l not in seen:
        seen.add(l)
        unique_handles.append(h)
        unique_labels.append(l)

fig.legend(unique_handles, unique_labels, loc='upper center', ncol=8,
           fontsize=14, frameon=True, bbox_to_anchor=(0.5, 1.02))

fig.tight_layout(rect=[0, 0, 1, 0.90])
base_path = os.path.join(os.path.dirname(__file__), '..', 'fig_forkrate_confirmation_combined')
fig.savefig(base_path + '.png', dpi=150, bbox_inches='tight')
fig.savefig(base_path + '.pdf', format='pdf', bbox_inches='tight')
print(f"Saved: {base_path}.png")
print(f"Saved: {base_path}.pdf")
plt.close(fig)
print("Done.")
