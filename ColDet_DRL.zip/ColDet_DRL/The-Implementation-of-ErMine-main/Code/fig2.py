import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import scienceplots
from matplotlib.font_manager import FontProperties

import statistics


# 准备热力图数据
beta_values = np.arange(0.1, 0.45, 0.05)
beta_values = np.round(beta_values, 2)


# b=0.30
# R_htela 数据矩阵
htela_matrix = np.array([
    [0.198056, 0.2131854545, 0.23271890909, 0.245480127273, 0.268090909, 0.302427273, 0.325318182],
    [0.1756, 0.181854545, 0.1971890909, 0.220127273, 0.238090909, 0.272427273, 0.3105318182],
    [0.18, 0.19, 0.2092, 0.2312, 0.2478, 0.2809, 0.3009074],
    [0.1878056, 0.20831854545, 0.238271890909, 0.2305480127273, 0.268028090909, 0.29082427273, 0.3008225318182]
])


# R_srela 数据矩阵
srela_matrix = np.array([
    [0.425, 0.37956, 0.3150901, 0.277843, 0.209159, 0.1359497, 0.099109],
    [0.43, 0.3856, 0.33901, 0.2843, 0.2159, 0.1497, 0.109],
    [0.443372727, 0.4070672727, 0.3574, 0.292845455, 0.224627273, 0.157845455, 0.12092509091],
    [0.4563372727, 0.42070672727, 0.371574, 0.3172845455, 0.24627273, 0.17845455, 0.1492509091]
])


# # b=0.35
# # R_htela 数据矩阵
# htela_matrix = np.array([
#     [0.1120972727, 0.13997545455, 0.16506872727, 0.2026581818, 0.2590036364, 0.2890018182, 0.3249829],
#     [0.120972727, 0.147545455, 0.1706872727, 0.214581818, 0.250036364, 0.2790018182, 0.309829],
#     [0.090972727, 0.107545455, 0.1406872727, 0.174581818, 0.210036364, 0.250018182, 0.279],
#     [0.10, 0.1198, 0.1529956, 0.192, 0.22993, 0.2609, 0.28074]
# ])
#
#
# # R_srela 数据矩阵
# srela_matrix = np.array([
#     [0.3804454545, 0.3094472727, 0.240145455, 0.1923827273, 0.11017536364, 0.0805199690909, 0.040656],
#     [0.384454545, 0.314472727, 0.249145455, 0.1993827273, 0.1297536364, 0.09199690909, 0.05656],
#     [0.404454545, 0.334472727, 0.269145455, 0.2193827273, 0.1497536364, 0.10999690909, 0.07656],
#     [0.43, 0.353, 0.2936, 0.2359, 0.1699, 0.136595, 0.09]
# ])


# # b=0.40
# # R_htela 数据矩阵
# htela_matrix = np.array([
#     [0.070409091, 0.106863636, 0.188854545, 0.2443, 0.3318409091, 0.351181818, 0.39765787],
#     [0.076863636, 0.1148854545, 0.1843, 0.2518409091, 0.3221181818, 0.36765787, 0.39590987],
#     [0.053, 0.0925, 0.162, 0.225, 0.2999, 0.3467, 0.3798],
#     [0.040409091, 0.076863636, 0.128854545, 0.2043, 0.278409091, 0.331181818, 0.36765787],
# ])
#
#
# # R_srela 数据矩阵
# srela_matrix = np.array([
#     [0.34097, 0.2835, 0.2215, 0.15909, 0.110501, 0.079795, 0.023905],
#     [0.353890909, 0.295745455, 0.231872727, 0.156409091, 0.102081818, 0.0756543, 0.02003],
#     [0.383890909, 0.315745455, 0.251872727, 0.176409091, 0.132081818, 0.0856543, 0.05003],
#     [0.403890909, 0.355745455, 0.2671872727, 0.2106409091, 0.1482081818, 0.10756543, 0.077003]
# ])


htela_matrix = htela_matrix.T
srela_matrix = srela_matrix.T

# 算法名称
algorithms = ['ErMine_DQRN', 'ErMine_DQN', 'SM1', 'Honest']

with plt.style.context(['science', 'bright', 'no-latex']):
    times_font = FontProperties(family="Times New Roman")

    fig, ax = plt.subplots(1, 1, figsize=(10, 7))

    im = sns.heatmap(srela_matrix.T, ax=ax, cmap='Blues', annot=True, fmt='.2f',
                     linewidths=1, linecolor='white', cbar_kws={'label': 'Score'}, annot_kws={"size": 16})
    cbar = ax.collections[0].colorbar
    cbar.ax.tick_params(labelsize=16)
    cbar.ax.set_ylabel(cbar.ax.get_ylabel(), fontsize=20)
    ax.set_title('$R_r^{rela}$ Metric Heatmap', fontsize=36, fontweight='bold', pad=12)
    ax.set_xlabel(r'$\gamma$', fontsize=33, fontweight='bold')
    ax.set_ylabel('relative reward', fontsize=33, fontweight='bold')
    ax.set_xticklabels(beta_values, rotation=0, fontsize=17)
    ax.set_yticklabels(algorithms, rotation=0, fontproperties=times_font, fontsize=17)
    ax.set_xticks(np.arange(len(beta_values)) + 0.5)
    ax.set_yticks(np.arange(len(algorithms)) + 0.5)

    plt.tight_layout()
    plt.savefig('C:/Users/23945/Desktop/result/fig2_r03.png', dpi=300, bbox_inches='tight')
    plt.show()
