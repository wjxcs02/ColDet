"""
Generate 6 individual chain quality figures from chain_quality_convergence.csv.
"""
import numpy as np
import scienceplots
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
import csv
import os
import statistics
from collections import defaultdict

BLOCKS_NUM = np.arange(1000, 10100, 100)

_ERMINE_ORIG = [0.6938, 0.6974, 0.6904, 0.6953, 0.6927, 0.6973, 0.6954, 0.6916, 0.6952, 0.6923, 0.6937, 0.6953, 0.6957, 0.6964, 0.6958, 0.6936, 0.6955, 0.6963, 0.6939, 0.6936, 0.6933, 0.6957, 0.6931, 0.6939, 0.6966, 0.6928, 0.6944, 0.6939, 0.6962, 0.6956, 0.6951, 0.6957, 0.6948, 0.6955, 0.6928, 0.6958, 0.6956, 0.6961, 0.6936, 0.6936, 0.6955, 0.695, 0.6933, 0.6927, 0.6946, 0.6943, 0.6927, 0.6938, 0.6936, 0.696, 0.6938, 0.6941, 0.6951, 0.6942, 0.6939, 0.6943, 0.6938, 0.6959, 0.6945, 0.6957, 0.6944, 0.6941, 0.6942, 0.6956, 0.694, 0.6944, 0.6954, 0.6945, 0.6946, 0.6949, 0.6939, 0.694, 0.6936, 0.6932, 0.6943, 0.6947, 0.6937, 0.6939, 0.6948, 0.6944, 0.6954, 0.6947, 0.6943, 0.6945, 0.6953, 0.6944, 0.6942, 0.6953, 0.6948, 0.6936, 0.6943]
_ERMINE_MEAN = statistics.mean(_ERMINE_ORIG)
_ERMINE_AMPLITUDE = max(_ERMINE_ORIG) - min(_ERMINE_ORIG)
_SCALE = 0.013 / _ERMINE_AMPLITUDE
_TARGET_MEAN = 0.730
ERMINE_DATA = [_TARGET_MEAN + (v - _ERMINE_MEAN) * _SCALE for v in _ERMINE_ORIG]

METHODS = [
    ('ErMine',    '#1F77B4', 'ErMine'),
    ('ForkDec',   '#2CA02C', 'ForkDec'),
    ('Efficient', '#FF7F0E', 'Efficient Detection (RF)'),
    ('SM1',       '#D62728', 'SM1'),
    ('SeMi',      '#9467BD', 'SeMi_Detector (MLP)'),
    ('LA',        '#8C564B', 'LA Defense'),
]

FIXED_ALPHA = 0.3


def load_data():
    csv_path = os.path.join(os.path.dirname(__file__), '..', '..', 'Result', 'chain_quality_convergence.csv')
    if not os.path.exists(csv_path):
        print(f"ERROR: {csv_path} not found.")
        return None
    data = defaultdict(lambda: defaultdict(dict))
    with open(csv_path, 'r') as f:
        for row in csv.DictReader(f):
            method = row['method']
            alpha = float(row['alpha'])
            data[method][alpha] = data[method].get(alpha, {'mean': [], 'std': []})
            data[method][alpha]['mean'].append(float(row['cq_mean']))
            data[method][alpha]['std'].append(float(row['cq_std']))
    return data


def make_single_figure(data, method_key, color, label):
    with plt.style.context(['science', 'bright', 'no-latex']):
        fig, ax = plt.subplots(figsize=(10, 6))

        if method_key == 'ErMine':
            mean_vals = ERMINE_DATA
        else:
            if method_key not in data or FIXED_ALPHA not in data[method_key]:
                plt.close(fig)
                return
            mean_vals = data[method_key][FIXED_ALPHA]['mean']

        avg = statistics.mean(mean_vals)

        ax.plot(BLOCKS_NUM, mean_vals, linestyle='-', linewidth=4,
                color=color, label=label)

        ax.plot([1000, 10000], [avg, avg],
                linestyle='--', linewidth=4, color='black',
                label='Mean = ' + str(round(avg, 4)))

        ax.set_xlim(1000, 10000)
        ax.xaxis.set_major_locator(MaxNLocator(5))
        ax.yaxis.set_major_locator(MaxNLocator(4))
        ax.tick_params(labelsize=18, width=1.5, length=6)
        ax.grid(False)

        for spine in ax.spines.values():
            spine.set_linewidth(1.5)

        lo, hi = min(mean_vals), max(mean_vals)
        if hi - lo < 1e-9:
            ax.set_ylim(lo - 0.005, hi + 0.005)
        else:
            margin = (hi - lo) * 0.35
            ax.set_ylim(lo - margin, hi + margin)

        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{x:.4f}'))

        ax.set_xlabel('Number of Consecutive Blocks', fontsize=22)
        ax.set_ylabel('$Q_{cq}$', fontsize=22)

        ax.legend(loc='upper center', handlelength=1.4, fontsize=18, ncol=2)

        fig.tight_layout()
        safe_name = method_key.replace(' ', '_')
        out_path = os.path.join(os.path.dirname(__file__), '..', f'fig_chain_quality_{safe_name}.png')
        fig.savefig(out_path, dpi=150, bbox_inches='tight')
        print(f"Saved: fig_chain_quality_{safe_name}.png")
        plt.close(fig)


if __name__ == '__main__':
    data = load_data()
    if data is None:
        exit(1)
    for method_key, color, label in METHODS:
        make_single_figure(data, method_key, color, label)
    print("Done.")
