import numpy as np
import scienceplots
import matplotlib.pyplot as plt
from matplotlib import patheffects
from matplotlib.ticker import MaxNLocator
from scipy.interpolate import make_interp_spline
import cmaps
from scipy.interpolate import CubicSpline

import statistics




def SM1_analysis():
    cost_factors = np.arange(0, 2500, 200)

    SM1_accuracy = [0,0.42245,0.59098,0.81763,0.83987,0.82154,0.84309,0.86632,0.85271,0.87453,0.876532,0.90208,0.90987]
    SM1_FNR = [1,0.89245,0.47098,0.17763,0.142987,0.099154,0.09009,0.08329,0.07971,0.08453,0.096532,0.090208,0.06943]
    SM1_precision = [0, 0.44567, 0.61782, 0.81763, 0.87645, 0.89754, 0.89084, 0.90845, 0.90998, 0.91783, 0.89084, 0.90208, 0.94534]



    with plt.style.context(['science', 'bright', 'no-latex']):
        fig, ax = plt.subplots(figsize=(13, 8))

        ax.plot(cost_factors, SM1_accuracy, linestyle='--', linewidth=3,
                marker='o', markevery=1, color="#4682B4",
                markersize=13, label="Accuracy")
        ax.plot(cost_factors, SM1_precision, linestyle='-.', linewidth=3,
                marker='^', markevery=1, color="#DC143C",
                markersize=13, label="Precision")
        ax.plot(cost_factors, SM1_FNR, linestyle=':', linewidth=3,
                marker='d', markevery=1, color="#FF8C00",
              markersize=13, label="FNR")

    plt.xlabel("SM1", fontdict={'family': 'Times New Roman', 'size': 35})
    plt.ylabel("Rate", fontdict={'family': 'Times New Roman', 'size': 35})

    plt.legend(loc='center right', handlelength=2,
               prop={'family': 'Times New Roman', 'size': 29})

    plt.xticks(fontproperties='Times New Roman', size=33)
    plt.yticks(fontproperties='Times New Roman', size=33)

    plt.tight_layout()
    plt.savefig('C:/Users/23945/Desktop/result/fig4_SM1.png')
    plt.show()



def OSM_analysis():
    cost_factors = np.arange(0, 2500, 200)

    OSM_accuracy = [0,0.48065,0.602456,0.83463,0.81453,0.86023,0.87964,0.85908,0.88763,0.89832,0.93512,0.93452,0.95633]
    OSM_precision = [0, 0.48065, 0.61092, 0.87934, 0.89084, 0.90753, 0.92093, 0.91032, 0.90845, 0.93845, 0.9564,
                     0.93545, 0.96045]
    OSM_FNR = [1, 0.86506, 0.422456, 0.15463, 0.120453, 0.07023, 0.08964, 0.0759, 0.06887, 0.078892, 0.063512, 0.059452,
               0.04432]



    with plt.style.context(['science', 'bright', 'no-latex']):
        fig, ax = plt.subplots(figsize=(13, 8))

        ax.plot(cost_factors, OSM_accuracy, linestyle='--', linewidth=3,
                marker='o', markevery=1, color="#4682B4",
                markersize=13, label="Accuracy")
        ax.plot(cost_factors, OSM_precision, linestyle='-.', linewidth=3,
                marker='^', markevery=1, color="#DC143C",
                markersize=13, label="Precision")
        ax.plot(cost_factors, OSM_FNR, linestyle=':', linewidth=3,
                marker='d', markevery=1, color="#FF8C00",
              markersize=13, label="FNR")

    plt.xlabel("SM1", fontdict={'family': 'Times New Roman', 'size': 35})
    plt.ylabel("Rate", fontdict={'family': 'Times New Roman', 'size': 35})

    plt.legend(loc='center right', handlelength=2,
               prop={'family': 'Times New Roman', 'size': 29})

    plt.xticks(fontproperties='Times New Roman', size=33)
    plt.yticks(fontproperties='Times New Roman', size=33)

    plt.tight_layout()
    plt.savefig('C:/Users/23945/Desktop/result/fig4_OSM.png')
    plt.show()


def STM_analysis():
    cost_factors = np.arange(0, 2500, 200)

    STM_accuracy = [0,0.57132,0.61543,0.85732,0.83764,0.82983,0.85730,0.87963,0.88921,0.89981,0.90872,0.96452,0.99633]
    STM_precision = [0, 0.54565, 0.63045, 0.89906, 0.92304, 0.91234, 0.94564, 0.92343, 0.95643, 0.93432, 0.94586,
                     0.96535, 0.98633]
    STM_FNR = [1, 0.85132, 0.38543, 0.13732, 0.10764, 0.0892983, 0.073099, 0.079631, 0.0588921, 0.0589981, 0.0490872,
               0.016452, 0.02093]



    with plt.style.context(['science', 'bright', 'no-latex']):
        fig, ax = plt.subplots(figsize=(13, 8))

        ax.plot(cost_factors, STM_accuracy, linestyle='--', linewidth=3,
                marker='o', markevery=1, color="#4682B4",
                markersize=13, label="Accuracy")
        ax.plot(cost_factors, STM_precision, linestyle='-.', linewidth=3,
                marker='^', markevery=1, color="#DC143C",
                markersize=13, label="Precision")
        ax.plot(cost_factors, STM_FNR, linestyle=':', linewidth=3,
                marker='d', markevery=1, color="#FF8C00",
              markersize=13, label="FNR")

    plt.xlabel("SM1", fontdict={'family': 'Times New Roman', 'size': 35})
    plt.ylabel("Rate", fontdict={'family': 'Times New Roman', 'size': 35})

    plt.legend(loc='center right', handlelength=2,
               prop={'family': 'Times New Roman', 'size': 29})

    plt.xticks(fontproperties='Times New Roman', size=33)
    plt.yticks(fontproperties='Times New Roman', size=33)

    plt.tight_layout()
    plt.savefig('C:/Users/23945/Desktop/result/fig4_STM.png')
    plt.show()


def accuracy_analysis():
    cost_factors = np.arange(0, 2500, 200)
    DQRN_accuracy = [0,0.59081,0.70095,0.80982,0.85752,0.88682,0.899011,0.90632,0.92777,0.950843,0.970082,0.98763,0.99972]
    BPNN_accuracy = [0,0.35245,0.58098,0.68763,0.77987,0.82154,0.84309,0.84632,0.85271,0.87453,0.876532,0.90208,0.90987]
    Boosting_accuracy = [0,0.45065,0.632456,0.72463,0.80453,0.85023,0.86964,0.87908,0.88763,0.89832,0.91512,0.93452,0.95633]
    SM_NEEDLE_accuracy = [0,0.57132,0.72543,0.82732,0.87764,0.88983,0.89730,0.90963,0.91921,0.93981,0.95872,0.96452,0.99633]

    # #曲线平滑处理
    # all_x = np.concatenate([DQRN_accuracy, SM1_accuracy, OSM_accuracy])
    # x_smooth = np.linspace(min(all_x), max(all_x), 1000)
    # cs_acc = CubicSpline(cost_factors, DQRN_accuracy)
    # DQRN_accuracy_smooth = cs_acc(x_smooth)

    with plt.style.context(['science', 'bright', 'no-latex']):
        fig, ax = plt.subplots(figsize=(13, 8))
        # plt.plot(x_smooth, DQRN_accuracy_smooth, color='#014382',linestyle='-', linewidth=3, label='ErMine_DQRN')
        # plt.plot(cost_factors, DQRN_accuracy, 'o', color='#1f77b4', markersize=13)

        ax.plot(cost_factors, DQRN_accuracy, linestyle='-', linewidth=3,
                marker='s', markevery=1, color="#014382",
                markersize=13, label="ErMine")
        ax.plot(cost_factors, BPNN_accuracy, linestyle='--', linewidth=3,
                marker='o', markevery=1, color="#C9631B",
                markersize=13, label="BPNN")
        ax.plot(cost_factors, Boosting_accuracy, linestyle='-.', linewidth=3,
                marker='^', markevery=1, color="#FDC101",
                markersize=13, label="Boosting")
        ax.plot(cost_factors, SM_NEEDLE_accuracy, linestyle=':', linewidth=3,
                marker='d', markevery=1, color="#55A868",
              markersize=13, label="SM_NEEDLE")

    plt.xlabel("The Number of Training Round", fontdict={'family': 'Times New Roman', 'size': 35})
    plt.ylabel("Rate", fontdict={'family': 'Times New Roman', 'size': 35})

    plt.legend(loc='lower right', handlelength=2,
               prop={'family': 'Times New Roman', 'size': 29})

    plt.xticks(fontproperties='Times New Roman', size=33)
    plt.yticks(fontproperties='Times New Roman', size=33)

    plt.tight_layout()
    #plt.savefig('C:/Users/23945/Desktop/result/fig4_accurcy.png')
    plt.show()



def precision_analysis():
    cost_factors = np.arange(0, 2500, 200)
    DQRN_precision = [0,0.47234,0.67273,0.83984,0.87834,0.90992,0.92364,0.937023,0.959456,0.96345,0.975864,0.98763,0.990972]
    BPNN_precision = [0,0.34567,0.57782,0.72763,0.80645,0.83754,0.87084,0.88845,0.90998,0.911783,0.925084,0.94208,0.95534]
    Boosting_precision = [0,0.42065,0.60092,0.77934,0.83084,0.87753,0.90093,0.91032,0.919845,0.930845,0.9464,0.95545,0.97045]
    SM_NEEDLE_precision = [0,0.49565,0.70045,0.85906,0.90304,0.93234,0.94564,0.951343,0.962643,0.96432,0.964586,0.979535,0.989633]

    # # 曲线平滑处理
    # m = make_interp_spline(cost_factors, DQRN_accuracy)
    # cost_factors = np.linspace(0, 2500, 20)
    # DQRN_accuracy = m(cost_factors)

    with plt.style.context(['science', 'bright', 'no-latex']):
        fig, ax = plt.subplots(figsize=(13, 8))

        ax.plot(cost_factors, DQRN_precision, linestyle='-', linewidth=3,
                marker='s', markevery=1, color="#014382",
                markersize=13, label="ErMine")
        ax.plot(cost_factors, BPNN_precision, linestyle='--', linewidth=3,
                marker='o', markevery=1, color="#C9631B",
                markersize=13, label="BPNN")
        ax.plot(cost_factors, Boosting_precision, linestyle='-.', linewidth=3,
                marker='^', markevery=1, color="#FDC101",
                markersize=13, label="Boosting")
        ax.plot(cost_factors, SM_NEEDLE_precision, linestyle=':', linewidth=3,
                marker='d', markevery=1, color="#55A868",
              markersize=13, label="SM_NEEDLE")

    plt.xlabel("The Number of Training Round", fontdict={'family': 'Times New Roman', 'size': 35})
    plt.ylabel("Rate", fontdict={'family': 'Times New Roman', 'size': 35})

    plt.legend(loc='lower right', handlelength=2,
               prop={'family': 'Times New Roman', 'size': 29})

    plt.xticks(fontproperties='Times New Roman', size=33)
    plt.yticks(fontproperties='Times New Roman', size=33)

    plt.tight_layout()
    plt.savefig('C:/Users/23945/Desktop/result/fig4_precision.png')
    plt.show()




def FNR_analysis():
    cost_factors = np.arange(0, 2500, 200)
    DQRN_FNR = [1,0.78081,0.40095,0.15982,0.10752,0.085682,0.066011,0.05329,0.041776,0.030843,0.025682,0.020763,0.01093]
    BPNN_FNR = [1,0.89245,0.60098,0.25763,0.152987,0.139154,0.11009,0.09829,0.09071,0.08453,0.080532,0.076208,0.06943]
    Boosting_FNR = [1,0.83506,0.542456,0.21463,0.120453,0.11023,0.09964,0.08759,0.08087,0.074892,0.063512,0.059452,0.04932]
    SM_NEEDLE_FNR = [1,0.76132,0.38543,0.13732,0.10764,0.0892983,0.063099,0.059631,0.0408921,0.0299981,0.0200872,0.016452,0.01093]

    # # 曲线平滑处理
    # m = make_interp_spline(cost_factors, DQRN_accuracy)
    # cost_factors = np.linspace(0, 2500, 20)
    # DQRN_accuracy = m(cost_factors)

    with plt.style.context(['science', 'bright', 'no-latex']):
        fig, ax = plt.subplots(figsize=(13, 8))

        ax.plot(cost_factors, DQRN_FNR, linestyle='-', linewidth=3,
                marker='s', markevery=1, color="#014382",
                markersize=13, label="ErMine")
        ax.plot(cost_factors, BPNN_FNR, linestyle='--', linewidth=3,
                marker='o', markevery=1, color="#C9631B",
                markersize=13, label="BPNN")
        ax.plot(cost_factors, Boosting_FNR, linestyle='-.', linewidth=3,
                marker='^', markevery=1, color="#FDC101",
                markersize=13, label="Boosting")
        ax.plot(cost_factors, SM_NEEDLE_FNR, linestyle=':', linewidth=3,
                marker='d', markevery=1, color="#55A868",
              markersize=13, label="SM_NEEDLE")

    plt.xlabel("The Number of Training Round", fontdict={'family': 'Times New Roman', 'size': 35})
    plt.ylabel("Rate", fontdict={'family': 'Times New Roman', 'size': 35})

    plt.legend(loc='upper right', handlelength=2,
               prop={'family': 'Times New Roman', 'size': 29})

    plt.xticks(fontproperties='Times New Roman', size=33)
    plt.yticks(fontproperties='Times New Roman', size=33)

    plt.tight_layout()
    plt.savefig('C:/Users/23945/Desktop/result/fig4_FNR.png')
    plt.show()


if __name__ == '__main__':
    accuracy_analysis()
    # precision_analysis()
    # FNR_analysis()
    # SM1_analysis()
    # OSM_analysis()
    # STM_analysis()