import matplotlib.pyplot as plt
import matplotlib
import csv
import os
import math
import numpy as np
import statistics
from collections import defaultdict

matplotlib.rcParams['font.family'] = 'serif'
matplotlib.rcParams['font.size'] = 17
matplotlib.rcParams['font.serif'] = ['Times New Roman']


def load_data(beta_str):
    """Load CSV data for a specific beta suffix (e.g. '0.3', '0.35', '0.4')."""
    csv_path = os.path.join(os.path.dirname(__file__), '..', '..', 'Result', f'comprehensive_results_beta{beta_str}.csv')
    if not os.path.exists(csv_path):
        print(f"ERROR: {csv_path} not found.")
        return None

    alphas, honest_att, sm1_att, theo_att = [], [], [], []
    ermine_att, nonparam_att, forkdec_att = [], [], []
    la_att, efficient_att, semi_att = [], [], []
    honest_other, sm1_other, ermine_other = [], [], []
    nonparam_other, forkdec_other, la_other = [], [], []
    efficient_other, semi_other = [], []

    with open(csv_path, 'r') as f:
        for row in csv.DictReader(f):
            alphas.append(float(row['alpha']))
            honest_att.append(float(row['honest_att']))
            sm1_att.append(float(row['sm1_att']))
            theo_att.append(float(row['theo_att']))
            ermine_att.append(float(row['ermine_att']))
            nonparam_att.append(float(row['nonparam_att']))
            forkdec_att.append(float(row['forkdec_att']))
            la_att.append(float(row['la_att']))
            efficient_att.append(float(row['efficient_att']))
            semi_att.append(float(row['semi_att']))
            honest_other.append(float(row['honest_other']))
            sm1_other.append(float(row['sm1_other']))
            ermine_other.append(float(row['ermine_other']))
            nonparam_other.append(float(row['nonparam_other']))
            forkdec_other.append(float(row['forkdec_other']))
            la_other.append(float(row['la_other']))
            efficient_other.append(float(row['efficient_other']))
            semi_other.append(float(row['semi_other']))

    return {
        'alphas': alphas, 'honest_att': honest_att, 'sm1_att': sm1_att,
        'theo_att': theo_att, 'ermine_att': ermine_att,
        'nonparam_att': nonparam_att, 'forkdec_att': forkdec_att,
        'la_att': la_att, 'efficient_att': efficient_att, 'semi_att': semi_att,
        'honest_other': honest_other, 'sm1_other': sm1_other,
        'ermine_other': ermine_other, 'nonparam_other': nonparam_other,
        'forkdec_other': forkdec_other, 'la_other': la_other,
        'efficient_other': efficient_other, 'semi_other': semi_other,
    }


def load_ermine_std(beta_str, alphas):
    """Compute standard deviation of ErMine revenue from raw output.csv data."""
    csv_path = os.path.join(os.path.dirname(__file__), '..', '..', 'Result', 'output.csv')
    if not os.path.exists(csv_path):
        print(f"WARNING: {csv_path} not found. Cannot compute ErMine std.")
        return None

    beta_val = float(beta_str)
    grouped = defaultdict(lambda: {'att': [], 'agent': [], 'other': []})

    with open(csv_path, 'r') as f:
        for row in csv.DictReader(f):
            b = float(row['beta'])
            if abs(b - beta_val) > 0.005:
                continue
            a = round(float(row['alpha']), 2)
            grouped[a]['att'].append(float(row['rela_att']))
            grouped[a]['agent'].append(float(row['rela_agent']))
            grouped[a]['other'].append(float(row['rela_other']))

    result = {}
    for a, vals in grouped.items():
        n_att = len(vals['att'])
        n_agent = len(vals['agent'])
        n_other = len(vals['other'])
        result[a] = (
            statistics.stdev(vals['att']) / math.sqrt(n_att) if n_att > 1 else 0.0,
            statistics.stdev(vals['agent']) / math.sqrt(n_agent) if n_agent > 1 else 0.0,
            statistics.stdev(vals['other']) / math.sqrt(n_other) if n_other > 1 else 0.0,
        )
    return result


# Colors and styles (same as plot_results.py)
colors = {
    'Honest':      '#333333',
    'SM1':         '#e41a1c',
    'Theoretical': '#e41a1c',
    'ErMine':      '#ff7f00',
    'NonParam':    '#377eb8',
    'ForkDec':     '#4daf4a',
    'LA':          '#984ea3',
    'Efficient':   '#a65628',
    'SeMi':        '#f781bf',
}
styles = {
    'Honest':      '--',
    'SM1':         '-',
    'Theoretical': ':',
    'ErMine':      '-',
    'NonParam':    '-',
    'ForkDec':     '-',
    'LA':          '-',
    'Efficient':   '-',
    'SeMi':        '-',
}
markers = {
    'Honest':      's',
    'SM1':         'o',
    'Theoretical': '',
    'ErMine':      'D',
    'NonParam':    '^',
    'ForkDec':     'v',
    'LA':          '<',
    'Efficient':   '>',
    'SeMi':        'p',
}

# Vertical background zone definitions (alpha ranges → colors)
ZONES = [
    (0.23, 0.30, '#E8F5E9'),   # light green
    (0.30, 0.40, '#FFF8E1'),   # light yellow
    (0.40, 0.47, '#FFEBEE'),   # light pink
]


def draw_background_zones(ax, x_min=0.23, x_max=0.47):
    """Draw vertical colored background zones."""
    for x_start, x_end, color in ZONES:
        x0 = max(x_start, x_min)
        x1 = min(x_end, x_max)
        if x0 < x1:
            ax.axvspan(x0, x1, facecolor=color, edgecolor='none', alpha=0.50, zorder=0)


ROLE_CFG = {
    'honest': {
        'att_data': True, 'other_data': False,
        'ylabel': r'$R_h^{rela}$', 'title': 'Honest Miner Revenue',
        'letter': '(a)', 'filename': 'honest',
        'baseline_label': 'Honest (Baseline)',
    },
    'selfish': {
        'att_data': False, 'other_data': True,
        'ylabel': r'$R_s^{rela}$', 'title': 'Selfish Miner Revenue',
        'letter': '(b)', 'filename': 'selfish',
        'baseline_label': 'Honest Mining (Fair Share)',
    },
    'rational': {
        'att_data': False, 'other_data': False,
        'ylabel': r'$R_r^{rela}$', 'title': 'Rational Miner Revenue',
        'letter': '(c)', 'filename': 'rational',
        'baseline_label': 'Honest (Baseline)',
    },
}


def make_role_figure(beta_str, role):
    """Generate a single figure for a given beta and role, with background zones."""
    cfg = ROLE_CFG[role]
    d = load_data(beta_str)
    if d is None:
        return

    a = d['alphas']
    beta_val = float(beta_str)

    # Load ErMine standard deviations
    erm_std = load_ermine_std(beta_str, a)
    if erm_std is not None and len(erm_std) > 0:
        available_alphas = sorted(erm_std.keys())
        erm_att_std = []
        erm_other_std = []
        for x in a:
            nearest = min(available_alphas, key=lambda k: abs(k - x))
            s = erm_std.get(nearest, (0, 0, 0))
            erm_att_std.append(s[0])
            erm_other_std.append(s[2])
    else:
        erm_att_std = [0.0] * len(a)
        erm_other_std = [0.0] * len(a)

    # Compute gains
    honest_gain = [h - x for h, x in zip(d['honest_att'], a)]
    sm1_gain = [s - x for s, x in zip(d['sm1_att'], a)]
    theo_gain = [t - x for t, x in zip(d['theo_att'], a)]
    ermine_gain = [e - x for e, x in zip(d['ermine_att'], a)]
    nonparam_gain = [n - x for n, x in zip(d['nonparam_att'], a)]
    forkdec_gain = [f - x for f, x in zip(d['forkdec_att'], a)]
    la_gain = [l - x for l, x in zip(d['la_att'], a)]
    efficient_gain = [e - x for e, x in zip(d['efficient_att'], a)]
    semi_gain = [s - x for s, x in zip(d['semi_att'], a)]

    fig, ax = plt.subplots(figsize=(10, 8))

    # ---- Draw background zones ----
    draw_background_zones(ax)

    # ---- Plot data lines ----
    if role == 'rational':
        ax.plot(a, honest_gain, color=colors['Honest'], linestyle=styles['Honest'],
                marker=markers['Honest'], markersize=7, linewidth=2, label='Honest (Baseline)')
        ax.plot(a, sm1_gain, color=colors['SM1'], linestyle=styles['SM1'],
                marker=markers['SM1'], markersize=7, linewidth=2, label='SM1 (No Defense)')
        ax.plot(a, theo_gain, color=colors['Theoretical'], linestyle=styles['Theoretical'],
                marker=markers['Theoretical'], markersize=5, linewidth=1.5, label='Theoretical SM1')
        ax.plot(a, ermine_gain, color=colors['ErMine'], linestyle=styles['ErMine'],
                marker=markers['ErMine'], markersize=7, linewidth=2, label='ErMine (Ours)')
        if erm_std is not None:
            ax.fill_between(a,
                            [v - s for v, s in zip(ermine_gain, erm_att_std)],
                            [v + s for v, s in zip(ermine_gain, erm_att_std)],
                            alpha=0.2, color=colors['ErMine'])
        ax.plot(a, nonparam_gain, color=colors['NonParam'], linestyle=styles['NonParam'],
                marker=markers['NonParam'], markersize=7, linewidth=2, label='Non-Parametric')
        ax.plot(a, forkdec_gain, color=colors['ForkDec'], linestyle=styles['ForkDec'],
                marker=markers['ForkDec'], markersize=7, linewidth=2, label='ForkDec')
        ax.plot(a, la_gain, color=colors['LA'], linestyle=styles['LA'],
                marker=markers['LA'], markersize=7, linewidth=2, label='LA Defense')
        ax.plot(a, efficient_gain, color=colors['Efficient'], linestyle=styles['Efficient'],
                marker=markers['Efficient'], markersize=7, linewidth=2, label='Efficient (RF)')
        ax.plot(a, semi_gain, color=colors['SeMi'], linestyle=styles['SeMi'],
                marker=markers['SeMi'], markersize=7, linewidth=2, label='SeMi_Detector (MLP)')
    elif cfg['att_data'] and not cfg['other_data']:
        # Honest Miner Revenue
        ax.plot(a, d['honest_att'], color=colors['Honest'], linestyle=styles['Honest'],
                marker=markers['Honest'], markersize=7, linewidth=2, label='Honest (Baseline)')
        ax.plot(a, d['sm1_att'], color=colors['SM1'], linestyle=styles['SM1'],
                marker=markers['SM1'], markersize=7, linewidth=2, label='SM1 (No Defense)')
        ax.plot(a, d['nonparam_att'], color=colors['NonParam'], linestyle=styles['NonParam'],
                marker=markers['NonParam'], markersize=7, linewidth=2, label='Non-Parametric')
        ax.plot(a, d['forkdec_att'], color=colors['ForkDec'], linestyle=styles['ForkDec'],
                marker=markers['ForkDec'], markersize=7, linewidth=2, label='ForkDec')
        ax.plot(a, d['la_att'], color=colors['LA'], linestyle=styles['LA'],
                marker=markers['LA'], markersize=7, linewidth=2, label='LA Defense')
        ax.plot(a, d['efficient_att'], color=colors['Efficient'], linestyle=styles['Efficient'],
                marker=markers['Efficient'], markersize=7, linewidth=2, label='Efficient (RF)')
        ax.plot(a, d['semi_att'], color=colors['SeMi'], linestyle=styles['SeMi'],
                marker=markers['SeMi'], markersize=7, linewidth=2, label='SeMi_Detector (MLP)')
        ax.plot(a, d['ermine_att'], color=colors['ErMine'], linestyle=styles['ErMine'],
                marker=markers['ErMine'], markersize=7, linewidth=2, label='ErMine (Ours)')
        if erm_std is not None:
            ax.fill_between(a,
                            [v - s for v, s in zip(d['ermine_att'], erm_att_std)],
                            [v + s for v, s in zip(d['ermine_att'], erm_att_std)],
                            alpha=0.2, color=colors['ErMine'])
        # Honest baseline: y = α (attacker's fair share when no attack)
        ax.plot(a, a, color='gray', linestyle='--', linewidth=1, alpha=0.5)
    else:
        # Selfish Miner Revenue
        ax.plot(a, d['honest_other'], color=colors['Honest'], linestyle=styles['Honest'],
                marker=markers['Honest'], markersize=7, linewidth=2, label='Honest (Baseline)')
        ax.plot(a, d['sm1_other'], color=colors['SM1'], linestyle=styles['SM1'],
                marker=markers['SM1'], markersize=7, linewidth=2, label='SM1 (No Defense)')
        ax.plot(a, d['nonparam_other'], color=colors['NonParam'], linestyle=styles['NonParam'],
                marker=markers['NonParam'], markersize=7, linewidth=2, label='Non-Parametric')
        ax.plot(a, d['forkdec_other'], color=colors['ForkDec'], linestyle=styles['ForkDec'],
                marker=markers['ForkDec'], markersize=7, linewidth=2, label='ForkDec')
        ax.plot(a, d['la_other'], color=colors['LA'], linestyle=styles['LA'],
                marker=markers['LA'], markersize=7, linewidth=2, label='LA Defense')
        ax.plot(a, d['efficient_other'], color=colors['Efficient'], linestyle=styles['Efficient'],
                marker=markers['Efficient'], markersize=7, linewidth=2, label='Efficient (RF)')
        ax.plot(a, d['semi_other'], color=colors['SeMi'], linestyle=styles['SeMi'],
                marker=markers['SeMi'], markersize=7, linewidth=2, label='SeMi_Detector (MLP)')
        ax.plot(a, d['ermine_other'], color=colors['ErMine'], linestyle=styles['ErMine'],
                marker=markers['ErMine'], markersize=7, linewidth=2, label='ErMine (Ours)')
        if erm_std is not None:
            ax.fill_between(a,
                            [v - s for v, s in zip(d['ermine_other'], erm_other_std)],
                            [v + s for v, s in zip(d['ermine_other'], erm_other_std)],
                            alpha=0.2, color=colors['ErMine'])

    ax.set_xlabel(r'$\alpha$', fontsize=18)
    ax.set_ylabel(cfg['ylabel'], fontsize=18)
    ax.set_title(f'{cfg["letter"]}  {cfg["title"]}  ($\\beta$={beta_str})',
                 fontsize=18, fontweight='bold', pad=12)
    ax.grid(True, alpha=0.25, zorder=5)
    ax.set_xlim(0.23, 0.47)
    ax.tick_params(labelsize=15)

    # ---- Legend ----
    handles, labels = ax.get_legend_handles_labels()
    seen = set()
    unique_handles, unique_labels = [], []
    for h, l in zip(handles, labels):
        if l not in seen and not l.startswith('_'):
            seen.add(l)
            unique_handles.append(h)
            unique_labels.append(l)

    ax.legend(unique_handles, unique_labels, loc='upper left', fontsize=10,
              frameon=True, ncol=2)

    fig.tight_layout()
    out_path = os.path.join(os.path.dirname(__file__), '..',
                            f'fig_{cfg["filename"]}_beta{beta_str}.png')
    fig.savefig(out_path, dpi=200, bbox_inches='tight')
    print(f"Saved: fig_{cfg['filename']}_beta{beta_str}.png")
    plt.close(fig)


# ============================================================
# Generate separate figures for all betas × roles
# ============================================================
for beta in ['0.3', '0.35', '0.4']:
    for role in ['honest', 'selfish', 'rational']:
        make_role_figure(beta, role)

print("All enhanced figures generated.")
